#ifndef EXP10TO2
#define EXP10TO2
#include "number.h"

void exp10ToExp2(struct Number *pn);

#endif
