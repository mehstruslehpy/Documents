this is a translator/preprocessor for caret style exponentiations into functional form


for example:           x^y 
will be translated to: pow(x, y)


it searches every line in a file for the caret symbol when it finds a caret it iterates over that line replacing all instances
 of the caret notation for the function notation



you can escape translation of caret symbols by using the comment:
//bitwise <anything you want here> 
directly above lines that you do not want to get translated



any other line that does not have a caret symbol should just get copied directly as is into the translated file



the demo_expressions.cpp sample file will not compile using g++ on its own

but if you translate it with my preprocessor/translator it will output a file called translated.cpp that will compile perfectly into a working 
program


WINDOWS USERS:


to compile on your own in codeblocks download the boost libraries and set the search path to search the directories containing the various boost sources

on my machine for example it is: C:\Program Files (x86)\CodeBlocks\boost 

you also might need to force c++11 to use regex's

I mainly wrote and tested this on archlinux so it might not work perfectly on windows..

but it seems to translate the demo_expressions.cpp file just fine! :D