#include <iostream>
#include <math.h>
using namespace std;

int main()
{
	//this comment and all lines that don't contain exponentiation 
	//should be left intact
	//sadly the formatting of the exponential expressions gets smashed up	
	int x = 1; 
	int	y = 2; 
	int	z = 3; 
	int	a = 4;
	int	b = 5;
	int	c = 0;
	
	//do some math
	c = 1+2+3+4+5;
	z = a ^ b;

	//do more math
	y = pow((111),(222)) * pow((333),(444));
	x = (1+2) + pow((111+222),(333));
	b = pow((111),( x+y+z ));

	a = pow((x),(y)) + pow((y),(z));

	//output some numbers
	cout << a << endl;
	cout << b << endl;
	cout << c << endl;
	cout << x << endl;
	cout << y << endl;
	cout << z << endl;
	return 0;
}
