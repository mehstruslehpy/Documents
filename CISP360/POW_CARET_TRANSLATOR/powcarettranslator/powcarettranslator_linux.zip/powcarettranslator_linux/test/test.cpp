#include <iostream>
using namespace std;

int main() 
{
	int	x = ( - 9 + 6 / 2 );
	cout << x;
}
