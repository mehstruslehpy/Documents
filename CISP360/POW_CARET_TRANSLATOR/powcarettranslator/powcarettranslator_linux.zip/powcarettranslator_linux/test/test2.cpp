#include <iostream>
using namespace std;

int notmain() 
{
	int	x = ( - 9 + 6 / 2 );
	cout << x;
}
