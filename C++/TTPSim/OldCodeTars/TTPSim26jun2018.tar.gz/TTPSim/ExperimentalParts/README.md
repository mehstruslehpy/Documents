# What is this?
	-this is for parts that are not in ttp that I would like to emulate anyway
		or other experimental additions to the main program
	-the base design is built around ttp but I think it would be cool to add more later
