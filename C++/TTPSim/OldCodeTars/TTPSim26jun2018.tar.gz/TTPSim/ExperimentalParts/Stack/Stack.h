#ifndef _STACK_H
#define _STACK_H
#include "../defs.h"
class Stack
{
public:

};
#endif
