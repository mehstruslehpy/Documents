#ifndef _CODE_H
#define _CODE_H
#include "../defs.h"
class Code
{
public:

};
#endif
