#include "../common.h"
#include "RegBank.h"
using namespace std;
int main()
{
    RegBank testReg;
    cout << "hello world" << endl;
    return 0;
}
