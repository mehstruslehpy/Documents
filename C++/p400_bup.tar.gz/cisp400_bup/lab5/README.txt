Check style and format
Current defaults are set to lowest value not sure what specifically I should do
test more
Trim any extra unneeded stuff
