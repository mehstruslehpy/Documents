/************************
William Vanskike
CISP 400 MW 5:30 pm
Animal Inheritance
October 25, 2017
************************/

#ifndef ELEPHANT_H_WPV
#define ELEPHANT_H_WPV
#include <iostream>
#include "mammal.h"
using namespace std;

class Elephant : public Mammal
{
    double _weight;
public:
    Elephant ( );
    Elephant ( const char* );
    //the three doubles are the body temp vars
    Elephant ( const char* n, const GenderType& gt,
            double fc, double lf, double t, double wt);
    Elephant ( const Elephant& );

    ~Elephant ( );

    Elephant& operator= ( const Elephant& );

    void Display()const;
    void Feed ( void )const;
    void CageMaintenance()const
    {
        cout << "Elephant Cage Maintenance:" << endl;
        cout << "\t1) Clean out the cage"<<endl;
        cout << "\t2) Empty and wash water tub"<<endl;
    }
    void setWeight(const double);
    double getWeight() const;
    bool weightInRange() const;

};

#endif
