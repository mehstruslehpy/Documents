/************************
William Vanskike
CISP 400 MW 5:30 pm
Animal Inheritance
October 25, 2017
************************/

#include "mammal.h"

Mammal::Mammal ( )
:Animal()
{
    _bodytemp = 0;
    _bodytemphi = 0;
    _bodytemplo = 0;
}

Mammal::Mammal ( const char* name )
:Animal(name)
{
    _bodytemp = 0;
    _bodytemphi = 0;
    _bodytemplo = 0;
}
Mammal::Mammal ( const char* n, const GenderType& gt,
        double fc, double lf, const DietType& dt,
        const FeedType& ft, double t, double hi, double lo)
:Animal(n,gt,fc,lf,dt,ft)
{
    _bodytemp = t;
    _bodytemphi = hi;
    _bodytemplo = lo;
}

Mammal::Mammal ( const Mammal& m)
:Animal(m)
{
    _bodytemp = m._bodytemp;
    _bodytemphi = m._bodytemphi;
    _bodytemplo = m._bodytemplo;
}

Mammal::~Mammal ( ) { }

Mammal& Mammal::operator= ( const Mammal& m)
{
    Animal::operator=(m);
    _bodytemp = m._bodytemp;
    _bodytemphi = m._bodytemphi;
    _bodytemplo = m._bodytemplo;

    return *this;
}

void Mammal::Display()const
{
    Animal::Display();
    cout << "Body Temp: " << _bodytemp << endl;
    cout << "Body Temp Range: " << _bodytemplo << "-" << _bodytemphi << endl;
}

void Mammal::setTemp(const double t)
{
    _bodytemp = t;
}
double Mammal::getTemp() const
{
    return _bodytemp;
}
bool Mammal::tempInRange() const
{
    return ( _bodytemp < _bodytemphi && _bodytemp > _bodytemplo);
}

