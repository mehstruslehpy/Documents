/************************
William Vanskike
CISP 400 MW 5:30 pm
Animal Inheritance
October 25, 2017
************************/

#ifndef PYTHON_H_WPV
#define PYTHON_H_WPV
#include <iostream>
#include "reptile.h"
using namespace std;

class Python : public Reptile
{
    double _length;
public:
    Python ( );
    Python ( const char* );
    Python ( const char* n, const GenderType& gt,
            double fc, double lf, double len);
    Python ( const Python& );

    ~Python ( );

    Python& operator= ( const Python& );

    void Display()const;
    void Feed ( void )const;
    void CageMaintenance()const
    {
        cout << "Python Cage Maintenance:" << endl;
        cout << "\t1) Clean out the cage"<<endl;
        cout << "\t2) Empty and wash water tub"<<endl;
    }
    void setLength(double);
    double getLength() const;
    bool lengthInRange() const;
};

#endif
