/************************
William Vanskike
CISP 400 MW 5:30 pm
Animal Inheritance
October 25, 2017
************************/

#include "elephant.h"
Elephant::Elephant ( )
:Mammal()
{
    _weight = 0;
}

Elephant::Elephant ( const char* name )
:Mammal(name)
{
    _weight = 0;
}

Elephant::Elephant ( const char* n, const GenderType& gt,
        double fc, double lf, double t, double wt)
:Mammal(n,gt,fc,lf,Herbivore,Hay,t,98.0,97.0)
{
    _weight = wt;
}

Elephant::Elephant ( const Elephant& e)
:Mammal(e)
{
    _weight = e._weight;
}

Elephant::~Elephant ( ) { }

Elephant& Elephant::operator= ( const Elephant& e)
{
    Mammal::operator=(e);
    _weight = e._weight;
    return *this;
}
void Elephant::Feed ( void )const
{
    cout << "Elephant feeding: " << endl;
    cout << "\t1) Place hay in the trough" << endl;
    cout << "\t2) Run!" << endl;
}
void Elephant::Display()const
{
    Mammal::Display();
    cout << "Weight: " << _weight << endl;
}

void Elephant::setWeight(const double w)
{
    _weight = w;
}
double Elephant::getWeight() const
{
    return _weight;
}
bool Elephant::weightInRange() const
{
    return ( _weight < 15000.0 && _weight > 12000.0);
}


