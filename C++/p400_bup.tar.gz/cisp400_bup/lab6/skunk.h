/************************
William Vanskike
CISP 400 MW 5:30 pm
Animal Inheritance
October 25, 2017
************************/

#ifndef SKUNK_H_WPV
#define SKUNK_H_WPV
#include <iostream>
#include "mammal.h"
using namespace std;

class Skunk : public Mammal
{

    bool _descented;
public:
    Skunk ( );
    Skunk ( const char* );
    Skunk ( const char* n, const GenderType& gt,
            double fc, double lf, double t, bool ds);
    Skunk ( const Skunk& );

    ~Skunk ( );

    Skunk& operator= ( const Skunk& );

    void Feed ( void )const;
    void Display()const;

    void CageMaintenance()const
    {
        cout << "Skunk Cage Maintenance:" << endl;
        cout << "\t1) Clean out the cage"<<endl;
        cout << "\t2) Add some air freshener"<<endl;
    }

    void setDescented(const bool ds);
    bool getDescented() const;

};

#endif
