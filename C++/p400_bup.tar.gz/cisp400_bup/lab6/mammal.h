/************************
William Vanskike
CISP 400 MW 5:30 pm
Animal Inheritance
October 25, 2017
************************/

#include <iostream>
#include "animal.h"
using namespace std;

#ifndef MAMMAL_H_WPV
#define MAMMAL_H_WPV

class Mammal : public  Animal
{
    double _bodytemp;
    double _bodytemphi;
    double _bodytemplo;
public:
    Mammal ( );
    Mammal ( const char* );
    Mammal ( const char* n, const GenderType& gt,
            double fc, double lf, const DietType& dt,
            const FeedType& ft, double t, double hi, double lo);
    Mammal ( const Mammal& );

    ~Mammal ( );

    Mammal& operator= ( const Mammal& );

    void Display()const;

    void CageMaintenance()const
    {
        cout << "Mammal";
        cout << "clean out the cage"<<endl;
    }

    void setTemp(const double);
    double getTemp() const;
    bool tempInRange() const;
};

#endif
