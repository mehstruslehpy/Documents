/************************
William Vanskike
CISP 400 MW 5:30 pm
Animal Inheritance
October 25, 2017
************************/

#include "zoo.h"

Zoo::Zoo()
{
    _num = 0;
    for (unsigned i = 0; i < MAX_ZOO; ++i)
    {
        _zoo[i] = NULL;
    }
}
Zoo::~Zoo()
{
    for (unsigned i = 0; i < _num; ++i)
    {
        delete _zoo[i];
    }
    _num = 0;
}
void Zoo::run()
{
    char choice;
    
    while (choice != '5')
    {
        choice = mainmenu();
        switch (choice)
        {
            case '1': add(); break;
            case '2': feed(); break;
            case '3': cage(); break;
            case '4': display(); break;
            case '5': return;
            default: ;
        }
    }
}
//a user can add an animal in two possible manners, a default option or a more granular option
void Zoo::add()
{
    char choice;
    if (_num >= MAX_ZOO)
    {
        cout << "ERROR: You have no more space in your zoo, sorry." << endl;
        return;
    }

    string name = "";
    int gender = 0;
    int croctype = 0;
    cout << "Add:" << endl;
    choice = addmenu();
    switch (choice)
    {
        case '1':
            cout << "Adding an elephant" << endl;
            cout << "Choose a name[press d for a default animal]: ";
            getline(cin,name);
            if (name == "d")
            {
                _zoo[_num++] = new Elephant("Default elephant");
                break;
            }
            cout << "Choose a gender[0=unknown,1=female,2=male]: ";
            cin >> gender;
            cin.ignore (256, '\n');
            _zoo[_num++] = new Elephant(name.c_str(),(GenderType)gender,1,1,96,13000);
            cout << "Elephant added successfully" << endl;
            break;
        case '2': ;
            cout << "Adding a python" << endl;
            cout << "Choose a name[press d for a default animal]: ";
            getline(cin,name);
            if (name == "d")
            {
                _zoo[_num++] = new Python("Default python");
                break;
            }
            cout << "Choose a gender[0=unknown,1=female,2=male]: ";
            cin >> gender;
            cin.ignore (256, '\n');
            _zoo[_num++] = new Python(name.c_str(),(GenderType)gender,1,1,23);
            cout << "Python added successfully" << endl;
            break;
        case '3': 
            cout << "Adding a skunk" << endl;
            cout << "Choose a name[press d for a default animal]: ";
            getline(cin,name);
            if (name == "d")
            {
                _zoo[_num++] = new Skunk("Default skunk");
                break;
            }
            cout << "Choose a gender[0=unknown,1=female,2=male]: ";
            cin >> gender;
            cin.ignore (256, '\n');
            _zoo[_num++] = new Skunk(name.c_str(),(GenderType)gender,1,1,96,true);
            cout << "Skunk added successfully" << endl;
            break;
        case '4': 
            cout << "Adding croc" << endl;
            cout << "Choose a name[press d for a default animal]: ";
            getline(cin,name);
            if (name == "d")
            {
                _zoo[_num++] = new Crocodilia("Default croc");
                break;
            }
            cout << "Choose a gender[0=unknown,1=female,2=male]: ";
            cin >> gender;
            cin.ignore (256, '\n');
            cout << "Choose a croc type[0=Unknown,1=Crocodile,2=Alligator,3=Caiman,4=Gharial]: ";
            cin >> croctype;
            cin.ignore (256, '\n');
            _zoo[_num++] = new Crocodilia(name.c_str(),(GenderType)gender,1,1,(CrocType)croctype);
            cout << "Croc added successfully" << endl;
            break;
        default: 
            cout << "Returning to main menu" << endl;
            break;
    }
    cout << endl;
    cin.clear();
}
void Zoo::feed()
{
    cout << "Feed:" << endl;
    for (unsigned i = 0; i < _num; ++i)
    {
        cout << "###########################################"<< endl;
        _zoo[i]->Feed();
        cout << endl;
    }
}
void Zoo::cage()
{
    cout << "Cage:" << endl;
    
    if (_num == 0) cout << "ERROR: Zoo is currently empty, please add some animals.";
    
    for (unsigned i = 0; i < _num; ++i)
    {
        cout << "###########################################"<< endl;
        _zoo[i]->CageMaintenance();
        cout << endl;
    }

}
void Zoo::display()
{
    cout << "Display:" << endl;
    
    if (_num == 0) cout << "ERROR: Zoo is currently empty, please add some animals.";
    
    for (unsigned i = 0; i < _num; ++i)
    {
        cout << "###########################################"<< endl;
        _zoo[i]->Display();
        cout << endl;
    }
}

//helper functions
char mainmenu()
{
    char input;
    
    cout << "1) add" << endl;
    cout << "2) feed" << endl;
    cout << "3) cage" << endl;
    cout << "4) display" << endl;
    cout << "5) quit" << endl;
    cin >> input;
    cin.ignore (256, '\n'); //flush input buffer after using cin 256 chars for a single char input is probably unnecessary...
    while (input < '1' || input > '5')
    {
        cout << "ERROR: Please make a valid selection [1-5]" << endl;
        cout << "1) add" << endl;
        cout << "2) feed" << endl;
        cout << "3) cage" << endl;
        cout << "4) display" << endl;
        cout << "5) quit" << endl;
        cin.ignore (256, '\n');
        cin >> input;
    }
    cout << endl;
    return input;
}
char addmenu()
{
    char input;
    
    cout << "1) elephant" << endl;
    cout << "2) python" << endl;
    cout << "3) skunk" << endl;
    cout << "4) crocodilia" << endl;
    cin >> input;
    cin.ignore (256, '\n');
    while (input < '1' || input > '4')
    {    
        cout << "1) elephant" << endl;
        cout << "2) python" << endl;
        cout << "3) skunk" << endl;
        cout << "4) crocodilia" << endl;
        cout << "ERROR: Please make a valid selection [1-4]" << endl;
        cin >> input;
        cin.ignore (256, '\n');
    }
    cout << endl;
    return input;

}
