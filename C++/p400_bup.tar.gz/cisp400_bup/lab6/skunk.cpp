/************************
William Vanskike
CISP 400 MW 5:30 pm
Animal Inheritance
October 25, 2017
************************/

#include "skunk.h"

Skunk::Skunk ( )
:Mammal()
{
    _descented = false;
}

Skunk::Skunk ( const char* name )
:Mammal(name)
{
    _descented = false;
}

Skunk::Skunk ( const char* n, const GenderType& gt,
        double fc, double lf, double t, bool ds)
:Mammal(n,gt,fc,lf,Herbivore,GrubsNGrass,t,97.0,95.0)
{
    _descented = ds;
}

Skunk::Skunk ( const Skunk& s)
:Mammal(s)
{
    _descented = s._descented;
}

Skunk::~Skunk ( ) { }

Skunk& Skunk::operator= ( const Skunk& s)
{
    Mammal::operator=(s);
    _descented = s._descented;
    return *this;
}
void Skunk::Feed ( void )const
{
    cout << "Skunk feeding instructions:" << endl;
    cout << "\t1) take one scoop of bugs and one scoop of grass" << endl;
    cout << "\t2) place the scoops in the bowls by the water bowl" << endl;
    cout << "\t3) don't get sprayed" << endl;
}
void Skunk::Display()const
{
    Mammal::Display();
    cout << "Descented: " << ((_descented)?"Yes":"No") << endl;
}

void Skunk::setDescented(const bool ds)
{
    _descented = ds;
}
bool Skunk::getDescented() const
{
    return _descented;
}


