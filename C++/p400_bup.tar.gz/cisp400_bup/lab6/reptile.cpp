/************************
William Vanskike
CISP 400 MW 5:30 pm
Animal Inheritance
October 25, 2017
************************/

#include "reptile.h"

Reptile::Reptile ( )
:Animal()
{
    _env = EnvironmentUnknown;
}

Reptile::Reptile ( const char* name )
:Animal(name)
{
    _env = EnvironmentUnknown;
}
Reptile::Reptile ( const char* n, const GenderType& gt,
        double fc, double lf, const DietType& dt,
        const FeedType& ft, EnvironmentType e)
:Animal(n,gt,fc,lf,dt,ft)
{
    _env = e;
}

Reptile::Reptile ( const Reptile& r)
:Animal(r)
{
    _env = r._env;
}

Reptile::~Reptile ( ) { }

Reptile& Reptile::operator= ( const Reptile& r)
{
    Animal::operator=(r);
    _env = r._env;

    return *this;
}

void Reptile::Display()const
{
    Animal::Display();
    cout << "Environment type: ";
    switch (_env)
    {
        case Water:
            cout << "Water";
            break;
        case Land:
            cout << "Land";
            break;
        default:
            cout << "Unknown";
    }
    cout << endl;
}

void Reptile::setEnv(const EnvironmentType e)
{
    switch (_env)
    {
        case Water:
            _env = Water;
            break;
        case Land:
            _env = Land;
            break;
        default:
            _env = EnvironmentUnknown;
    }
}
EnvironmentType Reptile::getEnv() const
{
    return _env;
}

