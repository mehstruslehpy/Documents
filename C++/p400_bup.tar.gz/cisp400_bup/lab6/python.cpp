/************************
William Vanskike
CISP 400 MW 5:30 pm
Animal Inheritance
October 25, 2017
************************/

#include "python.h"

Python::Python ( )
:Reptile()
{
    _length = 0;
}

Python::Python ( const char* name )
:Reptile(name)
{
    _length = 0;
}

Python::Python ( const char* n, const GenderType& gt,
        double fc, double lf, double l)
:Reptile(n,gt,fc,lf,Carnivore,LiveMice,Land)
{
    _length = l;
}

Python::Python ( const Python& p)
:Reptile(p)
{
    _length = p._length;
}

Python::~Python ( ) { }

Python& Python::operator= ( const Python& p)
{
    Reptile::operator=(p);
    _length = p._length;
    return *this;
}
void Python::Feed ( void )const
{
    cout << "Python feeding: " << endl;
    cout << "\t1) Place mice in tank" << endl;
    cout << "\t2) Check water bowl." << endl;
}
void Python::Display()const
{
    Reptile::Display();
    cout << "Length: " << _length << endl;
}

void Python::setLength(const double l)
{
    _length = l;
}
double Python::getLength() const
{
    return _length;
}
bool Python::lengthInRange() const
{
    return ( _length < 15.0 && _length > 23.0);
}


