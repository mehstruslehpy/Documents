/************************
William Vanskike
CISP 400 MW 5:30 pm
Animal Inheritance
October 25, 2017
************************/


#ifndef CROCODILIA_H_WPV
#define CROCODILIA_H_WPV
#include <iostream>
#include "reptile.h"
using namespace std;

enum CrocType {CrocTypeUnknown, Crocodile, Alligator, Caiman, Gharial};

class Crocodilia : public Reptile
{
    CrocType _type;

public:
    Crocodilia ( );
    Crocodilia ( const char* );
    Crocodilia ( const char* n, const GenderType& gt,
            double fc, double lf, CrocType);
    Crocodilia ( const Crocodilia& );

    ~Crocodilia ( );

    Crocodilia& operator= ( const Crocodilia& );

    void Display()const;
    void Feed ( void )const;
    void CageMaintenance()const
    {
        cout << "Crocodilia Cage Maintenance:" << endl;
        cout << "\t1) Drain water from pond"<<endl;
        cout << "\t2) Clean bottom of pond"<<endl;
    }
    void setCrocType(const CrocType);
    CrocType getCrocType() const;
};

#endif
