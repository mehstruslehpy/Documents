/************************
William Vanskike
CISP 400 MW 5:30 pm
Animal Inheritance
October 25, 2017
************************/

#include "crocodilia.h"

Crocodilia::Crocodilia ( )
:Reptile()
{
    _type = CrocTypeUnknown;
}

Crocodilia::Crocodilia ( const char* name )
:Reptile(name)
{
    _type = CrocTypeUnknown;
}

Crocodilia::Crocodilia ( const char* n, const GenderType& gt,
        double fc, double lf, CrocType t)
:Reptile(n,gt,fc,lf,Carnivore,RawMeat,Water)
{
    _type = t;
}

Crocodilia::Crocodilia ( const Crocodilia& c)
:Reptile(c)
{
    _type = c._type;
}

Crocodilia::~Crocodilia ( ) { }

Crocodilia& Crocodilia::operator= ( const Crocodilia& c)
{
    Reptile::operator=(c);
    _type = c._type;
    return *this;
}
void Crocodilia::Feed ( void )const
{
    cout << "Crocodilia feeding: " << endl;
    cout << "\t1) Pick up meat leftovers from butcher" << endl;
    cout << "\t2) Toss into pond enclosure." << endl;
}
void Crocodilia::Display()const
{
    Reptile::Display();
    cout << "Type: ";
    switch (_type)
    {
        case Crocodile:
            cout << "Crocodile";
            break;
        case Alligator:
            cout << "Alligator";
            break;
        case Caiman:
            cout << "Caiman";
            break;
        case Gharial:
            cout << "Gharial";
            break;
        default:
            cout << "Crocodilia Type Unknown";
    }
    cout << endl;
}

void Crocodilia::setCrocType(const CrocType t)
{
    if (t > 4 || t <= 0) 
    {
        _type = CrocTypeUnknown;
        return;
    }
    _type = t;
}
CrocType Crocodilia::getCrocType() const
{
    return _type;
}


