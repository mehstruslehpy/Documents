/************************
William Vanskike
CISP 400 MW 5:30 pm
Animal Inheritance
October 25, 2017
************************/

#ifndef ZOO_H_WPV
#define ZOO_H_WPV

#include <iostream>
#include "animal.h"
#include "zoo.h"
#include "elephant.h"
#include "python.h"
#include "crocodilia.h"
#include "skunk.h"

using namespace std;

const unsigned MAX_ZOO = 5;
char mainmenu();
char addmenu();

class Zoo
{
    Animal* _zoo[MAX_ZOO];
    unsigned _num;

public:
    Zoo();
    ~Zoo();
    void run();
private:
    void add();
    void feed();
    void cage();
    void display();
};

#endif
