/************************
William Vanskike
CISP 400 MW 5:30 pm
Animal Inheritance
October 25, 2017
************************/

#include <iostream>
#include "animal.h"
using namespace std;

#ifndef REPTILE_H_WPV
#define REPTILE_H_WPV

//I was unsure how specifically to name this enum but you have several other things/enums you refer to as
//types in animal.h so I chose mimic those names.
enum EnvironmentType {EnvironmentUnknown, Water, Land};

class Reptile : public  Animal
{
    EnvironmentType _env;

public:
    Reptile ( );
    Reptile ( const char* );
    Reptile ( const char* n, const GenderType& gt,
            double fc, double lf, const DietType& dt,
            const FeedType& ft, EnvironmentType e);

    Reptile ( const Reptile& );

    ~Reptile ( );

    Reptile& operator= ( const Reptile& );

    void Display()const;

    void CageMaintenance()const
    {
        cout << "Reptile";
        cout << "clean out the cage"<<endl;
    }
    void setEnv(const EnvironmentType);
    EnvironmentType getEnv() const;

};

#endif
