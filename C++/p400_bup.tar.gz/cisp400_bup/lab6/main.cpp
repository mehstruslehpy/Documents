/************************
William Vanskike
CISP 400 MW 5:30 pm
Animal Inheritance
October 25, 2017
************************/

#include <iostream>
#include "elephant.h"
#include "python.h"
#include "crocodilia.h"
#include "skunk.h"

using namespace std;

int main()
{
    cout << "###############################################################\n";
    Elephant elph("Elahfant", Male,1,1,96,10000);
    elph.Display();
    elph.CageMaintenance();
    cout << "Temp in range: " << ((elph.tempInRange())?"Yes":"No") << endl;
    elph.setTemp(96);
    cout << "Current temp: " << elph.getTemp() << endl;
    elph.Feed();
    cout << endl;

    cout << "###############################################################\n";
    Skunk sknk("Skuhnk",Female,1,1,95.2,true);
    sknk.Display();
    sknk.CageMaintenance();
    cout << "Temp in range: " << ((sknk.tempInRange())?"Yes":"No") << endl;
    sknk.setTemp(96);
    cout << "Current temp: " << sknk.getTemp() << endl;
    sknk.Feed();
    cout << endl;

    cout << "###############################################################\n";
    Python pyth("Ssssnake",Male,1,1,12.5);
    pyth.Display();
    pyth.CageMaintenance();
    cout << "Length in range: " << ((pyth.lengthInRange())?"Yes":"No") << endl;
    pyth.setLength(15.5);
    cout << "Current Length: " << pyth.getLength() << endl;
    cout << "Length in range: " << ((pyth.lengthInRange())?"Yes":"No") << endl;
    pyth.Feed();
    cout << endl;

    cout << "###############################################################\n";
    Crocodilia croc("Crocky",Female,1,1,Gharial);
    croc.Display(); 
    croc.CageMaintenance();
    croc.Feed();
    croc.setCrocType(Alligator);
    //this will only display the enum'd number
    cout << "Updating croc type to alligator: " << croc.getCrocType()  << endl;
    croc.Display();
    cout << endl;
    
    return 0;
}
