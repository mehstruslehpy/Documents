/************************
William Vanskike
CISP 400 MW 5:30 pm
Animal Inheritance
October 25, 2017
************************/

#include "zoo.h"

using namespace std;

int main()
{
    Zoo z;
    z.run();
    cout << "Goodbye\n";
    return 0;
}
