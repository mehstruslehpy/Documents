#Give user option to construct animals however they want
#implement other methods
check with fox to be sure I am safely allocating
    Am I testing the correct things?
implement better menus

