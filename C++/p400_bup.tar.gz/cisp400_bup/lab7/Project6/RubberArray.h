///*STUDENT HEADER HERE*/
//TODO: FIX ERROR CODES
#ifndef RUBBER_ARRAY_WPV_
#define RUBBER_ARRAY_WPV_
#include <iostream>
#include <cstdlib>
using namespace std;

template <class T>
class RubberArray
{
    T* _Array;  //where T's are actually stored
    unsigned _len; //num of things
    unsigned _alloc; //allocated spaces
    int _Vindex; //user chooses this

public:
    // Vindex is the virtual index of the first element in your RubberArray
    RubberArray ( int Vindex = 0 );

    // s is the number of items pointed to by T*
    // Vindex is the virtual index of the first element in your RubberArray
    RubberArray ( const T*, unsigned s, int Vindex = 0 );

    //Copy constructor
    RubberArray ( const RubberArray& );

    //Destructor
    ~RubberArray ( ); //[1]

    //Assignment
    RubberArray<T>& operator= ( const RubberArray<T>& ); //[1]

    // Insert the array or a pointer to an array into an ostream
    template <typename OS>
    friend ostream& operator<< ( ostream&, const RubberArray<OS>& );

    template <typename OS>
    friend ostream& operator<< ( ostream&, const RubberArray<OS>* );

    // access an item at index 0<= Vindex <_items (assuming standard indexing)[i]
    T& operator[] ( int Vindex );
    const T& operator[] ( int Vindex ) const;

    // Returns a sub array from virtual index Vfirst to index Vlast-1
    RubberArray operator( ) ( int Vfirst, int Vlast )const;

    // Append either a new item or another RubberArray at index _items
    void append ( const T& ); //[1][2]
    void append ( const RubberArray& );

    // return the number of items in the array
    unsigned length ( ) const
    {
        return _len;
    };

    // Add a new item at index 0 <= Vindex < _items (assuming standard indexing)[i]
    void add ( int Vindex, const T& );

    // Add a new item at index 0 (assuming standard indexing)[i]
    void add ( const T& );

    // Remove the item at index _items-1 (assuming standard indexing)[i]
    void remove ( );

    // Remove the item at index 0 <= Vindex <_items (assuming standard indexing)[i]
    void remove ( int Vindex );

    // Remove the items from index Vfirst through index Vlast-1
    void remove ( int Vfirst, int Vlast );

};

#endif

template <class T>
RubberArray<T>::RubberArray ( int Vindex )
    :_Vindex (Vindex)
{
    _Array = NULL;
    _len = 0;
    _alloc = 0;
}

template <class T>
RubberArray<T>::RubberArray ( const T* Array, unsigned s, int Vindex )
    : _Vindex(Vindex)
{
    _Array = NULL;
    _len = 0;
    _alloc = 0;

    for (unsigned i = 0; i < s; ++i)
    {
        append(Array[i]);
    }
}
//TODO: double check this
template <class T>
RubberArray<T>::RubberArray ( const RubberArray& ra)
{
    //setting _Array is not necessary but it also doesn't hurt
    _Array = NULL;
    _len = 0;
    _alloc = 0;

    for (unsigned i = 0; i < ra._len; ++i)
    {
        append(ra._Array[i]);
    }
}

template <class T>
RubberArray<T>::~RubberArray ( )
{
    delete [] _Array;
    _Array = NULL;
    _len = 0;
    _alloc = 0;
}

template <class T>
RubberArray<T>& RubberArray<T>::operator= ( const RubberArray<T>& ra)
{
    if (this != &ra)
    {
        if (_len != 0)
            delete [] _Array;
        _Vindex = ra._Vindex;
        _Array = NULL;
        _len = 0;
        _alloc = 0;
        for (unsigned i = 0; i < ra._len; ++i)
            append(ra._Array[i]);
    }
    return *this;
}

template <typename OS>
ostream& operator<< ( ostream& os, const RubberArray<OS>& ra)
{
    if (ra._len != 0)
    {
        os << ra._Array[0];
        for (unsigned i = 1; i < ra._len; ++i)
        {
            os << ", " << ra._Array[i];
        }
    }
    return os;
}
//TODO: double check this
template <typename OS>
ostream& operator<< ( ostream& os, const RubberArray<OS>* ra)
{
    if (ra->_len != 0)
    {
        os << ra->_Array[0];
        for (unsigned i = 1; i < ra->_len; ++i)
        {
            os << ", " << ra->_Array[i];
        }
    }
    return os;
}

template <class T>
T& RubberArray<T>::operator[] ( int Vindex )
{
    int Aindex = Vindex - _Vindex;
    if ( Aindex < 0 || Aindex >= _len)
    {
        cout << "ERROR : T& RubberArray<T>::operator[] ( int Vindex ) : at virtual index : " << Vindex << endl;
        exit(200);
    }
    return _Array[Aindex];
}
//TODO: double check this
template <class T>
const T& RubberArray<T>::operator[] ( int Vindex ) const
{
    int Aindex = Vindex - _Vindex;
    if ( Aindex < 0 || Aindex >= _len)
    {
        cout << "ERROR : const T& RubberArray<T>::operator[] ( int Vindex ) : at virtual index : "
             << Vindex << endl;
        exit(200);
    }
    return _Array[Aindex];
}

template <class T>
RubberArray<T> RubberArray<T>::operator( ) ( int Vfirst, int Vlast ) const
{
    //find actual indices in case of weird virt indices
    //this seems to work with negative indices
    int Afirst =  Vfirst - _Vindex;
    int Alast = Vlast - _Vindex;

    //if they enter inputs in the wrong order
    if (Afirst >= _len || Alast < 0)
    {
        cout << "ERROR : RubberArray<T> RubberArray<T>::operator() ( int Vfirst, int Vlast ) : \n\t"
             << "Vlast came before Vfirst\n";
    }

    //handle all other bad inputs
    if ( Afirst < 0 || Alast >= _len)
    {
        cout << "ERROR : RubberArray<T> RubberArray<T>::operator() ( int Vfirst, int Vlast ) : \n\tat first virtual index : "
             << Vfirst
             << "\n\tlast virtual index : " << Vlast << endl;
        exit(200);
    }
    //create a temp RubberArray to return as the sub-array
    RubberArray<T> temp;
    for (unsigned i = Afirst; i < Alast; ++i)
    {
        temp.append(_Array[i]);
    }

    return temp;
}

template <class T>
void RubberArray<T>::append ( const T& item)
{
    if (_len >= _alloc)
    {
        _alloc *= 2;
        ++_alloc;
        T* temp = new T[_alloc];

        for (unsigned i = 0; i < _len; ++i)
            temp[i] = _Array[i];
        if (_len != 0)
            delete [] _Array;
        _Array = temp;
    }
    _Array[_len++] = item;
}

template <class T>
void RubberArray<T>::append ( const RubberArray& ra)
{
    //we need a temp for appending to self
    //if not we will perpetually increment _len inside of append
    //which will result in an infinite loop
    RubberArray<T> temp(ra._Array,ra.length());

    for (unsigned i = 0; i < temp.length(); ++i)
    {
        append(temp._Array[i]);
    }
}

template <class T>
void RubberArray<T>::add ( int Vindex, const T& rt)
{
    int Aindex = Vindex - _Vindex;
    //check index
    if ( Aindex < 0 || Aindex >= _len)
    {
        cout << "ERROR : void RubberArray<T>::add ( int Vindex, const T& rt ) : at virtual index : "
             << Vindex << endl;
        exit(200);
    }
    //create temp based on the subarray from 0-Aindex
    RubberArray<T> temp(this->operator()(_Vindex,Vindex));
    //append the new element
    temp.append(rt);
    //add everything from the last element til the end
    for (int i = Aindex; i < _len; ++i)
    {
        temp.append(_Array[i]);
    }
    //set the virtual index for temp and set *this to temp to preserve the virtual index
    //between calls, without this calls to remove "clear" the user supplied virtual index
    temp._Vindex =_Vindex;
    *this = temp;
}

template <class T>
void RubberArray<T>::add ( const T& rt)
{
    add(_Vindex,rt);
}

template <class T>
void RubberArray<T>::remove ( )
{
    int Vindex = _Vindex + _len - 1;
    remove(Vindex);
}

template <class T>
void RubberArray<T>::remove ( int Vindex )
{
    int Aindex = Vindex - _Vindex;
    if ( Aindex < 0 || Aindex >= _len)
    {
        cout << "ERROR : void RubberArray<T>::remove ( int Vindex ) : at virtual index : " << Vindex << endl;
        exit(200);
    }
    RubberArray<T> temp(_Vindex);
    for (unsigned i = 0; i < _len; ++i)
    {
        if (i != Aindex)
            temp.append(_Array[i]);
    }
    //set the virtual index to preserve the virtual index between calls
    temp._Vindex = _Vindex;
    *this = temp;

}

template <class T>
void RubberArray<T>::remove ( int Vfirst, int Vlast )
{
    int Afirst =  Vfirst - _Vindex;
    int Alast = Vlast - _Vindex;

    for (unsigned i = Afirst; i < Alast; ++i)
    {
        remove(Vfirst);   //this version of remove takes a virtual index
    }
}
