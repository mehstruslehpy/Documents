///*place student header here */
#include <iostream>
#include "RubberArray.h"

using namespace std;

int main()
{
    int a[] = {1,2,3,123,5,6,7,8,9,10,11,12,13,14,15,16};
    int b[] = {7,5,4,123};

    RubberArray<int> test1(a,16);
    RubberArray<int> test2(b,4);
    RubberArray<int> test3;

    cout << "Test3: \n";
    for (unsigned i = 0 ; i < 13; ++i)
    {
        test3.append(i);
        cout << test3 << endl;
    }
    test1 = test1;
    test1 = test2;

    cout << "Test1: ";
    cout << test1 << endl;
    cout << "Test2: ";
    cout << test2 << endl;
    cout << "Test2 (again): ";
    for (int i = 0; i < int(test2.length()) ; ++i)
    {
        cout << test2[i] << ", ";
    }
    cout << endl;

    test1.remove(2);
    cout << "Test1 (again): ";
    cout << test1 << endl;

    /*
    test1.remove(-2);
    cout << "Test1(again again): ";
    cout << test1 << endl;
    */

    RubberArray<int> test4(test2);
    cout << "test4: " << test4 << endl;

    RubberArray<int> *ptest1;
    ptest1 = &test2;
    cout << "ptest1: " << ptest1 << endl;
    ptest1 = &test3;
    cout << "ptest1: " << ptest1 << endl;

    //test the const version of operator[] also some vindex testing
    const RubberArray<int> ctest1(a,16,-3);
    cout << "ctest1: ";
    for (int i = -3; i < int(ctest1.length()-3) ; ++i)
    {
        cout << ctest1[i] << ", ";
    }
    cout << endl;

    RubberArray<int> subtest(ctest1(3,10));
    cout << "subtest: "<< subtest << endl;

    cout << "TEST1: " << test1 << endl;
    cout << "TEST3: " << test3 << endl;
    test1.append(ctest1);
    cout << "test1: "<< test1 << endl;

    RubberArray<int> nrtest1(a,16,-3);
    cout << "nrtest1: " << nrtest1 << endl;
    nrtest1.remove(-3,0);
    cout << "nrtest1: " << nrtest1 << endl;
    nrtest1.remove();
    cout << "nrtest1: " << nrtest1 << endl;

    cout << "test4: " << test4 << endl;
    test4.remove();
    cout << "test4: " << test4 << endl;

    cout << "nrtest1: " << nrtest1 << endl;
    nrtest1.add(0,0);
    cout << "nrtest1: " << nrtest1 << endl;
    nrtest1.add(-2,555);
    cout << "nrtest1: " << nrtest1 << endl;
    nrtest1.add(1337);
    cout << "nrtest1: " << nrtest1 << endl;

    return 0;
}
