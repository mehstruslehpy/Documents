/************************
William Vanskike
CISP 400 MW 5:30 pm
Rubber Array
November 18, 2017
************************/

#include <iostream>
#include <fstream>
#include "RubberArray.h"

using namespace std;

int main()
{
    try
    {
        int a[] = {1,2,3,123,5,6,7,8,9,10,11,12,13,14,15,16};
        int b[] = {7,5,4,123};
        int c[] = {-8,15,1010,1337,98,5,1,3,378,276,32,54,14,10,99};

        //test each constructor
        RubberArray<int> test1(a,16);
        RubberArray<int> test2(b,4,-3);
        RubberArray<int> test3(-7);
        RubberArray<int> test4;

        //test normal printing
        cout << "PRINT TESTS:" << endl;
        cout << "\ttest1: "<< test1 << endl;
        cout << "\ttest2: "<< test2 << endl;
        cout << "\ttest3: "<< test3 << endl;
        cout << "\ttest4: "<< test4 << endl;

        //test operator=
        cout << "TEST operator=" << endl;
        cout << "\ttest1=test2=test3=test4:\n\t" << (test4=test3=test2=test1) << endl;
        cout << "\ttest4:" << (test4) << endl;

        //test the other ostream
        RubberArray<int> *rptr = &test4;
        cout << "TEST ostream& operator<< ( ostream&, const RubberArray<OS>* )" << endl;
        cout << "*rptr = test4: " << rptr << endl;


        //test iterative prints/looping/indexing
        cout << "NEGATIVE VINDEX TESTS: rubarr[VINDEX to SIZE+VINDEX]: \n\t";
        int SIZE = 13;
        int VINDEX = -4;
        RubberArray<int> test5(c,SIZE,VINDEX);
        for (int i = VINDEX; i < SIZE+VINDEX; ++i)
        {
            cout << test5[i] << "  ";
        }
        cout << endl;
        cout <<"\ttest5: " << test5 << endl;

        //test iterative prints/looping/indexing
        cout << "NEGATIVE VINDEX TESTS (const version): rubarr[VINDEX to SIZE+VINDEX]: \n\t";
        SIZE = 15;
        VINDEX = -444;
        const RubberArray<int> ctest(a,SIZE,VINDEX);
        for (int i = VINDEX; i < SIZE+VINDEX; ++i)
        {
            cout << ctest[i] << "  ";
        }
        cout << endl;
        cout << "\tctest: " << ctest << endl;
        //cout << ctest(-444,-429)<< endl;
        //subarray tests
        RubberArray<int> test7(c,8,-44);
        cout << "SUBARRAY TESTS:\n";
        cout << "\ttest1(3,7): " << test1(3,7);
        cout << "\n\ttest7:" << test7;
        cout << "\n\ttest7(-43,-38): " << test7(-43,-38);
        //cout << "\n\ttest7(-43,-38): " << test7(-38,-43);
        cout << "\n\ttest1(7,15): " << test1(7,15) << endl;
        cout << "\ttest1(0,3): " << test1(0,3) << endl;

        cout << "\ttest7(all): " << test7 << endl;
        cout << "\ttest7(-40,-37): " << test7(-40,-37) << endl;
        //cout << test1(11,10) << endl;
        //cout << "\n\ttest1(7,20): " << test1(7,20) << endl;

        //append tests
        cout << "APPEND TESTS:";
        int d[] = {1,0,-1,1,-0,1,-2};
        RubberArray<int> test8(d,7,3);
        cout << "\n\ttest8(before): "<< test8;
        test8.append(test8);    //append to self
        cout << "\n\ttest8(after): "<< test8;

        cout << "\n\ttest7(before): "<< test7;
        test7.append(test1(5,8)); // pos rub to neg rub also append a sub rub
        cout << "\n\ttest7(after): "<< test7;

        test1 = test2(0,2); //this is a good test and will make printing easier
        cout << "\n\ttest1(before): "<< test1;
        test1.append(test7);    //append a neg rub to a pos rub
        cout << "\n\ttest1(after): "<< test1;

        //append in a short loop
        RubberArray<int> test9(c,3,-17);
        cout << "\n\ttest9(before): "<< test9;
        for (int i = 0; i < 5; ++i)
        {
            test9.append(i);
        }
        cout << "\n\ttest9(before): "<< test9 << endl;

        //add() tests
        cout << "ADD TESTS:\n\t";
        test5.remove();
        test5.remove();
        cout << "test5(before): " << test5 << endl;
        SIZE = 13;
        VINDEX = -4;
        for (int i = 0; i < 2; ++i)
        {
            test5.add(3+i+VINDEX,i);
        }
        cout << "\ttest5(after): " << test5 << endl;
        cout << "\ttest5(before): " << test5 << endl;
        test5.add(8,234);
        test1.add(12,-55);
        cout << "\ttest5(after): " << test5 << endl;
        cout << "\n\ttest1(before): " << test1 << endl;
        for (int i = 5; i < 7; ++i)
        {
            test1.add(i);
        }
        cout << "\ttest1(after): " << test1 << endl;;

        //TODO: Check removes
        //REMOVE TESTS
        cout << "REMOVE TESTS:\n\t";
        cout << "test5(before): " << test5 << endl; //single elem default remove with vindex of -4
        test5.remove();
        test5.remove();
        cout << "\ttest5(after): " << test5 << endl;
        cout << "\ttest5(before): " << test5 << endl; //single elem remove with vindex of -4 and specified index of -2
        test5.remove(-2);
        test5.remove(-2);
        test5.remove(-4);
        cout << "\ttest5(after): " << test5 << endl;
//        int i = -4;
//        RubberArray<int> temp(test5);
//        while (1)
//        {
//            cout << i << ": " << temp << endl;
//            temp.remove();
//            i += 1;
//        }
        cout << "\ttest1(before): " << test1 << endl; //single elem default remove
        test1.remove();
        test1.remove();
        cout << "\ttest1(after): " << test1 << endl;
        cout << "\ttest1(before): " << test1 << endl; //single elem remove with specified index of 2
        test1.remove(2);
        test1.remove(2);
        test1.remove(10);
        cout << "\ttest1(after): " << test1 << endl;
        cout << endl;
        cout << "\ttest1(before): " << test1 << endl; //ranged remove
        test1.remove(2,5); //2 to 4 will be removed
        cout << "\ttest1(after): " << test1 << endl;
        cout << endl;
        cout << "\ttest5(before): " << test5 << endl; //ranged remove
        test5.remove(-3,4); //-4 to 3 will be removed
        cout << "\ttest5(after): " << test5 << endl;

        int MAX_SIZE = 9;
        int V_INDEX = -2;
        char ca[] = { 'D','E','A','D','_','B','E','E','F'};
        ofstream fout("Test.txt", ios::out | ios::binary | ios::trunc);
        //string mystr = "HEYDUDEWHATSUP!";
        RubberArray<char> write_ra(ca,MAX_SIZE,V_INDEX);
        //RubberArray<char> write_ra(mystr.c_str(),mystr.length()+1,-5);
        RubberArray<char> read_ra;

        write_ra.write(fout);
        cout << "write_ra: " << write_ra << endl;
        fout.close();
        ifstream fin("Test.txt", ios::in | ios::binary);
        read_ra.read(fin);
        cout << "read_ra:  " << read_ra << endl;

        fout.close();
        fin.close();

        //test backwards removal first > last
        //read_ra.remove(-2,0);
        read_ra.remove(6);
        cout << "remove: "<< read_ra << endl;

        RubberArray<int> except_test(a,16,0);
        //except_test[18] = 0;
        cout << except_test << endl;
        cout << except_test[15] << endl;
        return 0;
    }
    catch (unsigned a)
    {
        cout << "Caught exception: ";
        cout << a << endl;
    }
}
