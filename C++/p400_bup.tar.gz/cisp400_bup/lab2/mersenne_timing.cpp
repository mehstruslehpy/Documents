/************************
William Vanskike
CISP 400 MW 5:30 pm
Mersenne Numbers
August 30, 2017
************************/

#include <iostream>

#include <ctime>
#include <sys/timeb.h>

double TIME ( void );

//below main
// returns time in milliseconds since January 1 1970.
double TIME ( void )
{
    struct timeb t;
    ftime(&t);
    return ( ( (1000.0 * t.time) + t.millitm ) );
}

bool IsPrime( unsigned long long n );
//returns true if n is prime
unsigned long long pow2( unsigned n );
// returns 2n
unsigned long long Mersenne( unsigned n );
//returns the nth Mersenne number
unsigned long long Sqrt ( unsigned long long n );
//returns the square root of n as an integer
bool LucasLehmer ( unsigned long long n );
//returns true if the nth Mersenne number is prime. Uses the Lucas-Lehmer method

using namespace std;

int main()
{
    double start = 0;
    double end = 0;

/*
    cout << "pow2: " << endl;
    for (int i = 0; i < 25; i++)
    {
        cout << "\t2^"<< i << ": " << pow2(i) << endl;
    }
*/
    cout << "Times in the interval [1,61]:" << endl;
    start = TIME();
    cout << "LucasLehmer: " << endl;
    for (unsigned long long i = 1; i <= 61; i++)
    {      

        //cout << "\t2^"<< i << "-1: " << LucasLehmer(i) << endl;
        LucasLehmer(i);
    }
    end = TIME();
    cout << "\tstart: " << start << endl;
    cout << "\tend: " << end << endl;
    cout << "\ttotal-time:" << end - start << endl;

    start = TIME();
    cout << "IsPrime: " << endl;
    for (unsigned long long i = 1; i <= 61; i++)
    {
        //cout << "\t"<< i << ": " << IsPrime(Mersenne(i)) << endl;
        IsPrime(Mersenne(i)); 
    }
    end = TIME();
    cout << "\tstart: " << start << endl;
    cout << "\tend: " << end << endl;
    cout << "\ttotal-time:" << end - start << endl;

/*
    cout << "Sqrt: " << endl;
    for (int i = 1; i < 50; i++)
    {
        cout << "\t"<< i << ": " << Sqrt(i) << endl;
    }
*/
/*
    cout << "Mersenne: " << endl;
    for (int i = 1; i < 50; i++)
    {
        cout << "\t"<< i << ": " << Mersenne(i) << endl;
    }
*/
    return 0;
}

bool IsPrime( unsigned long long n )
{
    if ( n <= 2) return true;

    for ( unsigned long long i = 2; i < (n/2); i++)
    {
        if ( n % i == 0 )
        {
            return false;
        }
    } 
    return true;
}

//this was my original version
/*
unsigned long long pow2( unsigned n )
{
    unsigned long long acc = 1;
    
    for (unsigned long long i = 0; i < n; i++)
    {
        acc *= 2;
    }

    return acc;
}
*/
//this version from class causes a floating point exception for some reason
unsigned long long pow2( unsigned n )
{
    return 1ULL << n;
}


unsigned long long Mersenne( unsigned n )
{
    return (pow2(n) - 1);
}

//This is my version from before class
/*
unsigned long long Sqrt ( unsigned long long n )
{
    unsigned long long saved = 0;
    unsigned long long iter = 1;

    while ( iter <= n)
    {
        if (iter * iter <= n)
        {
            saved = iter;
        }
        iter++;   
    }

    return saved;
}
*/

//this is one of the methods shown in class
unsigned long long Sqrt ( unsigned long long n )
{
    unsigned long long retVal = 1;

    while (retVal * retVal <= n) ++retVal;
    --retVal;

    return retVal;
}

bool LucasLehmer( unsigned long long n )
{
    if ( n <= 2) return true;

    unsigned long long s = 4;
    unsigned long long M = pow2(n) - 1;

    for (unsigned long long i = 0; i < (n-2); i++)
    {
        s = ((s * s) - 2) % M;
    }
    
    if (s == 0)
    {
        return true;
    }
    else
    {
        return false;
    }
}
