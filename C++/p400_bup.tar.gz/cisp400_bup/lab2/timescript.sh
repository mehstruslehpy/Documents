#!/bin/bash

echo "mersenne_bruteforce.o"
time ./mersenne_bruteforce.o | grep real
echo "mersenne_lucas.o"
time ./mersenne_lucas.o | grep real
#echo "mersenne.o"
#time ./mersenne.o | grep real
#echo "mersenne_timing.o"
#time ./mersenne_timing.o | grep real
echo "prime_bruteforce.o"
time ./prime_bruteforce.o | grep real
