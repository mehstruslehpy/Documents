/************************
William Vanskike
CISP 400 MW 5:30 pm
Vector Graphics
September 11, 2017
************************/

#include "Vector.h"
#include <iostream>

using namespace std;

int main()
{

    //this will test all three constructors
    Vector input;
    Vector v1;
    Vector v2(1,2,3);
    Vector v3(4,5);
    Vector v4(v2);
    Vector v5(1,1,1);
    Vector ortho1(1,3,2);   //these are all orthogonal
    Vector ortho2(3,-1,0);
    Vector ortho3(1,3,-5);
    Vector cross1(2,3,4);   //cross prod of these will be <-3,6,-3>
    Vector cross2(5,6,7);
    Vector zero(0,0,0);
    Vector cs1(1,0,0);   //angle between these is 90 deg cos(90) = 0 
    Vector cs2(0,1,0);   

    cout << "Starting vectors:\n";
    cout << "v1: "<< v1 << endl; 
    cout << "v2: "<< v2 << endl; 
    cout << "v3: "<< v3 << endl; 
    cout << "v3: "<< v3 << endl; 
    cout << "v4: "<< v4 << endl;
    cout << "v5: "<< v5 << endl;
    cout << "ortho1: "<< ortho1 << endl;
    cout << "ortho2: "<< ortho2 << endl;
    cout << "ortho3: "<< ortho3 << endl;
    cout << "cross1: "<< cross1 << endl;
    cout << "cross2: "<< cross2 << endl;
    cout << endl;

    cout << "Arithmetic and assignment operators:\n";
    cout << "v1 += v2: " << (v1+=v2) << endl;
    cout << "v1 -= v4: " << (v1-=v4) << endl;
    cout << "v1 += v5: " << (v1+=v5) << endl;
    cout << "v1 *= 26: " << (v1*=26) << endl;
    cout << "v1 /= 13: " << (v1/=13) << endl;
    cout << "v1 = v4: " << (v1=v4) << endl;
    cout << endl;

    cout << "Arithmetic non-assignment operators\n";
    cout << "v1: " << v1 << endl; 
    cout << "v1 + v2: " << (v1+v2) << endl;
    cout << "v1 - v2: " << (v1-v2) << endl;
    cout << "v1 * 2: " << (v1 * 2) << endl;
    cout << "2 * v1: " << (2 * v1) << endl;
    cout << "v1 / 2: " << (v1 / 2) << endl;
    cout << "v1: " << v1 << endl; 
    cout << endl;

    cout << "Boolean operators:\n";
    cout << "v1 == v2: " << (v1 == v2) << endl;
    cout << "v1 == v3: " << (v1 == v3) << endl;
    cout << "v1 != v2: " << (v1 != v2) << endl;
    cout << "v1 != v3: " << (v1 != v3) << endl;
    cout << "v1.parallel(v2): " << (v1.parallel(v2)) << endl;
    cout << "v1.parallel(v3): " << (v1.parallel(v3)) << endl;
    cout << "ortho1.perpendicular(ortho2): " << ortho1.perpendicular(ortho2) << endl;
    cout << "ortho2.perpendicular(ortho3): " << ortho2.perpendicular(ortho3) << endl;
    cout << "ortho3.perpendicular(ortho1): " << ortho3.perpendicular(ortho1) << endl;
    cout << "ortho1.perpendicular(ortho1): " << ortho1.perpendicular(ortho1) << endl;
    cout << "ortho1.perpendicular(v1): " << ortho1.perpendicular(v2) << endl;
    cout << endl;
    
    cout << "Other operators:\n";
    cout << "v1.dotProduct(v2): " << v1.dotProduct(v2) << endl;
    cout << "cross1.crossProduct(cross2): " << cross1.crossProduct(cross2) << endl;
    cout << "-v1: " << -v1 << endl;
    cout << "+v1: " << +v1 << endl;
    cout << "cs1.dotProduct(cs2): " << cs1.dotProduct(cs2) << endl;
    cout << endl;

    cout << "Simple errors:\n";
    cout << "Normalizing a zero vector: " << endl; 
    zero.normalize();
    cout << "v1 / 0: " << (v1/0) << endl;   //these print because (v1/0) and (v1/=0) still return values to cout
    cout << "v1 /= 0: " << (v1/=0) << endl;
    cout << endl;

    cout << "Enter a vector as <x, y, z>:\n";
    cout << "Starting vector: " << input << endl;
    cin >> input;
    cout << "output: " << input << endl;
    cin >> input;
    cout << "output: " << input << endl;
    return 0;
}
