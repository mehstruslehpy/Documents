/************************
William Vanskike
CISP 400 MW 5:30 pm
Vector Graphics
September 11, 2017
************************/
#ifndef VECTOR_H_WPV_
#define VECTOR_H_WPV_
#include <iostream>
#include <cmath>

using namespace std;

class Vector
{
    double _x;
    double _y;
    double _z;
    //private member functions as needed
    public:
    Vector( );
    Vector( double X, double Y, double Z=0 );
    Vector ( const Vector& );
    ~Vector();
    //void display() const; //
    //void add(const Vector&);
    //void sub(const Vector&);
    //void mult(double);
    //void div(double);
    Vector& operator= (const Vector&);
    Vector& operator+= (const Vector&);
    Vector& operator-= (const Vector&);
    Vector& operator*= (double);
    Vector& operator/= (double);
    friend ostream& operator<< (ostream&, const Vector&);  // <_x, _y, _z>
    friend istream& operator>> (istream&, Vector&);
    // operator>> must read what operator<< writes
    Vector operator+ (const Vector&) const; //[1]
    Vector operator- (const Vector&) const;
    Vector operator* (double) const;
    friend Vector operator* (double, const Vector&);
    Vector operator/ (double) const;
    bool operator== (const Vector&) const;
    bool operator!= (const Vector&) const;
    bool parallel(const Vector&)const;
    bool perpendicular(const Vector&)const;
    void normalize();
    double length() const;
    double dotProduct ( const Vector& )const;
    Vector crossProduct( const Vector& ) const;
    Vector operator- () const;
    Vector operator+ () const;
};
#endif 
