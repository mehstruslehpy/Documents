/************************
  William Vanskike
  CISP 400 MW 5:30 pm
  Vector Graphics
  September 11, 2017
 ************************/

#include "Vector.h"

using namespace std; //you mentioned we should do this

//default constructor
Vector::Vector()
{
    _x = 0.0;
    _y = 0.0;
    _z = 0.0;
}
//constructor for v(x,y,z)
Vector::Vector(double X, double Y, double Z)
{
    _x = X;
    _y = Y;
    _z = Z;
}

//copy constructor for v(v1)
Vector::Vector ( const Vector& v)
: _x(v._x), _y(v._y), _z(v._z)
{}

//empty destructor
Vector::~Vector()
{}

//lhs = rhs
Vector& Vector::operator= (const Vector& rhs) //not exactly sure how he wants us to overload this
{
    if (this == &rhs) return *this;
    _x = rhs._x;
    _y = rhs._y;
    _z = rhs._z;
    return *this;   
}

//lhs += rhs
Vector& Vector::operator+= (const Vector& rhs)
{
    _x += rhs._x;
    _y += rhs._y;
    _z += rhs._z;
    return *this;
}

//lhs -= rhs
Vector& Vector::operator-= (const Vector& rhs)
{
    _x -= rhs._x;
    _y -= rhs._y;
    _z -= rhs._z;
    return *this;
}

//lhs *= rhs
Vector& Vector::operator*= (double rhs)
{
    _x *= rhs;
    _y *= rhs;
    _z *= rhs;
    return *this;
}

//lhs /= rhs
//last time I used exit() so this time I will just avoid div by zero
Vector& Vector::operator/= (double rhs)
{
    if(rhs == 0) //check for div by zero
    {
        cout << "Div by zero error!" << endl;
        return *this;
    }
    _x /= rhs;
    _y /= rhs;
    _z /= rhs;
    return *this;
}

//performs stream << op this is also a friend function
ostream& operator<< (ostream& osm, const Vector& op) 
{             
    osm << "<" << op._x << ", " << op._y << ", " << op._z << ">";
    return osm;
}

//performs stream >> op this is also a friend function
istream& operator>> (istream& ism, Vector& op)
{
    char c;
    double X,Y,Z;
    
    //    <    X    ,    Y    ,    Z    >
    ism >> c >> X >> c >> Y >> c >> Z >> c;

    op = Vector(X,Y,Z);
    return ism;
}

//x + y returns the result without permanent assignment
Vector Vector::operator+ (const Vector& rhs) const
{
    return Vector(*this) += rhs;
}

//x - y returns the result without permanent assignment
Vector Vector::operator- (const Vector& rhs) const
{
    return Vector(*this) -= rhs;
}

//x * y returns the result without permanent assignment
Vector Vector::operator* (double rhs) const
{
    return Vector(*this) *= rhs;
}

//this is the friend version
//x * y returns the result without permanent assignment
Vector operator* (double lhs, const Vector& rhs)
{
    return Vector(rhs) *= lhs;
}

//x / y returns the result without permanent assignment
Vector Vector::operator/ (double rhs) const
{
    return Vector(*this) /= rhs;
}

//returns true if v == v1
bool Vector::operator== (const Vector& rhs) const
{
    return (_x == rhs._x && _y == rhs._y && _z == rhs._z);
}

//returns true if v != v1
bool Vector::operator!= (const Vector& rhs) const
{
    return !(*this == rhs);
}

bool Vector::parallel(const Vector& V)const   
{
    Vector v1 = *this;
    Vector v2 = V;
    v2.normalize();
    v1.normalize();

    return fabs(v1.dotProduct(v2)) >= 0.9999999999;
}

bool Vector::perpendicular(const Vector& V)const
{
   Vector v1 = *this;
   Vector v2 = V;
   v1.normalize();
   v2.normalize();
   
   return fabs(v1.dotProduct(v2)) <= 0.000000001;
}

//this should normalize if done correctly if done on a zero vector it should print an error
//and either do nothing or exit
void Vector::normalize()
{
    //div(length());
    operator/=(length());
}

//returns the length of a vector
double Vector::length()const
{
    return sqrt((_x * _x)+(_y * _y)+(_z * _z));
}

double Vector::dotProduct ( const Vector& rhs)const
{
    return (_x * rhs._x) + (_y * rhs._y) + (_z * rhs._z);
}

Vector Vector::crossProduct( const Vector& rhs) const
{
    
    return Vector(_y * rhs._z - _z * rhs._y,
                  -_x * rhs._z + _z * rhs._x,  
                  _x * rhs._y - _y * rhs._x);
}

//x = -x
Vector Vector::operator- () const
{
    return *this * -1;
}

//x = +x
Vector Vector::operator+ () const
{
    return *this;
}
