/************************
William Vanskike
CISP 400 MW 5:30 pm
Vector Graphics
September 11, 2017
************************/

#ifndef VECTOR_H_WPV   
#define VECTOR_H_WPV
#include <iostream>
#include <cmath>  
//you said we could use exit() from here to handle div by zero
#include <stdlib.h>

using namespace std;

class Vector
{
    double _x;
    double _y;
    double _z;
public:
    Vector();
    Vector(double X, double Y, double Z = 0.0);
    void display() const; // <_x, _y, _z>
    void add(const Vector&);
    void sub(const Vector&);
    void mult(const double&);
    void div(const double&);
    void normalize();
    double length()const;
};
#endif 
