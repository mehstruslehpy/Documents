/************************
William Vanskike
CISP 400 MW 5:30 pm
Vector Graphics
September 11, 2017
************************/

#include "Vector.h"

using namespace std; //you mentioned we should do this

Vector::Vector()
{
    _x = 0.0;
    _y = 0.0;
    _z = 0.0;
}
Vector::Vector(double X, double Y, double Z)
{
    _x = X;
    _y = Y;
    _z = Z;
}
void Vector::display() const
{
    cout << "<" << _x << ", " << _y << ", " \
         << _z << ">";
}
void Vector::add(const Vector& v)
{
    _x += v._x;
    _y += v._y;
    _z += v._z;
}
void Vector::sub(const Vector& v)
{
    _x -= v._x;
    _y -= v._y;
    _z -= v._z;
}
//you said you didn't really care if I check for overflow or not
//so I left it in because I thought it was neat.
void Vector::mult(const double& sc)
{
    double temp = 0.0;

    temp = _x * sc;
    if (!isfinite(temp)) 
    {
        cout << "Result of operation is not a number\n";
        exit(EXIT_FAILURE); //EXIT_FAILURE is a nonzero macro from cstdlib
    }
    _x = temp;

    temp = _y * sc;
    if (!isfinite(temp))
    {
        cout << "Result of operation is not a number\n";
        exit(EXIT_FAILURE); 
    }
    _y = temp;

    temp = _z * sc;
    if (!isfinite(temp))
    {
        cout << "Result of operation is not a number\n";
        exit(EXIT_FAILURE); 
    }
    _z = temp;
}

void Vector::div(const double& sc)
{
    if (sc == 0)
    {
        cout << "Division by zero error\n";
        exit(EXIT_FAILURE); 
    }
    double temp = 0.0;

    temp = _x / sc;
    if (!isfinite(temp))
    {
        cout << "Result of operation is not a number\n";
        exit(EXIT_FAILURE); 
    }
    _x = temp;

    temp = _y / sc;
    if (!isfinite(temp))
    {
        cout << "Result of operation is not a number\n";
        exit(EXIT_FAILURE); 
    }
    _y = temp;

    temp = _z / sc;
    if (!isfinite(temp))
    {
        cout << "Result of operation is not a number\n";
        exit(EXIT_FAILURE); 
    }
    _z = temp;
}

//this was the version you went over in class
//my previous version was more clunky
void Vector::normalize()
{
    div(length());
}

double Vector::length()const
{
    return sqrt((_x * _x)+(_y * _y)+(_z * _z));
}

