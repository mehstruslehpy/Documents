/************************
William Vanskike
CISP 400 MW 5:30 pm
Vector Graphics
September 11, 2017
************************/

#include "Vector.h"
#include <iostream>

using namespace std;

int main()
{

    //this will test all three constructors
    Vector v1;
    Vector v2(1,2,3);
    Vector v3(4,5);

    //test v.display()
    cout << "Testing display(): \n";
    cout << "\tv1: ";
    v1.display();
    cout << " v2: ";
    v2.display();
    cout << " v3: ";
    v3.display();
    cout << endl;

    //test v.add
    cout << "Testing add(): \n";
    cout << "\tv2 + v3 = ";
    v2.add(v3);
    v2.display();
    cout << endl;

    //test v.sub
    cout << "Testing sub(): \n";
    cout << "\tv2 - v3 = ";
    v2.sub(v3);
    v2.display();
    cout << endl;

    //test v.mul
    cout << "Testing mult(): \n";
    cout << "\tv2 * 13 = ";
    v2.mult(13);
    v2.display();
    cout << endl;

    //test v.div
    cout << "Testing div(): \n";
    cout << "\tv2 / 13 = ";
    v2.div(13);
    v2.display();
    cout << endl;

    //test v.length
    cout << "Testing length(): \n";
    cout << "\t|v2| = " << v2.length();
    cout << endl;

    //test v.normalize
    cout << "Testing normalize(): \n";
    cout << "\tv2: ";
    v2.normalize();
    v2.display();
    cout << endl;
    cout << endl;

/*
    The following tests are more interesting 
*/

    cout << "Iterative multiplication test:\n";
    Vector iv1(1,1,1);
    Vector tempv(1,1,1);

    //previously I tested this with for (double i = 1000; i > -1000; i--) which fails due to overflow
    for (double i = 1; i < 10; i++)
    {
        iv1.display();
        cout << endl;
        iv1.mult(i);
    }
    cout << endl;
    cout << endl;

    cout << "Iterative division test:\n";
    iv1.sub(iv1); //reset v1 to <1,1,1>
    iv1.add(tempv); 

    //previously I tested this with for (double i = 1000; i > -1000; i--) which also fails but due to div by zero
    //as well as having an overflow (underflow?) issue, if you divide for long enough in the loop above eventually 
    //your vector becomes <0,0,0>
    for (double i = 1; i < 10; i++)
    {
        iv1.display();
        cout << endl;
        iv1.div(i);
    }
    cout << endl;
    cout << endl;


    cout << "Iterative length and normalize test (variation 1):\n";
    iv1.sub(iv1); //reset v1 to <1,1,1>
    iv1.add(tempv); 
    
    //stdlib includes rand this seemed like an interesting way to test my length and normalize functions
    //you also mentioned you didn't particularly care what we did in this file so long as you could see
    //we tested stuff
    srand(time(NULL));
    
    for (double i = 1; i < 10; i++) //at one point I tried testing up to 1000000000 but no errors happened and I got bored waiting
    {                               //for it to finish
        double random = (double) rand();

        cout << "Random number: " << random << endl; 
        tempv.mult(random); //set tempv to something interesting
        iv1.add(tempv);

        cout << "Starting vector: ";
        iv1.display();
        cout << endl;

        cout << "Vector length: " << iv1.length() << endl;

        iv1.normalize();
        cout << "Normalized vector: ";
        iv1.display();
        cout << endl;

        iv1.sub(iv1);
        tempv.div(random);  //reset tempv to 1's
        iv1.add(tempv);
    }
    cout << endl;
    cout << endl;

    //the last test doesn't do a good job of checking normalization
    //here's something even more random
    cout << "Iterative length and normalize test (variation 2):\n";
    Vector* pvec;
    double random1 = 0.0;
    double random2 = 0.0;
    double random3 = 0.0;
     
    for (int i = 0; i < 10; i++)
    {
        random1 = (double) rand();
        random2 = (double) rand();
        random3 = (double) rand();
        pvec = new Vector(random1,random2,random3);
        
        cout << "Starting vector: ";
        pvec->display();
        cout << endl;

        cout << "Vector length: " << pvec->length() << endl;

        pvec->normalize();
        cout << "Normalized vector: ";
        pvec->display();
        cout << endl;

        delete pvec;
    }
    cout << endl;
    
    return 0;
}
