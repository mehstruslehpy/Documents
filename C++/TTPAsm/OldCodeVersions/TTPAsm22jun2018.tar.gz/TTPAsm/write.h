#ifndef _WRITE_H
#define _WRITE_H
#include "common.h"
using namespace std;
string getOutStr(string& str, unsigned int lineno);
void instrError(string& str, unsigned int lineno);
#endif
