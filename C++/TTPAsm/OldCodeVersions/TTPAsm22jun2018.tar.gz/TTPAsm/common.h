#ifndef _COMMON_H_
#define _COMMON_H_
#include <iostream>
#include <fstream>
#include <iomanip>
#include <vector>
#include <string>
#include <memory>
#include <algorithm>
#include <map>
#include <regex>
#endif
