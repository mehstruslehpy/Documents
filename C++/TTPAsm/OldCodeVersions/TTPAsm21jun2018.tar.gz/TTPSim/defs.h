#ifndef _DEFS_H_
#define _DEFS_H_
#include "RegBank/RegBank.h"
#include "Ram/Ram.h"
#include "IO/IO.h"
#include "CompSim.h"
#endif
