﻿#include <iostream>
#include <sstream>
#include <string>
#include <cstdlib>
#include <cmath>

using namespace std;

// Headers
string toString (double);
int toInt (string);
double toDouble (string);

int main()
{
    // At 49 the output is rounded to 1 which makes me kinda wish we had a type that gave us more decimal places. In c++ the rounding happens quite a bit earlier than 49..
    double sum;
    
    sum = 0;
    int n;
    int i;
    
    cout << "Input a number: " << endl;
    cin >> n;
    for (i = 1 ; i <= n ; i += 1)
    {
        sum = pow(((double) 1 / 2), i) + sum;
    }
    cout << sum << endl;
}

// The following implements type conversion functions.

string toString (double value)  //int also
{
    stringstream temp;
    temp << value;
    return temp.str();
}

int toInt (string text)
{
    return atoi(text.c_str());
}

double toDouble (string text)
{
    return atof(text.c_str());
}
