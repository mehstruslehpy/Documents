﻿#include <iostream>
#include <sstream>
#include <string>
#include <cstdlib>
#include <cmath>

using namespace std;

// Headers
string toString (double);
int toInt (string);
double toDouble (string);

int main()
{
    double lg;
    double sm;
    double in;
    
    cout << "Enter a series of a numbers" << endl;
    cout << "Press enter between each entry" << endl;
    cout << "Enter -99 to quit" << endl;
    cin >> in;
    lg = in;
    sm = in;
    if (in != -99)
    {
        while (in != -99)
        {
            if (in > lg)
            {
                lg = in;
            }
            if (in < sm)
            {
                sm = in;
            }
            cin >> in;
        }
        cout << "Largest input: " << lg << " Smallest input: " << sm << endl;
    }
    else
    {
        cout << "Largest input: Smallest input:" << endl;
    }
}

// The following implements type conversion functions.

string toString (double value)  //int also
{
    stringstream temp;
    temp << value;
    return temp.str();
}

int toInt (string text)
{
    return atoi(text.c_str());
}

double toDouble (string text)
{
    return atof(text.c_str());
}
