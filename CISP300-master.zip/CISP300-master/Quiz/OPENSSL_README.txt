I figured out a way to install openssl binaries on windows just get them here:
I chose v1.10 the 30mb one then you install it to the windows system directory because I think that is in your PATH by default. After that the attached file will run perfectly. (at least it does on my version of windows 7)
https://slproweb.com/products/Win32OpenSSL.html