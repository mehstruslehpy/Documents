﻿#include <iostream>
#include <sstream>
#include <string>
#include <cstdlib>
#include <cmath>
#include <ctime>

using namespace std;

// Headers
string toString (double);
int toInt (string);
double toDouble (string);

void determineWinner(int, int);
void displayChoice(int);
int getComputerChoice();
int getUserChoice();

int main()
{
    srand(time(0));   //Seed random number generator
    
    int userChoice;
    int compChoice;
    
    userChoice = 0;
    compChoice = 0;
    cout << "Welcome to rock paper scissors!" << endl;
    cout << "Enter 1 for rock 2 for paper and 3 for scissors or 4 to exit" << endl;
    while (userChoice != 4)
    {
        determineWinner(userChoice, compChoice);
        if (userChoice != 0)
        {
            cout << "Starting a new round..." << endl;
        }
        userChoice = getUserChoice();
        if (userChoice != 4)
        {
            compChoice = getComputerChoice();
            displayChoice(compChoice);
        }
    }
    cout << "Exitting... See ya later!" << endl;
}

void determineWinner(int cchoice, int uchoice)
{
    if (cchoice == 0)
    {
        // for the initial case of 0 
        // 0 should not be able to happen again after  
        // the very first initialization of compChoice
    }
    else
    {
        // Check for a tie
        if (uchoice == cchoice)
        {
            cout << "You tied :|" << endl;
        }
        else
        {
            // No tie 
            // So check who won
            if (uchoice == 1 && cchoice == 2)
            {
                cout << "User wins! :D" << endl;
            }
            else
            {
                if (uchoice == 2 && cchoice == 3)
                {
                    cout << "User wins! :D" << endl;
                }
                else
                {
                    if (uchoice == 3 && cchoice == 1)
                    {
                        cout << "User wins! :D" << endl;
                    }
                    else
                    {
                        cout << "Computer wins! D:" << endl;
                    }
                }
            }
        }
    }
}

void displayChoice(int cchoice)
{
    if (cchoice == 1)
    {
        cout << "The computer chose rock" << endl;
    }
    else
    {
        if (cchoice == 2)
        {
            cout << "The computer chose paper" << endl;
        }
        else
        {
            if (cchoice == 3)
            {
                cout << "The computer chose scissors" << endl;
            }
            else
            {
                cout << "Error the computer chose an invalid number!" << endl;
            }
        }
    }
}

int getComputerChoice()
{
    int choice;
    
    choice = (rand() % 3) + 1;
    
    return choice;
}

int getUserChoice()
{
    int choice;
    
    cout << "What do you choose?" << endl;
    cin >> choice;
    while (! (choice >= 1 && choice < 5))
    {
        cout << "Your input is not within range please make another choice!" << endl;
        cin >> choice;
    }
    if (choice == 1)
    {
        cout << "You chose rock" << endl;
    }
    else
    {
        if (choice == 2)
        {
            cout << "You chose paper" << endl;
        }
        else
        {
            if (choice == 3)
            {
                cout << "You chose scissors" << endl;
            }
            else
            {
                if (choice == 4)
                {
                }
                else
                {
                    cout << "Error you shouldn't be able to see this" << endl;
                }
            }
        }
    }
    
    return choice;
}

// The following implements type conversion functions.

string toString (double value)  //int also
{
    stringstream temp;
    temp << value;
    return temp.str();
}

int toInt (string text)
{
    return atoi(text.c_str());
}

double toDouble (string text)
{
    return atof(text.c_str());
}
