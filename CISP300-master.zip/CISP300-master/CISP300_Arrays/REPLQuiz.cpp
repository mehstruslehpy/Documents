﻿#include <iostream>
#include <sstream>
#include <string>
#include <cstdlib>
#include <cmath>
#include <vector>
#include <string.h>

using namespace std;

// Headers
string toString (double);
int toInt (string);
double toDouble (string);

void help();
void initAns(string answers, int);
void initQs(string questions, int);
void output(int, int);
int quizStart(string questions, string answers, int);

int main()
{
    bool isLoaded;

    isLoaded = false;
    string command;
    int SIZE;
    SIZE = 1;
    string questions[SIZE];
    questions[0] = "DUMMYQUESTION";
    string answers[SIZE];
    answers[0] = "DUMMYANSWER";


    cout << "Welcome to ezQuiz!" << endl;
    help();
    cin >> command;
    while (command != string("q"))
    {
        if (command == string("h"))
        {
            help();
        }
        if (command == string("c"))
        {
            cout << "Input how many questions you would like in your quiz:" << endl;
            cin >> SIZE;

            initQs(*questions, SIZE);
            initAns(*answers, SIZE);
            isLoaded = true;
        }
        if (command == string("s"))
        {
            if (isLoaded == true)
            {
                cout << "Teacher, please clear the console window to prevent cheating. Instruct your student to type lowercase y to begin the quiz." << endl;
                output(quizStart(*questions, *answers, SIZE), SIZE);
            }
            else
            {
                cout << "Error: you have not created a quiz yet!" << endl;
                help();
            }
        }
        cin >> command;
    }
    cout << "See you later..." << endl;
}

void help()
{
    cout << "        q: quit" << endl;
    cout << "        h: help" << endl;
    cout << "        c: create a quiz" << endl;
    cout << "        s: start a quiz" << endl;
}

void initAns(string answers, int SIZE)
{
    cout << "Please input your answers (only in lowercase format)" << endl;
    int i;

    for (i = 0 ; i <= SIZE - 1 ; i += 1)
    {
        cout << "answer " << i << ":" << endl;
        cin >> answers[i];
    }
}

void initQs(string questions, int SIZE)
{
    cout << "Please input your questions" << endl;
    int i;

    for (i = 0 ; i <= SIZE - 1 ; i += 1)
    {
        cout << "Question " << i << ":" << endl;
        cin >> questions[i];
    }
}

void output(int count, int SIZE)
{
    cout << "You got: " << count << " out of " << SIZE << " correct" << endl;
    cout << "Percent correct: " << (double) count * 100 / SIZE << endl;
}

int quizStart(string questions, string answers, int SIZE)
{
    string ready;
    int i;
    int count;

    count = 0;
    string uAnswers;

    cin >> ready;
    while (ready != string("y"))
    {
        cout << "Invalid input please type y and enter to start." << endl;
        cin >> ready;
    }
    cout << "Quiz is starting... Please only answer in lowercase." << endl;
    for (i = 0 ; i <= SIZE - 1 ; i += 1)
    {
        cout << questions[i] << endl;
        cin >> uAnswers[0];
        if (uAnswers[0] == answers[i])
        {
            count = count + 1;
        }
    }

    return count;
}

// The following implements type conversion functions.

string toString (double value)  //int also
{
    stringstream temp;
    temp << value;
    return temp.str();
}

int toInt (string text)
{
    return atoi(text.c_str());
}

double toDouble (string text)
{
    return atof(text.c_str());
}
