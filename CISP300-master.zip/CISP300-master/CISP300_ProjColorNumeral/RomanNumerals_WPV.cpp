﻿#include <iostream>
#include <sstream>
#include <string>
#include <cstdlib>
#include <cmath>

using namespace std;

// Headers
string toString (double);
int toInt (string);
double toDouble (string);

int main() {
    // Funny story I had already kinda done this excercise from the book in python before this project was assigned. In python you can cut down on some of the conditionals with a for loop for repeated characters. I'm not sure how to do that in flowgorithm, I tried to do it but individually outputting repeated I's in numbers like three or seven would escape to a newline after each output block:  
    //  
    // https://github.com/mehstruslehpy/Documents/blob/master/Python/More/roman_numeral.py
    int inputNum;
    
    cout << "Please enter a number from 1-10: " << endl;
    cin >> inputNum;
    if (inputNum > 10 || inputNum < 1) {
        cout << "Error input outside of range!" << endl;
    } else {
        if (inputNum == 10) {
            cout << "X" << endl;
        } else {
            if (inputNum == 9) {
                cout << "IX" << endl;
            } else {
                if (inputNum == 8) {
                    cout << "VIII" << endl;
                } else {
                    if (inputNum == 7) {
                        cout << "VII" << endl;
                    } else {
                        if (inputNum == 6) {
                            cout << "VI" << endl;
                        } else {
                            if (inputNum == 5) {
                                cout << "V" << endl;
                            } else {
                                if (inputNum == 4) {
                                    cout << "IV" << endl;
                                } else {
                                    if (inputNum == 3) {
                                        cout << "III" << endl;
                                    } else {
                                        if (inputNum == 2) {
                                            cout << "II" << endl;
                                        } else {
                                            if (inputNum == 1) {
                                                cout << "I" << endl;
                                            } else {
                                                cout << "OOPS! You shouldn't be able to get to here!" << endl;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// The following implements type conversion functions.

string toString (double value) { //int also
    stringstream temp;
    temp << value;
    return temp.str();
}

int toInt (string text) {
    return atoi(text.c_str());
}

double toDouble (string text) {
    return atof(text.c_str());
}
