﻿#include <iostream>
#include <sstream>
#include <string>
#include <cstdlib>
#include <cmath>

using namespace std;

// Headers
string toString (double);
int toInt (string);
double toDouble (string);

int main()
{
    // This program doesn't account for inputs like red red or any other spellings of the words..
    string inColor1;
    string inColor2;
    
    cout << "Please enter a color input from the following list then press enter:" << endl;
    cout << "'Blue' or 'blue'" << endl;
    cout << "'Red' or 'red'" << endl;
    cout << "'Yellow' or 'yellow'" << endl;
    cin >> inColor1;
    if (inColor1 == string("red") || inColor1 == string("blue") || inColor1 == string("yellow") || inColor1 == string("Red") || inColor1 == string("Blue") || inColor1 == string("Yellow"))
    {
        cout << "Please enter another color input then press enter:" << endl;
        cin >> inColor2;
        if (inColor2 == string("red") || inColor2 == string("blue") || inColor2 == string("yellow") || inColor2 == string("Red") || inColor2 == string("Blue") || inColor2 == string("Yellow"))
        {
        }
        else
        {
            cout << "Error: Wrong color input 2" << endl;
        }
        if ((inColor1 == string("red") || inColor1 == string("Red")) && (inColor2 == string("blue") || inColor2 == string("Blue")) || (inColor1 == string("blue") || inColor1 == string("Blue")) && (inColor2 == string("red") || inColor2 == string("Red")))
        {
            cout << "Purple" << endl;
        }
        else
        {
            if ((inColor1 == string("red") || inColor1 == string("Red")) && (inColor2 == string("yellow") || inColor2 == string("Yellow")) || (inColor1 == string("yellow") || inColor1 == string("Yellow")) && (inColor2 == string("red") || inColor2 == string("Red")))
            {
                cout << "Orange" << endl;
            }
            else
            {
                if ((inColor1 == string("blue") || inColor1 == string("Blue")) && (inColor2 == string("yellow") || inColor2 == string("Yellow")) || (inColor1 == string("yellow") || inColor1 == string("Yellow")) && (inColor2 == string("blue") || inColor2 == string("Blue")))
                {
                    cout << "Green" << endl;
                }
            }
        }
    }
    else
    {
        cout << "Error: Wrong color input 1" << endl;
    }
}

// The following implements type conversion functions.

string toString (double value)  //int also
{
    stringstream temp;
    temp << value;
    return temp.str();
}

int toInt (string text)
{
    return atoi(text.c_str());
}

double toDouble (string text)
{
    return atof(text.c_str());
}
