﻿#include <iostream>
#include <sstream>
#include <string>
#include <cstdlib>
#include <cmath>

using namespace std;

// Headers
string toString (double);
int toInt (string);
double toDouble (string);

int main()
{
    int secA;
    int secB;
    int secC;
    
    cout << "Enter the tickets sold for Section A." << endl;
    cin >> secA;
    
    // if not in range, do not continue, prompt for input.
    while (! (secA >= 0 && secA <= 5000))
    {
        cout << "Error value must be in range 0 to 5000" << endl;
        cin >> secA;
    }
    cout << "Enter the tickets sold for Section B." << endl;
    cin >> secB;
    while (! (secB >= 0 && secB <= 10000))
    {
        cout << "Error value must be in range 0 to 10000" << endl;
        cin >> secB;
    }
    cout << "Enter the tickets sold for Section C." << endl;
    cin >> secC;
    while (! (secC >= 0 && secC <= 8000))
    {
        cout << "Error value must be in range 0 to 8000" << endl;
        cin >> secC;
    }
    cout << "Total profit is: " << secA * 200 + secB * 150 + secC * 100 << " dollars" << endl;
}

// The following implements type conversion functions.

string toString (double value)  //int also
{
    stringstream temp;
    temp << value;
    return temp.str();
}

int toInt (string text)
{
    return atoi(text.c_str());
}

double toDouble (string text)
{
    return atof(text.c_str());
}
