﻿#include <iostream>
#include <sstream>
#include <string>
#include <cstdlib>
#include <cmath>

using namespace std;

// Headers
string toString (double);
int toInt (string);
double toDouble (string);

int main()
{
    double speed;
    double limit;
    
    // I'm using a real because depending on the police officer and the speedometer the number entered might be a decimal.
    cout << "Enter the speed limit:" << endl;
    cin >> limit;
    
    // if speed is not in range iterate
    while (! (limit >= 20 && limit <= 70))
    {
        cout << "Error input speed limit out of range!" << endl;
        cin >> limit;
    }
    cout << "Enter the drivers speed:" << endl;
    cin >> speed;
    
    // You asked for at least not greater than, if you wanted to only accept inputs above the speed limit you would just do !(speed > limit) instead
    while (! (speed >= limit))
    {
        cout << "The driver is not speeding!" << endl;
        cin >> speed;
    }
    cout << "The driver was going: " << speed - limit << " mph over the limit" << endl;
}

// The following implements type conversion functions.

string toString (double value)  //int also
{
    stringstream temp;
    temp << value;
    return temp.str();
}

int toInt (string text)
{
    return atoi(text.c_str());
}

double toDouble (string text)
{
    return atof(text.c_str());
}
