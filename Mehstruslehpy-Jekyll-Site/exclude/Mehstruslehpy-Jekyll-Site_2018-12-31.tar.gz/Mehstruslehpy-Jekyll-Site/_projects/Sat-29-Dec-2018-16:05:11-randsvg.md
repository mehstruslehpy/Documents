---
projectname: RandSvg
projectlink: https://mehstruslehpy.neocities.org/randsvg/randsvg.html
projectdescription: A program which randomly draws an svg image to the current window every five seconds.
projectid: randsvg
---
This was built on top of engine for rexpr after I realized I could also randomly generate svg tags. The result is actually fairly aesthetically pleasineasing.
