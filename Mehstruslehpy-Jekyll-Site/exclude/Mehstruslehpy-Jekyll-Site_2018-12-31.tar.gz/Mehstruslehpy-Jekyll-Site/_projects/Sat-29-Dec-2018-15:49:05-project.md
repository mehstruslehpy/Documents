---
projectname: MathMisc
projectlink: https://github.com/mehstruslehpy/MathMisc
projectdescription: A catchall repo for mathematical experiments.
projectid: mathmisc
---
I created this repository for cataloging various mathematical/programming experiments.
