---
projectname: Text Reminder Site
projectlink: http://mehstruslehpy.pythonanywhere.com/
projectdescription: A simple text reminder/bulletin website.
projectid: textremindersite
---
This website was mostly just a modification of a project from the book 'Flask By Example'
