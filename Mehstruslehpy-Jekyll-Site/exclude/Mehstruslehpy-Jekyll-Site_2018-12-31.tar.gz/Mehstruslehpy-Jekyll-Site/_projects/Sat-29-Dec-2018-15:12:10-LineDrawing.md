---
projectname: LineDrawing
projectlink: https://github.com/mehstruslehpy/LineDrawing
projectdescription: An ncurses library for drawing shapes and functions.
projectid: linedrawing
---
LineDrawing is a set of functions for drawing some basic shapes and graphs at the commandline.
