---
projectname: FirefoxSearch
projectlink: https://github.com/mehstruslehpy/Documents/tree/master/Scripts/FirefoxSearch
projectdescription: No not the real firefox search. This program is just a wrapper around the real thing.
projectid: firefoxsearch
---
This was written to add a convenient entry for searching the internet from QuickMenu. It is just a primitive tcl/tk wrapper around the command line interface to firefox.
