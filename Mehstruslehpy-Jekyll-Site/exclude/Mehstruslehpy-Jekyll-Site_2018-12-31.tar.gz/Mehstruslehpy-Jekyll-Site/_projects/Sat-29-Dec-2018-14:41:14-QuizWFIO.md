---
projectname: QuizWFIO
projectlink: https://github.com/mehstruslehpy/Documents/tree/master/QuizWFIO
projectdescription: A simeple program for taking, creating and storing quizzes at the command line.
projectid: QuizWFIO
---
QuizWFIO was written in C it can load and store and administer simple quizzes and features some hacky encryption for keeping the solutions unknown.
