---
projectname: exprGraph
projectlink: https://github.com/mehstruslehpy/exprGraph
projectdescription: A propositional tableau prover.
projectid: exprgraph
---
I created this prover after learning the tableau method from Graham Priests 'An Introduction to Nonclassical Logic'.
