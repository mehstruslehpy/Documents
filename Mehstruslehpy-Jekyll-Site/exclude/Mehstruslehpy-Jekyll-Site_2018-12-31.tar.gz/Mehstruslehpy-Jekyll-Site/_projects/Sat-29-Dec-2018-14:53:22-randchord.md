---
projectname: RandChord
projectlink: https://github.com/mehstruslehpy/RandChords
projectdescription: A gui program for generating random musical chord progressions.
projectid: randchord
---
RandChord was written in C++ and uses tcl/tk for its gui. The program can also be run at the command line if the user chooses.
