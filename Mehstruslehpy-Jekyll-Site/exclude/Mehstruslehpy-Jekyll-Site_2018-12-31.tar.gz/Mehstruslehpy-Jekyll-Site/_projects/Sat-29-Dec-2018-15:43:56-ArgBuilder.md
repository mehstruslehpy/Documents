---
projectname: ArgBuilder
projectlink: https://github.com/mehstruslehpy/ArgBuilder
projectdescription: Some scripts for generating random logical formulas.
projectid: argbuilder
---
The output formulas can be plaintext at the command line or as pdfs. The program can be run as a tcl/tk gui or command line program.
