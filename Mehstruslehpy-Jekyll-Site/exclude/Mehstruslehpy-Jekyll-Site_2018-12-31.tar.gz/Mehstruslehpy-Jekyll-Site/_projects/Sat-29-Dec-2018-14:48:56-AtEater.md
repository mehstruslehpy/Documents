---
projectname: AtEater
projectlink: https://github.com/mehstruslehpy/AtEater
projectdescription: A very primitive pacman style terminal game engine.
projectid: ateater
---
AtEater was written in C++ the goal of the game is to eat all of the '@' symbols on the map without getting eaten by the monsters ('M'). The game engine is written for the command line, users can create their own maps with a text editor and the included map building program.
