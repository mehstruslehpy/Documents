---
projectname: htmlFilters
projectlink: https://github.com/mehstruslehpy/Documents/tree/master/Scripts/htmlFilters
projectdescription: Some simple html filtering scripts.
projectid: htmlfilt
---
The main one is a filter for grabbing and displaying all the youtube links on a website. I use this one for getting all the youtube music links from some websites when I don't actually care to read the content posted.
