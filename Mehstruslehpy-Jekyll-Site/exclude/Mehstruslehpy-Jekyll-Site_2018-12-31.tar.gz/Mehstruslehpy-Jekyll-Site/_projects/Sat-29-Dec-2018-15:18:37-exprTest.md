---
projectname: exprTest
projectlink: https://github.com/mehstruslehpy/exprTest
projectdescription: A propositional logic prover.
projectid: exprtestlinux
---
exprTest is a propositional logic prover which uses a proof procedure derived from the one in the book 'Introduction To Logic' by Harry Gensler. There is also a set of translation tools and testing tools for quickly building and testing different logical arguments. The random argument generator is written in lisp the prover and translator itself are written in C++. The prover can receive input in three modes but the most efficient is from the translator tool which generate a heredoc that runs against the main prover.
