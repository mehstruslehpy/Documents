---
projectname: Containers
projectlink: https://github.com/mehstruslehpy/Containers
projectdescription: Some basic container classes for C++.
projectid: containers
---
This was written before I knew much about data structures but after I had learned some of the basics of OOP. It features various implementations of Stacks, Linked Lists etc.
