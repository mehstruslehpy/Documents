---
projectname: QuickMenu
projectlink: https://github.com/mehstruslehpy/QuickMenu
projectdescription: A configurable gui menu launcher program.
projectid: quickmenu
---
QuickMenu was written when I first started using dwm a minimal window manager with no gui launcher menu of its own. QuickMenu was written in tcl/tk.
