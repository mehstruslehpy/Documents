---
projectname: TempPlotScripts
projectlink: https://github.com/mehstruslehpy/Documents/tree/master/Scripts/TempPlotScripts
projectdescription: Some CPU temperature logging and plotting scripts for linux.
projectid: tempplotscripts
---
These aren't really meant to be used by anybody but myself. I wrote them for fun while trouble shooting an old laptop of mine that was constantly overheating and shutting off. I used gnuplot for this one because I was unaware of any better solutions at the time.
