---
projectname: Location Database Website
projectlink: http://mehstruslehpy2.pythonanywhere.com/
projectdescription: A website which can store and display bits of geographic information.
projectid: geoinfowebsite
---
Like the text reminder website this project was mostly just a modificaion of code from the book 'Flask By Example'
