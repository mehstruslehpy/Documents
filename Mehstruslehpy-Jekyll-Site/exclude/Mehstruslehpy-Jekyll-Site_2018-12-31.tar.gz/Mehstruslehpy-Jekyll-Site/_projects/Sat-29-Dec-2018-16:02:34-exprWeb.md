---
projectname: exprWeb
projectlink: http://mehstruslehpy3.pythonanywhere.com/
projectdescription: An experimental web interface to the exprGraph and exprTest provers.
projectid: exprWeb
---
exprWeb was created to allow people to use my provers from the web as well as to scratch an itch to develop a website with python and flask again.
