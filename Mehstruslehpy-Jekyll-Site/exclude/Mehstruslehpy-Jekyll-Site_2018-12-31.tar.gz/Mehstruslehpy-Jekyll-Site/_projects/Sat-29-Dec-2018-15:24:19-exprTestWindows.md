---
projectname: exprTestWindows
projectlink: https://github.com/mehstruslehpy/exprTestWindowsVersion
projectdescription: A port of the above prover to windows.
projectid: exprtestwindows
---
This is a port of the exprtest prover to windows. The main changes are that instead of generating a heredoc the windows version generates a batch script format.
