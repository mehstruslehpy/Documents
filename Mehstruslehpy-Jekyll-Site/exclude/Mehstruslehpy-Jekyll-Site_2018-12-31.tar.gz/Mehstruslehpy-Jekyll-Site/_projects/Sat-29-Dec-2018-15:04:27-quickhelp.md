---
projectname: QuickHelp
projectlink: https://github.com/mehstruslehpy/QuickHelp
projectdescription: QuickHelp is a simple documentation system.
projectid: quickhelp
---
QuickHelp was written for tracking configuration information for my computer. I was bouncing around between gentoo and archlinux at the time and needed a good way to track some of the more idiosyncratic bits and pieces of how I had configured my computer. It is written in a mix of bash and python.
