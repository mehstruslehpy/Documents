#include <iostream>
#include <fstream>

//the assigned functions
void stringCopy(char *A, char *B);
bool stringCompare(char *A, char *B);
void stringConcatenation (char *A, char *B);
int stringPosition(char *A, char B);
int stringLength(char *A);

//two helper functions
char numToChar(const unsigned int num);
unsigned int helperStrLen(const char *A);

#define MAX 10

using namespace std;

ifstream in("input.txt");
ofstream out("output.txt");

int main()
{
    char from[MAX], to[MAX];

    while (in.good())
    {
        //Copy Test:
        in >> from >> to;
        out << "COPY TEST:" << endl;
        out << "copy "<< from <<" to "<< to << endl;
        stringCopy(to,from);
        out << "result: "<< from <<" "<< to << endl << endl;
        //Compare Test:
        in >> from >> to;
        out << "COMPARE TEST:" << endl;
        out << "compare "<< from <<" to "<< to << endl;
        out << "result: "
            << from
            << ((stringCompare(from,to))?(" matches "):(" does not match "))
            << to << endl << endl;
        //Concatenate Test:
        in >> from >> to;
        out << "CONCATENATE TEST:" << endl;
        out << "append "<< from <<" to "<< to << endl;
        stringConcatenation(to,from);
        out << "result: "<< to << endl << endl;
        //Position Test:
        in >> from >> to;
        out << "POSITION TEST:" << endl;
        out << "locate in " <<from <<" the character "<< to[0] << endl;
        out << stringPosition(from,to[0]) << endl << endl;
        //Length Test:
        //the "to" part will toggle in.good()
        in >> from >> to;
        out << "LENGTH TEST:" << endl;
        out << "find length and append to start: "<<from << endl;
        out << "result: "<<stringLength(from) <<" new string "<<from<< endl << endl;
    }
    in.close();
    out.close();
}

//stringCopy:
//takes two strings A and B
//replaces the contents of A with B
void stringCopy(char *A, char *B)
{
    unsigned int i;
    //copy over every character from B into A, this will not copy the null char
    for (i = 0; B[i]!='\0'; i++)
    {
        A[i] = B[i];
    }
    //make sure to end A with the null character
    A[i] = '\0';
}

//stringCompare:
//takes two strings returns true if the strings are the same false if not
bool stringCompare(char *A, char *B)
{
    unsigned int i;
    bool ret = true;
    //check every character in each string
    for (i = 0; A[i]!='\0'; i++)
    {
        //set ret to false if a mismatch is found
        if (A[i] != B[i])
        {
            ret = false;
        }
    }
    //the loop above skips checking the last char of B for the null char
    if (B[i]!='\0') ret = false;
    return ret;
}

//stringConcatenation:
//receives two characters
//append B to A
void stringConcatenation (char *A, char *B)
{
    //find the ending of A
    unsigned int nullCharIndex = 0;
    while (A[nullCharIndex] != '\0')
    {
        nullCharIndex++;
    }

    //copy B to A starting from the ending of A
    unsigned int index = 0;
    while (B[index] != '\0')
    {
        A[nullCharIndex] = B[index];
        nullCharIndex++;
        index++;
    }
    A[nullCharIndex] = '\0';
}

//stringPosition:
//takes a string and character
//return the first position of the character in the string
//return -1 if not found
int stringPosition(char *A, char B)
{
    for (unsigned int i = 0; A[i]!='\0'; i++)
    {
        if (A[i]==B)
        {
            return i;
        }
    }
    return -1;
}

//stringLength:
//receive a char array, shift every char right by one, and store the length of
//the string in position 0, the length stored does not include the null char
//returns the length as an integer
int stringLength(char *A)
{
    //it will be easier to start from the right and work left
    unsigned int len = helperStrLen(A);
    //shift every char right by one
    for (unsigned int i = len+1; i > 0; i--)
    {
        A[i] = A[i-1];
    }
    //add the count at index 0
    A[0] = numToChar(len);
    //return the length
    return len;
}

/*------------------------helper functions-----------------------------------*/

//helper function: counts the characters in A
//A must contain a null character
unsigned int helperStrLen(const char *A)
{
    unsigned int count = 0;
    for (count = 0; A[count] != '\0'; count++)
    {}
    return count;
}

//helper function: receives a number [0-9] returns the corresponding ascii digit
//this function stops working so nicely when it receives a number greater than 9
char numToChar(const unsigned int num)
{
    //ascii digit 0 is 48 in decimal, ascii 9 is 57 in decimal
    return (num + 48);
}
