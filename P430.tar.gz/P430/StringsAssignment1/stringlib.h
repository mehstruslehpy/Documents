#ifndef _STRINGLIB_WPV_
#define _STRINGLIB_WPV_
#include <iostream>
using namespace std;
void stringCopy(char *A, char *B);
bool stringCompare(char *A, char *B);
void stringConcatenation (char *A, char *B);
int stringPosition(char *A, char B);
int stringLength(char *A);
#endif
