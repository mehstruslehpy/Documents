//TODO: clean up comments and debugging code, merge the stringlib files into a single file
#include <iostream>
#include <fstream>

#define MAX 10

//my string functions are here
#include "stringlib.h"

using namespace std;

ifstream in("input.txt");
ofstream out("output.txt");
int main()
{
    char from[MAX], to[MAX];

    // can use in.good() to check for end of file
    while (in.good())
    {
        //stringLength test:
        //in >> from >> to;
        //cout << from <<"  "<< to << endl;
        //stringLength(from);
        //stringLength(to);
        //cout << from <<"  "<< to << endl;

        //stringCompare test:
        //cin >> from >> to;
        //bool match = stringCompare(from,to);
        //if (match) cout << "MATCH" << endl;
        //else cout << "NO MATCH!" << endl;

        //stringCopy test:
        //cout << "String copy test: " << endl;
        //cin >> from >> to;
        //cout << "BEFORE: " << from <<" "<< to << endl;
        //stringCopy(from,to);
        //cout << "AFTER: " << from <<" "<< to << endl;

        //stringPosition test:
        //cin >> from >> to;
        //cout << "Position: "<< stringPosition(from,to[0]) << endl;

        //stringConcatenation test:
        //cin >> from >> to;
        //stringConcatenation(from,to);
        //cout << "Position: "<< from << endl;

        //all five tests:
        //test1:
        in >> from >> to;
        out << "COPY TEST:" << endl;
        out << "copy "<< from <<" to "<< to << endl;
        stringCopy(to,from);
        out << "result: "<< from <<" "<< to << endl << endl;
        //test2:
        in >> from >> to;
        out << "COMPARE TEST:" << endl;
        out << "compare "<< from <<" to "<< to << endl;
        out << "result: "
            << from
            << ((stringCompare(from,to))?(" matches "):(" does not match "))
            << to << endl << endl;
        //test3:
        in >> from >> to;
        out << "CONCATENATE TEST:" << endl;
        out << "append "<< from <<" to "<< to << endl;
        stringConcatenation(to,from);
        out << "result: "<< to << endl << endl;
        //test4:
        in >> from >> to;
        out << "POSITION TEST:" << endl;
        out << "locate in " <<from <<" the character "<< to[0] << endl;
        out << stringPosition(from,to[0]) << endl << endl;
        //test5:
        in >> from;
        out << "LENGTH TEST:" << endl;
        out << "find length and append to start: "<<from << endl;
        out << "result: "<<stringLength(from) <<" new string "<<from<< endl << endl;
        //consume a blank space or eof
        in >> from;
    }
    in.close();
    out.close();
}
