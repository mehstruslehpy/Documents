#!/bin/bash

rm input.txt
touch input.txt

RANDCOUNT=$(( ( RANDOM % 90 )  + 1 ))

for i in `seq 1 $RANDCOUNT`; do
	RANDNUM=$(( ( RANDOM % 100 ) + 1 ))
	echo $RANDNUM >> input.txt
done

valgrind ./main
#./main
#echo
#echo "Input File:"
#cat input.txt
