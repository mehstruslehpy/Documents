#include <iostream>
#include <fstream>
#include <math.h>
using namespace std;

struct TreeNode
{
    unsigned key;
    TreeNode* right = NULL;
    TreeNode* left = NULL;
};
//insert an element into a tree
void Insert(TreeNode*&,unsigned);
//from the notes
TreeNode* NewNode(unsigned);
//build a tree from a file of ints
void BuildTreeFromFile(TreeNode*&);
//build an array from a tree given the starting index
void BuildArray(TreeNode*&,unsigned[],unsigned);
//build a tree from an array given the starting index and the size of the array
void BuildTreeFromArray(unsigned[],TreeNode*&,unsigned,unsigned);
//initialize every element of an array given its size
void PrepareArray(unsigned[],unsigned);
//from the notes
int TreeDepth(TreeNode*);
//recursively delete each element in the tree
void DeleteTree(TreeNode*&);
//inorder print like the last assignment
void InOrderPrint(TreeNode*&);
//print an array given its size
void PrintArray(unsigned[],unsigned);

//the same debugging visualizations as before
void DotHandler(TreeNode*&);
void DotLangPrint(TreeNode*&);

int main()
{
    TreeNode* startingtree = NULL; //the starting tree
    TreeNode* rebuilttree = NULL; //the tree to be built from the array
    BuildTreeFromFile(startingtree); //build the first tree
    //DotLangPrint(startingtree); //uncomment for dot language version of the first tree

    //I wanted to see if I could write this without a fixed size array
    unsigned MAX_SIZE = pow(2,TreeDepth(startingtree)+1)-1;
    unsigned* array = new unsigned [MAX_SIZE];
    PrepareArray(array,MAX_SIZE); //set up the array
    BuildArray(startingtree,array,0); //build the array from the tree
    cout << "The Tree in Array Format: (0 stands for null)" << endl;
    PrintArray(array,MAX_SIZE);
    BuildTreeFromArray(array,rebuilttree,0,MAX_SIZE); //build the new tree from the array
    cout << "The reconstructed tree inorder printed: " << endl;
    //DotLangPrint(rebuilttree);
    InOrderPrint(rebuilttree); //inorder print the new tree
    cout << endl;
    //clean up
    delete [] array;
    DeleteTree(startingtree);
    DeleteTree(rebuilttree);
}
//print a tree via an inorder traversal
void InOrderPrint(TreeNode*& root)
{
    if (root!=NULL)
    {
        InOrderPrint(root->left); //L
        cout << ":"<<root->key; //V
        InOrderPrint(root->right); //R
    }
}
//build a tree from an array given its size and the index of the next element to insert
void BuildTreeFromArray(unsigned arr[],TreeNode*& root,unsigned index,unsigned size)
{
    //don't insert into the tree if the element is zero (a null) or if the index we are trying to insert exceeds size
    if (arr[index]!=0&&index<size) //picking zero for nulls means we cannot use it as a normal node key
    {
        Insert(root,arr[index]); //Visit: insert the current item in the array
        BuildTreeFromArray(arr,root,2*index+1,size); //Left: handle the left child index recursively
        BuildTreeFromArray(arr,root,2*index+2,size); //Right: handle the right child index recursively
    }
}
//recurse down the tree and delete everything
void DeleteTree(TreeNode*& node)
{
    if (node==NULL) return;

    //delete the leaves first
    if (node->left!=NULL) DeleteTree(node->left);
    if (node->right!=NULL) DeleteTree(node->right);

    //delete the current node last
    delete node;
    node=NULL;
}
//from the notes
int TreeDepth(TreeNode* node)
{
    if (node==NULL)
    {
        return(-1);
    }
    else
    {
        // compute the depth of each subtree
        int LDepth = TreeDepth (node->left);
        int RDepth = TreeDepth (node->right); // use the larger one
        if (LDepth > RDepth) return(LDepth +1);
        else return(RDepth +1);
    }
}
//initialize the entire array to NULL
void PrepareArray(unsigned arr[],unsigned size)
{
    for (unsigned i = 0; i<= size; i++) arr[i]=0;
}

//as a precondition assume arr has the correct amount of space allocated and index is an element between the
//first and last indices of arr
void BuildArray(TreeNode*& root,unsigned* arr,unsigned index)
{
    if (root!=NULL)
    {
        arr[index]=root->key; //Visit: insert the current node into the array
        BuildArray(root->left,arr,2*index+1); //Left: recurse down the tree with the index for the left item and the address of the left node
        BuildArray(root->right,arr,2*index+2); //Right: recurse down the tree with the index for the right item and the address of the right node
    }
}
//build a tree from a file of integers
void BuildTreeFromFile(TreeNode*& root)
{
    fstream inf("input.txt"); //open the file
    unsigned temp = 0;
    while (inf>>temp) Insert(root,temp); //read every number into the tree
}
//receives key returns a new node
TreeNode* NewNode(unsigned key)
{
    TreeNode* node=new TreeNode;
    node->key = key;
    node->left=NULL;
    node->right=NULL;
    return node;
}
//insert item in the appropriate position
void Insert(TreeNode*& leaf, unsigned item)
{
    if (!leaf)
    {
        leaf=NewNode(item);
    }
    else if (item < leaf->key)
    {
        Insert(leaf->left, item);
    }
    else if (item > leaf->key)
    {
        Insert(leaf->right, item);
    }
    //this will not insert duplicates but could be modified to do so
}
//print the array
void PrintArray(unsigned arr[],unsigned size)
{
    for (unsigned i = 0; i< size; i++) cout << ":" <<arr[i];
    cout << endl;
}
//the dotlang printing functions I've been using for the past couple projects
void DotLangPrint(TreeNode*& root)
{
    //if (root==NULL) throw runtime_error("void DotLangPrint(TreeNode* root): root must not be NULL.");
    if (root==NULL) return;
    cout << "digraph BST\n{"<<endl;
    cout << "\tnodesep=0.01"<<endl;
    DotHandler(root);
    cout << "}"<<endl;

    cout << endl << endl << "You can copy and paste the code: \"digraph names { ... }\" ";
    cout << "at one of the following sites to see a diagram of the tree"<< endl;
    cout << "http://webgraphviz.com/" << endl;
    cout << "https://dreampuf.github.io/GraphvizOnline/" << endl;
    cout << "http://viz-js.com/" << endl;
    cout << "or use some other graphviz/DOT language viewer" << endl;
    cout << "more info about graphviz can be found here:" << endl;
    cout << "https://www.graphviz.org/about/" << endl;

}
void DotHandler(TreeNode*& node)
{
    static long invisnode = 0;
    //print the connecting nodes
    if (node->left==NULL)
    {
        cout << "\t"<<long(&node)<< " -> "<<++invisnode<<"//left branch is null"<<endl;
        cout << "\t" << invisnode << "[label=\"\\\\\"]"<<endl;
    }
    else
    {
        cout << "\t"<<long(&node) << " -> " << long(&(node->left)) << endl;
    }

    if (node->right==NULL)
    {
        cout << "\t"<<long(&node)<< " -> "<<++invisnode<<"//right branch is null"<<endl;
        cout << "\t" << invisnode << "[label=\"\\\\\"]"<<endl;
    }
    else
    {
        cout << "\t" <<long(&node) << " -> " << long(&(node->right)) << endl;
    }

    //recurse
    if(node->left!=NULL)DotHandler(node->left);
    if(node->right!=NULL)DotHandler(node->right);

    //print the label for the current node
    cout << "\t" <<long(&node)<<"[label=\""<<node->key<<"\"];"<<endl;
}

