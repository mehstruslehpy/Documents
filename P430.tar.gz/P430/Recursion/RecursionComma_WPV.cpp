#include <iostream>

using namespace std;

void recurFunc(int num)
{
    int tail = num%1000;
    int rest = num/1000;
    if (rest==0)
    {
        cout << tail;
        return;
    }
    else
        recurFunc(rest);

    cout << "," << tail;
}

int main()
{
    recurFunc(3874);
    return 0;
}
