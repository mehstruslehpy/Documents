#include <iostream>

using namespace std;

int recurFunc(int num)
{
    int tail = num%10;
    int rest = num/10;
    if (rest==0)
    {
        return num;
    }
    else
        return tail+recurFunc(rest);
}

int main()
{
    int result = 0;
    result = recurFunc(2302);
    cout << "RESULT: " << result << endl;
    return 0;
}
