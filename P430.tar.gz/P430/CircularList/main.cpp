#include <iostream>
#include <fstream>
#include <cstring> //strncpy

using namespace std;

//max length for any string
const int STR_MAX = 99;

//node structure
struct Node
{
    char name[STR_MAX];
    Node* next;
    Node* prev;
};

//insert at the beginning (from the notes)
void InsertBeginning(Node*& head, char* name);
//insert at the end from the challenge q in the notes
//the assignment prompt doesn't specify which so I wrote both
void InsertEnding(Node*& head, char* name);
//traverse through the list and print each element
void TraverseFwd(Node*& head);
//read the file into the list
void ReadFile(Node*& head);
//delete the whole list
void DeleteCList(Node*& head);
//delete the head
void DeleteHead(Node*& head);
//delete count nodes from the head
void DeleteNodes(Node*& head,unsigned int count);

//I should probably just use assert
void Error(const char* msg);

int main()
{
    Node* head = NULL;
    unsigned int count = 0; //don't allow negatives

    ReadFile(head);
    cout << "The current list:" << endl;
    TraverseFwd(head);

    cout << "How many nodes would you like to delete?" << endl;
    cin >> count;

    DeleteNodes(head,count);

    cout << "The modified list:" << endl;
    TraverseFwd(head);

    DeleteCList(head);
    return 0;
}

void DeleteNodes(Node*& head,unsigned int count)
{
    if (!head) Error("ERROR:void DeleteNodes(Node*& head,unsigned int count): Cannot delete from empty list");

    //iterate until count is zero delete a node from the head
    //each time
    for (; count>0; count--) //if count is zero this won't run
    {
        DeleteHead(head);
    }
}
void DeleteHead(Node*& head)
{
    if (!head) Error("ERROR:void DeleteHead(Node*& head): Cannot delete the head of an empty list");
    if (head->next==head) //only one node
    {
        head->next=NULL;
        head->prev=NULL;
        delete head;
        head=NULL;
    }
    else
    {
        //hang onto the current head
        Node* temp = head;
        //slice the node out
        head->prev->next=head->next;
        head->next->prev=head->prev;
        //set up the new head
        head = temp->next;
        //delete the temp
        delete temp;

    }
}
void DeleteCList(Node*& head)
{
    //the user may delete all the elements of the list so don't error if head is null
    if (!head) return;

    Node* curr = head;

    //untangle the list into a plain doubly linked list
    head->prev->next=NULL;
    head->prev=NULL;

    //delete the list like a normal doubly linked list
    while (head)
    {
        head=head->next;
        delete curr;
        curr=head;
    }
}

void TraverseFwd(Node*& head)
{
    //don't print an empty list
    if (!head) return;
    //iterate down the list until you hit head->prev (the "tail") print each name
    Node* curr = head;
    while(curr!=head->prev)
    {
        cout << curr->name << " ";
        curr=curr->next;
    }
    cout << curr->name << endl;
}

void ReadFile(Node*& head)
{
    if (head) Error("ERROR:void ReadFile(Node*& head): List not empty");
    ifstream infile("input.txt");
    char tempname[STR_MAX];
    //read and insert every line at the end of the list
    while (infile.getline(tempname,STR_MAX,'\n'))
    {
        //InsertBeginning(head,tempname);
        InsertEnding(head,tempname);
    }
}

void Error(const char* msg)
{
    cout << msg << endl;
}

void InsertBeginning(Node*& head, char* name)
{
    if (!name) Error("void ReadFile(Node*& head): Invalid name pointer");
    Node *nn = new Node;
    strncpy(nn->name,name,STR_MAX);
    if (!head) //list is empty
    {
        nn->prev=nn;
        nn->next=nn;
        head=nn;
    }
    else
    {
        nn->prev=head->prev;
        nn->next=head;

        head->prev=nn;
        nn->prev->next=nn;
        head=nn;
    }
}
void InsertEnding(Node*& head, char* name)
{
    if (!name) Error("void ReadFile(Node*& head): Invalid name pointer");
    Node *nn = new Node;
    strncpy(nn->name,name,STR_MAX);
    if (!head) //list is empty
    {
        nn->prev=nn;
        nn->next=nn;
        head=nn;
    }
    else
    {
        nn->prev=head->prev->next;
        nn->next=head;

        head->prev->next=nn;
        head->prev=nn;
    }
}
