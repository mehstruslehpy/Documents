#include <iostream>
#include <fstream>

using namespace std;

//the doubly linked list node struct
struct Node
{
    int data;
    Node* next;
    Node* prev;
};

//read in input.txt
void ReadFile(Node*& head, Node*& tail);

//traverse from the front to the end right to fout
void TraverseFwd(Node* head,ostream& fout);

//delete a whole list to clean up
void DeleteList(Node*& head);

//delete an item counting from the start
void DelFromStart(Node*& head,Node*& tail,int usernum);

//delete an item counting from the end
void DelFromEnd(Node*& head,Node*& tail,int usernum);

//print an error message and throw
void Error(const char* errmsg);


int main()
{
	//variables
	Node* head = NULL;
	Node* tail = NULL;
	int usernum = -1;	
	ofstream outf("output.txt");
	
	//set up the list
	ReadFile(head,tail);
	cout << "Input list:" << endl;
	TraverseFwd(head,cout);
	outf << "Input list:" << endl; //also output to output.txt
	TraverseFwd(head,outf);

	//prompt for deletion from beginning then output
	cout << "Which item do you want to delete from the beginning?" << endl;
	cin >> usernum;
	DelFromStart(head,tail,usernum);
	cout << "Result: " << endl;
	TraverseFwd(head,cout);
	outf << "Result of delete from beginning:"<< endl;
	TraverseFwd(head,outf);
	
	//prompt for deletion from end then output
	cout << "Which item do you want to delete from the end?" << endl;
	cin >> usernum;
	DelFromEnd(head,tail,usernum);
	cout << "Result: " << endl;
	TraverseFwd(head,cout);
	outf << "Result of delete from end:"<< endl;
	TraverseFwd(head,outf);

	//if necessary clean up
	if (head) DeleteList(head);
}

void DelFromEnd(Node*& head,Node*& tail,int usernum)
{
	//check that tail and head are good and check usernum too
	if (!head||!tail) Error("ERROR:void DelFromEnd(Node*& head,int usernum): Cannot delete from empty list.");
	if (usernum<0) Error("ERROR:void DelFromEnd(Node*& head,int usernum): Invalid node selected for deletion.");
	
	Node* curr = tail;
	
	//count to the selected node
	for (int i = 1; i < usernum;i++)
	{
		if(curr->prev)
		{
			curr=curr->prev;
		}
		else //without counting the list this is the only way I know of to catch whether usernum is invalid
		{
			Error("ERROR:void DelFromEnd(Node*& head,int usernum): Invalid node selected for deletion.");
		}
	}

	//if curr->prev exists then this is not the head, so we need to fix the connections
	//on the next part of the prev node
	if (curr->prev)
	{
		curr->prev->next = curr->next;
	}
	else
	{	//if it is the head then slide the head forward one node
		head = curr->next;
		//TODO:
		head->prev = NULL; //update the prev of the new head
	}

	//if curr->next exists then this is not the tail, so we need to fix the connections
	//on the prev part of the next node
	if (curr->next)
	{
		curr->next->prev = curr->prev;
	}
	else
	{	//if it is the tail then slide the tail back one node
		tail = curr->prev;
		tail->next = NULL; //update the next of the new tail
	}

	//clean up the snipped out node
	delete curr;
}

void DelFromStart(Node*& head,Node*& tail,int usernum)
{
	if (!head||!tail) Error("ERROR:void DelFromStart(Node*& head,int usernum): Cannot delete from empty list.");
	if (usernum<0) Error("ERROR:void DelFromStart(Node*& head,int usernum): Invalid node selected for deletion.");
	
	Node* curr = head;

	//do the same thing as DelFromEnd but find the node from the head moving towards the tail
	for (int i = 1; i < usernum;i++)
	{
		if(curr->next)
		{
			curr=curr->next;
		}
		else 
		{
			Error("ERROR:void DelFromStart(Node*& head,int usernum): Invalid node selected for deletion.");
		}
	}

	if (curr->prev)
	{
		curr->prev->next = curr->next;
	}
	else
	{
		head = curr->next;
	}
	
	if (curr->next)
	{
		curr->next->prev = curr->prev;
	}
	else
	{
		tail = curr->prev;
	}

	delete curr;
}

void Error(const char* errmsg)
{
    cout << errmsg << endl;
    throw;
}

void ReadFile(Node*& head, Node*& tail)
{
    //can't build a new list if head or tail already points to one
    if (head||tail) Error("ERROR:void ReadFile(Node*& head, Node*& tail): head is not empty.");
    //setup for file io
    ifstream infile("input.txt");
    int filevalue = 0;

	//setup first element
	if(infile >> filevalue)
	{
		head = new Node;
		head->prev = NULL;
		head->next = NULL;
		head->data = filevalue;
		tail=head;
	}
	else Error("ERROR:void ReadFile(Node*& head, Node*& tail): File was empty.");
	//setup rest of elements
    while (infile >> filevalue)
    {
   		tail->next = new Node;
		tail->next->data = filevalue;
		tail->next->prev = tail;
		tail->next->next = NULL;
		tail = tail->next;
	}
}

void TraverseFwd(Node* head,ostream& fout)
{
    //don't print anything for empty lists 
    if (!head) return;

    //print the first item
    fout << head->data;
    //print the rest
    while (head->next)
    {
        head=head->next;
        fout << " : " << head->data;
    }
    fout << endl;
}

void DeleteList(Node*& head)
{
    if (!head) Error("ERROR:void DeleteList(Node*& head): Cannot delete empty list");
    Node* temp = NULL;
    while (head->next)
    {
        temp = head->next;
        delete head;
        head=temp;
    }
    temp = head->next;
    delete head;
    head=temp;
}
