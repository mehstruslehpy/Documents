chars=abcd1234ABCD
for i in {1..8} ; do
    echo -n ${chars:RANDOM%${#chars}:1}
	done
	echo
