#!/bin/bash

rm input.txt
touch input.txt

RANDCOUNT=$(( ( RANDOM % 20 )  + 1 ))

for i in `seq 1 $RANDCOUNT`; do
	RANDNUM=$(( ( RANDOM % 41 )  - 20 ))
	chars=abcd1234ABCD
	for i in {1..8} ; do
	    RANDNUM+=${chars:RANDOM%${#chars}:1}
	done
	echo $RANDNUM >> input.txt
done

#valgrind ./main
./main
echo
#echo "Input File:"
#cat input.txt
