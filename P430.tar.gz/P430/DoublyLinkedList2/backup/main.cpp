#include <iostream>
#include <fstream>
#include <cstring> //contains strcmp
using namespace std;

const int MAX = 99;

struct Node
{
    Node* next;
    Node* prev;
    char name[MAX];
};

void ReadFile(Node*& head,Node*& tail);
void Delete(Node*& head, Node*& tail, char* name);
void DeleteList(Node*& head, Node*& tail);
void RemoveNode(Node*& head, Node*& tail, Node* node);
void Insert(Node*& head, Node*& tail, char* name);
void TraverseFwd(Node* head);
void TraverseBack(Node* tail);
void Error(const char *msg);

int main()
{
    Node* head = NULL;
    Node* tail = NULL;
    ReadFile(head,tail);
    TraverseFwd(head);
    TraverseBack(tail);
	DeleteList(head,tail);
    return 0;
}

void DeleteList(Node*& head, Node*& tail)
{
    if (!head) Error("ERROR:");
	while(head)
    {
		Node* temp=head;
		head=head->next;
		delete temp;
    }
	head = tail = NULL;
}
void TraverseFwd(Node* head)
{
    if (!head) Error("ERROR:void TraverseFwd(Node* head): List is empty");
    while(head!=NULL)
    {
        cout << head->name << " ";
        head=head->next;
    }
    cout << endl;
}

void TraverseBack(Node* tail)
{
    if (!tail) Error("ERROR:void TraverseBack(Node* tail): List is empty");
    while(tail!=NULL)
    {
        cout << tail->name << " ";
        tail=tail->prev;
    }
    cout << endl;
}

void ReadFile(Node*& head,Node*& tail)
{
    ifstream infile("input.txt");
    unsigned int delmarker = 6;
    char temp = '\0';
    char instr[MAX];

    //while (infile >> instr)
    while (infile.getline(instr,MAX,'\n'))
    {
        temp = instr[delmarker];
		cout << "DEBUG: instr:" << instr<<endl;
		cout << "DEBUG: instr[delmarker]:" << instr[delmarker]<<endl;
		cout << "DEBUG: instr[delmarker+1]:" << instr[delmarker+1]<<endl;
		instr[delmarker] = '\0';
		cout << "DEBUG: instr:" << instr<<endl;
        if (strcmp("delete",instr)==0)
        {
            cout << "DEBUG: delete keyword1:" << instr << endl;
            cout << "DEBUG: delete keyword2:" << &instr[delmarker+1] << endl;
            Delete(head,tail,&instr[delmarker+1]);
        }
        else
        {
            instr[delmarker]=temp;
            Insert(head,tail,instr);
        }
    }
}
void Delete(Node*& head, Node*& tail, char* name)
{
    for(Node* curr = head; curr!=NULL; curr=curr->next)
    {
        if (strcmp(name,curr->name)==0)
        {
            if (curr->prev)
            {
                curr->prev->next=curr->next;
            }
            else
            {
                head=curr->next;
            }

            if (curr->next)
            {
                curr->next->prev=curr->prev;
            }
            else
            {
                tail=curr->prev;
            }

            delete curr;
            curr = head;
        }
    }
}
void Insert(Node*& head, Node*& tail, char* name)
{
    Node* nn = new Node;
    strncpy(nn->name,name,MAX);

    if (!head) //if this is a brand new list
    {
        nn->next=NULL;
        nn->prev=NULL;
        head=tail=nn;
    }
    else //if it is not a brand new list
    {
		if (strcmp(nn->name,head->name)<0) //nn comes before the head
		{
			nn->next=head;
			nn->prev=NULL;
			head->prev=nn;
			head=nn;
		}
		else if (strcmp(nn->name,tail->name)>=0) //nn comes after or is duplicate of the tail
		{
			nn->prev=tail;
			nn->next=NULL;
			tail->next=nn;
			tail=nn;
		}
		else
		{
        	for(Node* curr = head; curr!=NULL; curr=curr->next)
        	{
				if (strcmp(nn->name,head->name)<0) //nn comes before curr
				{
					nn->next=curr;
					nn->prev=curr->prev;
					curr->prev=nn;
					curr->prev->next=nn;
    				break;
				}
        	}
		}
    }
}

void Error(const char *msg)
{
    cout << msg << endl;
    throw;
}
