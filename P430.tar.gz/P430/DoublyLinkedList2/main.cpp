#include <iostream>
#include <fstream>
#include <cstring> //contains strcmp

using namespace std;

const int MAX = 99;

struct Node
{
    Node* next;
    Node* prev;
    char name[MAX];
};

void ReadFile(Node*& head,Node*& tail);
void Delete(Node*& head, Node*& tail, char* name);
void DeleteList(Node*& head, Node*& tail);
void RemoveNode(Node*& head, Node*& tail, Node* node);
void Insert(Node*& head, Node*& tail, char* name);
void TraverseFwd(Node* head);
void TraverseBack(Node* tail);
void Error(const char *msg);

int main()
{
    Node* head = NULL;
    Node* tail = NULL;
    ReadFile(head,tail);
    cout << "Forwards:" << endl;
	TraverseFwd(head);
    cout << "Backwards:" << endl;
    TraverseBack(tail);
	DeleteList(head,tail);
    return 0;
}

void DeleteList(Node*& head, Node*& tail)
{
    if (!head) Error("ERROR:void DeleteList(Node*& head, Node*& tail): Malformed list head cannot be NULL");
    if (!tail) Error("ERROR:void DeleteList(Node*& head, Node*& tail): Malformed list tail cannot be NULL");
	while(head)
    {
		Node* temp=head;
		head=head->next;
		delete temp;
    }
	head = tail = NULL;
}
void TraverseFwd(Node* head)
{
    if (!head) Error("ERROR:void TraverseFwd(Node* head): List is empty");
    while(head!=NULL)
    {
        cout << head->name << " ";
        head=head->next;
    }
    cout << endl;
}

void TraverseBack(Node* tail)
{
    if (!tail) Error("ERROR:void TraverseBack(Node* tail): List is empty");
    while(tail!=NULL)
    {
        cout << tail->name << " ";
        tail=tail->prev;
    }
    cout << endl;
}

void ReadFile(Node*& head,Node*& tail)
{
    ifstream infile("input.txt");
    unsigned int delmarker = 6;
    char temp = '\0';
    char instr[MAX];

	//read a line
    while (infile.getline(instr,MAX,'\n'))
    {
		//store this char for if we need to insert the string
		temp = instr[delmarker];
		//chop the string into two strings
		instr[delmarker] = '\0';
        if (strcmp("delete",instr)==0) //if the first part is "delete"
        {
            Delete(head,tail,&instr[delmarker+1]); //then delete the second part from the list
        }
        else //if not then restore the orignal string and insert it
        {
            instr[delmarker]=temp;
            Insert(head,tail,instr);
        }
    }
}
void Delete(Node*& head, Node*& tail, char* name)
{
	if (!head) Error("ERROR:void Delete(Node*& head, Node*& tail, char* name): Malformed list head cannot be NULL");
	if (!tail) Error("ERROR:void Delete(Node*& head, Node*& tail, char* name): Malformed list tail cannot be NULL");
	if (!name) Error("ERROR:void Delete(Node*& head, Node*& tail, char* name): Cannot pass NULL string");
	
	for(Node* curr = head; curr!=NULL; curr=curr->next)
    {
        if (strcmp(name,curr->name)==0)
        {
            if (curr->prev)
            {
                curr->prev->next=curr->next;
            }
            else
            {
                head=curr->next;
            }

            if (curr->next)
            {
                curr->next->prev=curr->prev;
            }
            else
            {
                tail=curr->prev;
            }

            delete curr;
            curr = head;
        }
    }
}

void Insert(Node*& head, Node*& tail, char* name)
{
	if (!name) Error("ERROR:void Insert(Node*& head, Node*& tail, char* name): Cannot pass NULL string");

	//allocate the node to insert into the list
    Node* nn = new Node;
    strncpy(nn->name,name,MAX);

    if (!head) //if this is a brand new list
    {
        nn->next=NULL;
        nn->prev=NULL;
        head=tail=nn;
    }
    else //if it is not a brand new list
    {
		if (strcmp(nn->name,head->name)<0) //if nn comes before the head
		{
			nn->next=head;
			nn->prev=NULL;
			head->prev=nn;
			head=nn;
		}
		else if (strcmp(nn->name,tail->name)>=0) //if nn comes after or is duplicate of the tail
		{
			nn->prev=tail;
			nn->next=NULL;
			tail->next=nn;
			tail=nn;
		}
		else //for all other cases
		{
			//iterate down the list
       		for(Node* curr = head; curr!=NULL; curr=curr->next)
        	{
				if (strcmp(nn->name,curr->name)<0) //once nn comes before curr insert it
				{
					nn->next=curr;
					nn->prev=curr->prev;
					curr->prev->next=nn;
					curr->prev=nn;
    				break;
				}
        	}
		}
    }
}

void Error(const char *msg)
{
    cout << msg << endl;
    throw;
}
