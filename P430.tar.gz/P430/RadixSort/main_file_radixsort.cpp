#include <iostream>
#include <fstream>
using namespace std;

//the base for radix sort
const unsigned BASE = 10;

//basic structs
struct Node
{
    Node* next=NULL;
    Node* prev=NULL;
    int data;
};
struct Queue
{
    Node* front=NULL;
    Node* rear=NULL;
};
//useful for specifying sort order
enum SortOrder
{
    ASCENDING,
    DESCENDING
};

//Radix sort
void RadixSort(Queue& inq,SortOrder ord);
//Basic Queue functions along with push to allow for descending order
inline void Enqueue(Queue& q,int data);
inline int Dequeue(Queue& q);
inline void PushToQ(Queue& q);
//utility functions
void ReadFile(Queue& q,ifstream& inf);
inline void DeleteQueue(Queue& q);
inline void PrintQueue(Queue q);

int main()
{
    ifstream inf("input.txt");
    Queue workingq{NULL,NULL};

    //read, sort, and print in ascending order
    ReadFile(workingq,inf);
    cout << "Starting Queue:" << endl;
    PrintQueue(workingq);
    RadixSort(workingq,ASCENDING);
    cout << "Ascending Queue:" << endl;
    PrintQueue(workingq);

    //reset the queue
    DeleteQueue(workingq);
    inf.close();
    inf.open("input.txt");

    //read sort and print in descending order
    ReadFile(workingq,inf);
    cout << "Reset Queue:" <<endl;
    PrintQueue(workingq);
    RadixSort(workingq,DESCENDING);
    cout << "Descending Queue:" << endl;
    PrintQueue(workingq);

    //clean up anything leftover
    DeleteQueue(workingq);
    return 0;
}

inline void Enqueue(Queue& q,int data)
{
    if (q.front==NULL||q.rear==NULL)
    {
        q.front=q.rear=new Node;
        q.front->data=data;
        q.front->next=q.front->prev=NULL;
    }
    else
    {
        q.rear->next=new Node;
        q.rear->next->data=data;
        q.rear->next->next=NULL;
        q.rear->next->prev=q.rear;
        q.rear=q.rear->next;
    }
}
inline int Dequeue(Queue& q)
{
    int retval;
    if (q.front->next==NULL)
    {
        retval=q.front->data;
        delete q.front;
        q.front=q.rear=NULL;
        return retval;
    }
    else
    {
        Node* oldfront = q.front;
        retval=oldfront->data;
        q.front=q.front->next;
        delete oldfront;
        return retval;
    }
}
inline void PushToQ(Queue& q,int data)
{
    if (q.front==NULL||q.rear==NULL)
    {
        q.front=q.rear=new Node;
        q.front->data=data;
        q.front->next=q.front->prev=NULL;
    }
    else
    {
        Node* newFront=new Node;
        newFront->data=data;
        newFront->next=q.front;
        newFront->prev=NULL;
        q.front->prev=newFront;
        q.front=newFront;
    }
}

inline void PrintQueue(Queue q)
{
    if (q.front==NULL) 
	{
		cout << endl;
		return;
	}
    Node* curr = q.front;
    while (curr->next!=NULL)
    {
        cout << curr->data << " ";
        curr=curr->next;
    }
    cout << curr->data << endl;
}
inline void DeleteQueue(Queue& q)
{
    while (q.rear!=NULL)
    {
        Dequeue(q);
    }
}
inline int FindMax(Queue& q)
{
    Node* curr = q.front;
    int max = q.front->data;
    for (; curr; curr=curr->next)(max<curr->data)?(max=curr->data):(max=max);
    return max;
}
inline void PrintQueueArray(Queue qs[BASE],unsigned base)
{
	for (unsigned i=0;i<base;i++)
	{
		cout <<"DEBUG:qs["<<i<<"]: ";
		PrintQueue(qs[i]);
	}
}
void RadixSort(Queue& q,SortOrder ord)
{
    int DEBUG_COUNT=0;
    Queue qs[BASE];
	for (int LSD,temp,N=1,M=BASE,MAX=FindMax(q);N<=MAX;M*=BASE,N*=BASE)
    {
        cout << "DEBUG:iteration:"<<DEBUG_COUNT++<<endl;
        //place each element at the appropriate element of qs
        while (q.front)
        {
            temp = Dequeue(q);
            LSD = (temp%M)/N;
			if (ord==ASCENDING) Enqueue(qs[LSD],temp);
            else PushToQ(qs[LSD],temp);
        }
       	PrintQueueArray(qs,BASE);
		//remove each element of qs in order into the original queue
        for (unsigned i=0; i<BASE; i++)
            while(qs[i].front)
				if (ord==ASCENDING) Enqueue(q,Dequeue(qs[i]));
				else PushToQ(q,Dequeue(qs[i]));
		cout <<"DEBUG:q:";
		PrintQueue(q);
		cout << endl;
    }

}
void ReadFile(Queue& q,ifstream& inf)
{
    int temp;
    while(inf >> temp) Enqueue(q,temp);
}
