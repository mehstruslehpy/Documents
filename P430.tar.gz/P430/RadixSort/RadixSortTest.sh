#!/bin/bash

rm input.txt
touch input.txt

RANDCOUNT=$(( ( RANDOM % 20)  + 1 ))

for i in `seq 1 $RANDCOUNT`; do
	RANDNUM=$(( ( RANDOM % 99999 )  + 1 ))
	echo $RANDNUM >> input.txt
done

#valgrind ./main
echo
./main_file_radixsort
echo
echo "Line Count:"
wc -l input.txt
echo
echo "Input File:"
cat input.txt
