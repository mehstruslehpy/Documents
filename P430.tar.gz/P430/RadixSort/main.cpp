#include <iostream>
using namespace std;

//the base for radix sort
const unsigned int BASE = 10;

//basic structs
struct Node
{
    Node* next = NULL;
    Node* prev = NULL;
    int data;
};
struct Queue
{
    Node* front = NULL;
    Node* rear = NULL;
};
//useful for specifying sort order
enum SortOrder
{
    ASCENDING,
    DESCENDING
};

//Radix sort
void RadixSort(Queue& inq,SortOrder ord);
//Basic Queue functions along with push to allow for descending order
void Enqueue(Queue& q,int data);
int Dequeue(Queue& q);
void PushToQ(Queue& q);
//utility functions
void ReadArray(Queue& q);
void DeleteQueue(Queue& q);
void PrintQueue(Queue q);

int main()
{
    Queue workingq{NULL,NULL};

    //read, sort, and print in ascending order
    ReadArray(workingq);
    cout << "Starting Queue:" << endl;
    PrintQueue(workingq);
    RadixSort(workingq,ASCENDING);
    cout << "Ascending Queue:" << endl;
    PrintQueue(workingq);

    //reset the queue
    DeleteQueue(workingq);

    //read sort and print in descending order
    ReadArray(workingq);
    cout << "Reset Queue:" <<endl;
    PrintQueue(workingq);
    RadixSort(workingq,DESCENDING);
    cout << "Descending Queue:" << endl;
    PrintQueue(workingq);

    //clean up anything leftover
    DeleteQueue(workingq);
    return 0;
}

void Enqueue(Queue& q,int data)
{
    if (q.front==NULL||q.rear==NULL)
    {
        q.front=q.rear=new Node;
        q.front->data=data;
        q.front->next=q.front->prev=NULL;
    }
    else
    {
        q.rear->next=new Node;
        q.rear->next->data=data;
        q.rear->next->next=NULL;
        q.rear->next->prev=q.rear;
        q.rear=q.rear->next;
    }
}
int Dequeue(Queue& q)
{
    int retval;
    if (q.front->next==NULL)
    {
        retval=q.front->data;
        delete q.front;
        q.front=q.rear=NULL;
        return retval;
    }
    else
    {
        Node* oldfront = q.front;
        retval=oldfront->data;
        q.front=q.front->next;
        delete oldfront;
        return retval;
    }
}
void PushToQ(Queue& q,int data)
{
    if (q.front==NULL||q.rear==NULL)
    {
        q.front=q.rear=new Node;
        q.front->data=data;
        q.front->next=q.front->prev=NULL;
    }
    else
    {
        Node* newFront=new Node;
        newFront->data=data;
        newFront->next=q.front;
        newFront->prev=NULL;
        q.front->prev=newFront;
        q.front=newFront;
    }
}

void PrintQueue(Queue q)
{
    if (q.front==NULL) return;
    Node* curr = q.front;
    while (curr->next!=NULL)
    {
        cout << curr->data << " ";
        curr=curr->next;
    }
    cout << curr->data << endl;
}
void DeleteQueue(Queue& q)
{
    while (q.rear!=NULL)
    {
        Dequeue(q);
    }
}
int FindMax(Queue& q)
{
    Node* curr = q.front;
    int max = q.front->data;
    for (; curr; curr=curr->next)(max<curr->data)?(max=curr->data):(max=max);
    return max;
}
void RadixSort(Queue& q,SortOrder ord)
{
    Queue qs[BASE];
    //the least significant digit
    int LSD;
    int temp;
    int N=1;
    int M=BASE;
    //get the max
    int MAX = FindMax(q);
    //while N<Max the largest item in the queue
    while (N<=MAX)
    {
        //place each element at the appropriate element of qs
        while (q.front)
        {
            temp = Dequeue(q);
            LSD = (temp%M)/N;
            if (ord==ASCENDING) Enqueue(qs[LSD],temp);
            else PushToQ(qs[LSD],temp);
        }
        //remove each element of qs in order into the original queue
        for (unsigned int i=0; i<BASE; i++)
            while(qs[i].front)
                if (ord==ASCENDING) Enqueue(q,Dequeue(qs[i]));
                else PushToQ(q,Dequeue(qs[i]));
        //increment for the next iteration
        M*=BASE;
        N*=BASE;
    }
}
void ReadArray(Queue& q)
{
    const unsigned int asize = 17;
    int arr[asize] = {323,42,1,4,79,88,42,1387,84,2,0,9,1,0,123,4324,19};
    for (unsigned int i = 0; i < asize; i++) Enqueue(q,arr[i]);
}
