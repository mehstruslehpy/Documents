#include <iostream>
#include <string.h>
using namespace std;
struct Employee 
{
    char name[10]; 
    char gender;
    int emp_no;
};
int main()
{
	Employee arr[2] = {{"Jim",'m',1},{"Sally",'f',2}};
	Employee *emp_ptr[2] = {&arr[0],&arr[1]}; //[] has higher precedence than *, this is a two elem array of pointers to employees

	//using the array
	//notice arr[0].name is equivalent to (arr[0]).name brackets have precedence over .
	cout << "Employee 1: name=" << arr[0].name << " gender="<< arr[0].gender << " employee-number="<< arr[0].emp_no << endl;
	cout << "Employee 2: name=" << arr[1].name << " gender="<< arr[1].gender << " employee-number="<< arr[1].emp_no << endl;
	
	cout << "-----------------------------------------------------------------------------------------------" << endl;
	
	//using array of pointers
	cout << "Employee 1: name=" << emp_ptr[0]->name << " gender="<< emp_ptr[0]->gender << " employee-number="<< emp_ptr[0]->emp_no << endl;
	cout << "Employee 2: name=" << emp_ptr[1]->name << " gender="<< emp_ptr[1]->gender << " employee-number="<< emp_ptr[1]->emp_no << endl;

	cout << "-----------------------------------------------------------------------------------------------" << endl;

	//using array of pointers
	cout << "Employee 1: name=" << (*((emp_ptr)[0])).name << " gender="<< emp_ptr[0]->gender << " employee-number="<< emp_ptr[0]->emp_no << endl;
	cout << "Employee 2: name=" << (*(*emp_ptr+1)).name << " gender="<< emp_ptr[1]->gender << " employee-number="<< emp_ptr[1]->emp_no << endl;
}
