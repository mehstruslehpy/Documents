#include <iostream>
#include <string.h>
using namespace std;
int main()
{
	int a[10] = {1,2,3};
	cout << "->" << a << " "<< &a << " "<< &a[0] << endl;
}
