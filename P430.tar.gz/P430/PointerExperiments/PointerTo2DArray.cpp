#include <iostream>
#include <string.h>
using namespace std;
int main()
{
	int array[2][2] = {{1,2},{3,4}};
	int (*ptr)[2] = array;
	cout << ptr[0][0] << " " << ptr[0][1] << endl;
	cout << ptr[1][0] << " " << ptr[1][1] << endl;
}
