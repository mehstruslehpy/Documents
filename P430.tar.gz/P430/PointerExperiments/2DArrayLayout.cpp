#include <iostream>
#include <string.h>
using namespace std;
int main()
{
	int array[2][2] = {{1,2},{3,4}};
	cout << "array:" << array << endl; 
	cout << "&array:" << &array << endl;
	cout << "array[0]:" << array[0] << endl; 
	cout << "&array[0]:" << &array[0] << endl;
	cout << "array[0][0]:" << array[0][0] << endl;
	cout << "&array[0][0]:" << &array[0][0] << endl;
	cout << "&*(*(array + 0) + 0):" << &*(*(array + 0) + 0)<< endl;
	cout << "array[1]:" << array[1] << endl; 
	cout << "&array[1]:" << &array[1] << endl;
	cout << "array[1][0]:" << array[1][0] << endl;
	cout << "&array[1][0]:" << &array[1][0] << endl;

}
