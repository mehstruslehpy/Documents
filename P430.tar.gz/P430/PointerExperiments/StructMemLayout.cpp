#include <iostream>
#include <string.h>
using namespace std;
struct SimpleStruct
{
    char str[3]; 
    int nums[3];
    int num;
};
//this is a pass by copy
SimpleStruct func(SimpleStruct yours)
{
    cout << "&yours: " << &yours << endl;
    
    cout << "yours.str: " << yours.str << endl;
    cout << "&yours.str: " << &yours.str << endl;
    
    cout << "yours.nums: " << yours.nums << endl;
    cout << "yours.nums[0]: " << yours.nums[0] << endl;
    cout << "&yours.nums: " << &yours.nums << endl;

    cout << "yours.num: " << yours.num << endl;
    cout << "&yours.num: " << &yours.num << endl;
    cout << "addr:val: " << &yours.nums[0] << ":" << yours.nums[0] << "   "
         << &yours.nums[1] << ":" << yours.nums[1] << "   "
         << &yours.nums[2] << ":" << yours.nums[2] << endl;

    yours.nums[0]=4,yours.nums[1]=5,yours.nums[2]=6;
    return yours;
}
int main()
{
    SimpleStruct mine = {"hi",{1,2,3},2};
    //cout << "mine" << mine << endl; //wrong
    cout << "----------------------------------------"<< endl;
    cout << "&mine: " << &mine << endl;
    
    cout << "mine.str: " << mine.str << endl;
    cout << "&mine.str: " << &mine.str << endl;
    
    cout << "mine.nums: " << mine.nums << endl;
    cout << "mine.nums[0]: " << mine.nums[0] << endl;
    cout << "&mine.nums: " << &mine.nums << endl;

    cout << "mine.num: " << mine.num << endl;
    cout << "&mine.num: " << &mine.num << endl;
    cout << "addr:val: " << &mine.nums[0] << ":" << mine.nums[0] << "   "
         << &mine.nums[1] << ":" << mine.nums[1] << "   "
         << &mine.nums[2] << ":" << mine.nums[2] << endl;

    cout << "----------------------------------------"<< endl;
    mine = func(mine);
    cout << "----------------------------------------"<< endl;
    cout << "&mine: " << &mine << endl;
    
    cout << "mine.str: " << mine.str << endl;
    cout << "&mine.str: " << &mine.str << endl;
    
    cout << "mine.nums: " << mine.nums << endl;
    cout << "mine.nums[0]: " << mine.nums[0] << endl;
    cout << "&mine.nums: " << &mine.nums << endl;

    cout << "mine.num: " << mine.num << endl;
    cout << "&mine.num: " << &mine.num << endl;
    cout << "addr:val: " << &mine.nums[0] << ":" << mine.nums[0] << "   "
         << &mine.nums[1] << ":" << mine.nums[1] << "   "
         << &mine.nums[2] << ":" << mine.nums[2] << endl;


}
