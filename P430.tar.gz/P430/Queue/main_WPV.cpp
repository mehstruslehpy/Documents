#include <iostream>
#include <fstream>

//queues are implemented in terms of Nodes
struct Node
{
    int data;
    Node* next;
};

//takes data front and rear, if front is null start a new queue, if not
//add to the end of the current queue. 
void Enqueue(Node*& front,Node*& rear,int data);

//takes only front remove and dealloc the front of the queue return its value
int Dequeue(Node*& front);

//read from the file "input.txt" store each integer into the queue represented
//by front and rear using only the Dnqueue and Dequeue functions
void BuildQueue(Node*& front, Node*& rear);

//Print the queue
void Traverse(Node* front);

//Remove all the negative elements from the queue represented by front and rear
void RemoveNegatives(Node*& front, Node*& rear);

//delete the queue using the Dequeue function
void DeleteQueue(Node*& front);

//print an error message and throw
void Error(const char* errmsg);

using namespace std;

int main()
{
	//pointers to the front and rear
    Node *front = NULL;
    Node *rear = NULL;

	//BuildQueue only uses Enqueue to modify the queue
    cout << "BuildQueue..." << endl;
    BuildQueue(front,rear);
    
	//traverse once
	cout << "Before negative removal" << endl;
    Traverse(front);
    
	//remove any negatives
	RemoveNegatives(front,rear);
    
	//traverse again
	cout << "After negative removal" << endl;
    Traverse(front);

	//clean up
    DeleteQueue(front);
}
void Error(const char* errmsg)
{
    cout << errmsg << endl;
    throw;
}

void Enqueue(Node*& front,Node*& rear,int data)
{
	//if front is null the queue is empty
    if (!front)
    {
        front = new Node;
        front->next=NULL;
        front->data=data;
        rear=front;
    }
    else //if not the queue has items so we have to add new stuff to the rear
    {
        rear->next = new Node;
        rear->next->data = data;
        rear->next->next = NULL;
        rear=rear->next;
    }
}

int Dequeue(Node*& front)
{
	//handle front is null case
    if (!front) Error("ERROR:void Dequeue(Node*& front): Nothing to dequeue.");

	//if not remove from the front
    Node* tempnode = front;
    int retval = front->data;
    front = front->next;
    delete tempnode;
    return retval;
}
void BuildQueue(Node*& front, Node*& rear)
{
	//can't build a new queue if front already points to one
    if (front) Error("ERROR:void BuildQueue(Node*& front, Node*& rear: Front is not empty.");
	//setup for file io
    ifstream infile("input.txt");
    int filevalue = 0;
	//read through the file and enqueue each element
    while (infile >> filevalue)
    {
        Enqueue(front,rear,filevalue);
    }
}
void Traverse(Node* front)
{
	//don't print anything for empty queues
    if (!front) return;

	//print the first item
    cout << front->data;
	//print the rest
    while (front->next)
    {
        front=front->next;
        cout << " : " << front->data;
    }
    cout << endl;
}

void RemoveNegatives(Node*& front, Node*& rear)
{
	//must have both front and rear pointers
    if (!front||!rear) Error("ERROR:void RemoveNegatives(Node*& front, Node*& rear: Malformed queue pointers.");
    int temp;
	//use this to track the rear pointer at the very start of the algorithm
    Node* qptr = rear;

	//handle one element queues separately
    if (front==rear)
    {
		temp=Dequeue(front);
		if (temp>=0)
        {
			Enqueue(front,rear,temp);
		}
    	return;
	}

    //if we make it hear we have at least two elements to check
	//loop from front to qptr (the original rear) via Dequeue and Enqueue
	while(qptr!=front)
    {
        temp = Dequeue(front);
        if (temp >= 0) Enqueue(front,rear,temp);
    }
	//check the final element and rotate us back into the starting ordering
    temp=Dequeue(front);
    if(temp>=0)Enqueue(front,rear,temp);
}

//just use dequeue to remove all the elements
void DeleteQueue(Node*& front)
{
    while(front)
    {
        Dequeue(front);
    }
}
