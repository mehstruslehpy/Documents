#include <iostream>
#include <fstream>
#include <string>
using namespace std;
template<typename T>
struct LNode
{
    LNode<T>* next = NULL;
    T name;
};

template<typename T>
struct BSTNode
{
    BSTNode<T>* left = NULL;
    BSTNode<T>* right = NULL;
    LNode<T>* duplicates = NULL;
    T name;
};

template <typename T>
class AbstractTree
{
	//AbstractNode<T>* _root;
public:
	void Insert(T);
};
//push a duplicate node on the list
template<typename T>
void LNodePush(LNode<T>*&,T name);
//add a node to the tree
template<typename T>
void AddBSTNode(BSTNode<T>*&leaf, T name);
//insert a node at the node "leaf"
template<typename T>
void Insert(BSTNode<T>*& leaf, T name);
//read a list of names from the file building a tree as it goes
template<typename T>
void ReadFile(BSTNode<T>*& root);
//search a tree for a name
template<typename T>
void SearchTree(BSTNode<T>* root,T name);
//print a linked list
template<typename T>
void PrintList(LNode<T>* node);
//print an error message
void Error(const string);
//clean up functions
template<typename T>
void DeleteTree(BSTNode<T>*&);
template<typename T>
void DeleteList(LNode<T>*&);

//just for fun and (debugging) I put in functionality to print the tree in a graph visualization language
//called DOT so I could generate pictures of my tree these are at the end so they stay out of the way
template<typename T>
void DotLangPrint(BSTNode<T>*& root,ofstream&);
template<typename T>
void DotHandler(BSTNode<T>*& node,ofstream&);

int main()
{
	BSTNode<string>* root = NULL;
	string searchname = "";
	//read the tree
	ReadFile<string>(root);
	cout << "Enter a name to search for:"<<endl;
	cin >> searchname;
	//search the tree
	SearchTree(root,searchname);
	cout << "Would you like to print a DOT language version of the tree? (yes/no)" << endl;
	cin >> searchname;
	cout << endl;
	//print the DOT language version of the tree if needed
	if (searchname=="yes") 
	{
		ofstream outfile("output.txt");
		DotLangPrint(root,outfile);
		outfile.close();
	}
	//clean up
	DeleteTree(root);
	return 0;
}
template<typename T>
void DeleteTree(BSTNode<T>*& node)
{
	if (node==NULL) return;
	//delete the list
	if (node->duplicates!=NULL) DeleteList(node->duplicates);
	
	//delete the leaves first
	if (node->left!=NULL) DeleteTree(node->left);
	if (node->right!=NULL) DeleteTree(node->right);
	
	//delete the current node
	delete node;
	node=NULL;
}
template<typename T>
void DeleteList(LNode<T>*& node)
{
	//iterate across the list and delete each node
	LNode<T>* cur = node;
	while (cur->next)
	{
		cur=cur->next;
		delete node;
		node=cur;
	}
}
template<typename T>
void Error(const T msg)
{
	cout << "ERROR:"<<msg<<endl;
	throw;
}
//push duplicates onto the duplicate list
template<typename T>
void LNodePush(LNode<T>*& node,T name)
{
	if(node==NULL)
	{
		node  = new LNode<T>{NULL,name};
	}
	else
	{
		LNode<T>* temp = new LNode<T>{node,name};
		node=temp;
	}
}
//read each name from a file and add it to the tree
template<typename T>
void ReadFile(BSTNode<T> *& root)
{
	if (root!=NULL) Error("void ReadFile(BSTNode<T> *& root): root must be NULL.");
	fstream inf("input.txt");
	T temp = "";
	while (inf >> temp)
	{
		Insert(root,temp);
	}
}
//print the list use the same addr: name format as the tree nodes
template<typename T>
void PrintList(LNode<T> * node)
{
	if (node==NULL) return;
	LNode<T>* cur = node;
	while(cur->next)
	{
		cout << &cur <<": " <<cur->name<<endl;
		cur=cur->next;
	}
	cout << &cur <<": " <<cur->name<<endl;
}
//add a node at leaf modified from your notes
template<typename T>
void AddBSTNode(BSTNode<T> *&leaf, T name)
{
    leaf=new BSTNode<T>;
    leaf->name=name;
    leaf->left=NULL;
    leaf->right=NULL;
}
//find and insert a node larger on goes on left, smaller on right
//duplicates to the duplicate list
template<typename T>
void Insert(BSTNode<T> *& leaf, T name)
{
	if (!leaf)
    {
        // Insertion place found.
		AddBSTNode<T>(leaf,name);
	}
    else if (name > leaf->name)
    {
        //Insert in left subtree.
        Insert(leaf->left, name);
    }
    else if (name < leaf->name)
    {
        //Insert in right subtree.
        Insert(leaf->right, name);
    }
	else if (name == leaf->name)
	{
		//add duplicates to linked list
		LNodePush(leaf->duplicates,name);
	}
}
//search the tree and print the path as you go
template<typename T>
void SearchTree(BSTNode<T>* node,T name)
{
	if (!node)
    {
		cout << name << " was not found" << endl;
	}
    else if (name > node->name)
    {
		cout << &node << ": " << node->name<<endl; 
        SearchTree(node->left, name);
    }
    else if (name < node->name)
    {
		cout << &node << ": " << node->name<<endl; 
        SearchTree(node->right, name);
    }
	else if (name == node->name)
	{
		cout << &node << ": " << node->name<<endl; 
		if (node->duplicates!=NULL)PrintList(node->duplicates);
		cout << name << " was found" << endl;
	}
}

/*---------------------------------------------------------------------------*/
/*---------------------------------------------------------------------------*/
//graphviz output stuff
/*---------------------------------------------------------------------------*/
/*---------------------------------------------------------------------------*/

template<typename T>
void DotLangPrint(BSTNode<T>*& root,ofstream& outf)
{
	if (root==NULL) Error("void DotLangPrint(BSTNode<T>* root): root must not be NULL.");
	outf << "digraph names\n{"<<endl;
	outf << "\tnodesep=0.01"<<endl;
	DotHandler(root,outf);
	outf <<"\tinfo[shape=box label=\"the linked list uses dashed connections and boxes\\n the tree uses solid connections and ovals\"]" << endl;
	outf << "}"<<endl;
	
	outf << endl << endl << "//You can copy and paste this code";
	outf << "//to one of the following sites to see a diagram of the tree"<< endl;
	outf << "//http://webgraphviz.com/" << endl;
	outf << "//https://dreampuf.github.io/GraphvizOnline/" << endl;
	outf << "//http://viz-js.com/" << endl;
	outf << "//or use some other graphviz/DOT language viewer" << endl;
	outf << "//more info about graphviz can be found here:" << endl;
	outf << "//https://www.graphviz.org/about/" << endl;

}
template<typename T>
void DotHandler(BSTNode<T>*& node,ofstream& outf)
{
	static long invisnode = 0;
	//print the connecting nodes
	if (node->left==NULL)
	{
		outf << "\t"<<long(&node)<< " -> "<<++invisnode<<"[style=invis]//left branch is null"<<endl;
		outf << "\t" << invisnode << "[style=invis]"<<endl;
	}
	else
	{
		outf << "\t"<<long(&node) << " -> " << long(&(node->left)) << endl;
	}

	//print duplicates
	LNode<T>* cur = node->duplicates;
	long addr1 = long(&node);
	while (cur!=NULL)
	{
		outf << "\t" <<addr1 << " -> " << long(&*cur) <<"[style=dashed];" <<endl;
		outf << "\t" <<long(&*cur)<<"[shape=box label=\""+cur->name<<"\"];"<<endl;
		addr1=long(&*cur);
		cur=cur->next;
	}
	if (cur==NULL)
	{
		outf << "\t"<<long(&node)<< " -> "<<++invisnode<<"[style=invis]//left branch is null"<<endl;
		outf << "\t" << invisnode << "[style=invis]"<<endl;
	}


	if (node->right==NULL)
	{
		outf << "\t"<<long(&node)<< " -> "<<++invisnode<<"[style=invis]//right branch is null"<<endl;
		outf << "\t" << invisnode << "[style=invis]"<<endl;
	}
	else
	{
		outf << "\t" <<long(&node) << " -> " << long(&(node->right)) << endl;
	}

	//recurse
	if(node->left!=NULL)DotHandler(node->left,outf);	
	if(node->right!=NULL)DotHandler(node->right,outf);	
	
	//print the label for the current node
	outf << "\t" <<long(&node)<<"[label=\""+node->name<<"\"];"<<endl;
}

