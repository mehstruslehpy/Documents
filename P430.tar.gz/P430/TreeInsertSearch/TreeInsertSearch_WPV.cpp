#include <iostream>
#include <fstream>
#include <string>
using namespace std;

struct ListNode
{
    ListNode* next = NULL;
    string name = "";
};
struct TreeNode
{
    TreeNode* left = NULL;
    TreeNode* right = NULL;
    ListNode* duplicates = NULL;
    string name;
};
//push a duplicate node on the list
void ListNodePush(ListNode*&,string name);
//add a node to the tree
void AddTreeNode(TreeNode *&leaf, string name);
//insert a node at the node "leaf"
void Insert(TreeNode *& leaf, string name);
//read a list of names from the file building a tree as it goes
void ReadFile(TreeNode *& root);
//search a tree for a name
void SearchTree(TreeNode * root,string name);
//print a linked list
void PrintList(ListNode * node);
//print an error message
void Error(const string);
//clean up functions
void DeleteTree(TreeNode*&);
void DeleteList(ListNode*&);

//just for fun and (debugging) I put in functionality to print the tree in a graph visualization language
//called DOT so I could generate pictures of my tree these are at the end so they stay out of the way
void DotLangPrint(TreeNode*& root);
void DotHandler(TreeNode*& node);

int main()
{
	TreeNode* root = NULL;
	string searchname = "";
	//read the tree
	ReadFile(root);
	cout << "Enter a name to search for:"<<endl;
	cin >> searchname;
	//search the tree
	SearchTree(root,searchname);
	cout << "Would you like to print a DOT language version of the tree? (yes/no)" << endl;
	cin >> searchname;
	cout << endl;
	//print the DOT language version of the tree if needed
	if (searchname=="yes") DotLangPrint(root);
	//clean up
	DeleteTree(root);
	return 0;
}
void DeleteTree(TreeNode*& node)
{
	if (node==NULL) return;
	//delete the list
	if (node->duplicates!=NULL) DeleteList(node->duplicates);
	
	//delete the leaves first
	if (node->left!=NULL) DeleteTree(node->left);
	if (node->right!=NULL) DeleteTree(node->right);
	
	//delete the current node
	delete node;
	node=NULL;
}
void DeleteList(ListNode*& node)
{
	//iterate across the list and delete each node
	ListNode* cur = node;
	while (cur->next)
	{
		cur=cur->next;
		delete node;
		node=cur;
	}
}
void Error(const string msg)
{
	cout << "ERROR:"<<msg<<endl;
	throw;
}
//push duplicates onto the duplicate list
void ListNodePush(ListNode*& node,string name)
{
	if(node==NULL)
	{
		node  = new ListNode{NULL,name};
	}
	else
	{
		ListNode* temp = new ListNode{node,name};
		node=temp;
	}
}
//read each name from a file and add it to the tree
void ReadFile(TreeNode *& root)
{
	if (root!=NULL) Error("void ReadFile(TreeNode *& root): root must be NULL.");
	fstream inf("input.txt");
	string temp = "";
	while (inf >> temp)
	{
		Insert(root,temp);
	}
}
//print the list use the same addr: name format as the tree nodes
void PrintList(ListNode * node)
{
	if (node==NULL) return;
	ListNode* cur = node;
	while(cur->next)
	{
		cout << &cur <<": " <<cur->name<<endl;
		cur=cur->next;
	}
	cout << &cur <<": " <<cur->name<<endl;
}
//add a node at leaf modified from your notes
void AddTreeNode(TreeNode *&leaf, string name)
{
    leaf=new TreeNode;
    leaf->name=name;
    leaf->left=NULL;
    leaf->right=NULL;
}
//find and insert a node larger on goes on left, smaller on right
//duplicates to the duplicate list
void Insert(TreeNode *& leaf, string name)
{
	if (!leaf)
    {
        // Insertion place found.
		AddTreeNode(leaf,name);
	}
    else if (name > leaf->name)
    {
        //Insert in left subtree.
        Insert(leaf->left, name);
    }
    else if (name < leaf->name)
    {
        //Insert in right subtree.
        Insert(leaf->right, name);
    }
	else if (name == leaf->name)
	{
		//add duplicates to linked list
		ListNodePush(leaf->duplicates,name);
	}
}
//search the tree and print the path as you go
void SearchTree(TreeNode* node,string name)
{
	if (!node)
    {
		cout << name << " was not found" << endl;
	}
    else if (name > node->name)
    {
		cout << &node << ": " << node->name<<endl; 
        SearchTree(node->left, name);
    }
    else if (name < node->name)
    {
		cout << &node << ": " << node->name<<endl; 
        SearchTree(node->right, name);
    }
	else if (name == node->name)
	{
		cout << &node << ": " << node->name<<endl; 
		if (node->duplicates!=NULL)PrintList(node->duplicates);
		cout << name << " was found" << endl;
	}
}

/*---------------------------------------------------------------------------*/
/*---------------------------------------------------------------------------*/
//graphviz output stuff
/*---------------------------------------------------------------------------*/
/*---------------------------------------------------------------------------*/

void DotLangPrint(TreeNode*& root)
{
	if (root==NULL) Error("void DotLangPrint(TreeNode* root): root must not be NULL.");
	cout << "digraph names\n{"<<endl;
	cout << "\tnodesep=0.01"<<endl;
	DotHandler(root);
	cout <<"\tinfo[shape=box label=\"the linked list uses dashed connections and boxes\\n the tree uses solid connections and ovals\"]" << endl;
	cout << "}"<<endl;
	
	cout << endl << endl << "You can copy and paste the code: \"digraph names { ... }\" ";
	cout << "at one of the following sites to see a diagram of the tree"<< endl;
	cout << "http://webgraphviz.com/" << endl;
	cout << "https://dreampuf.github.io/GraphvizOnline/" << endl;
	cout << "http://viz-js.com/" << endl;
	cout << "or use some other graphviz/DOT language viewer" << endl;
	cout << "more info about graphviz can be found here:" << endl;
	cout << "https://www.graphviz.org/about/" << endl;

}
void DotHandler(TreeNode*& node)
{
	static long invisnode = 0;
	//print the connecting nodes
	if (node->left==NULL)
	{
		cout << "\t"<<long(&node)<< " -> "<<++invisnode<<"[style=invis]//left branch is null"<<endl;
		cout << "\t" << invisnode << "[style=invis]"<<endl;
	}
	else
	{
		cout << "\t"<<long(&node) << " -> " << long(&(node->left)) << endl;
	}

	//print duplicates
	ListNode* cur = node->duplicates;
	long addr1 = long(&node);
	while (cur!=NULL)
	{
		cout << "\t" <<addr1 << " -> " << long(&*cur) <<"[style=dashed];" <<endl;
		cout << "\t" <<long(&*cur)<<"[shape=box label=\""+cur->name<<"\"];"<<endl;
		addr1=long(&*cur);
		cur=cur->next;
	}
	if (cur==NULL)
	{
		cout << "\t"<<long(&node)<< " -> "<<++invisnode<<"[style=invis]//left branch is null"<<endl;
		cout << "\t" << invisnode << "[style=invis]"<<endl;
	}


	if (node->right==NULL)
	{
		cout << "\t"<<long(&node)<< " -> "<<++invisnode<<"[style=invis]//right branch is null"<<endl;
		cout << "\t" << invisnode << "[style=invis]"<<endl;
	}
	else
	{
		cout << "\t" <<long(&node) << " -> " << long(&(node->right)) << endl;
	}

	//recurse
	if(node->left!=NULL)DotHandler(node->left);	
	if(node->right!=NULL)DotHandler(node->right);	
	
	//print the label for the current node
	cout << "\t" <<long(&node)<<"[label=\""+node->name<<"\"];"<<endl;
}

