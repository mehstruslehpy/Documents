#!/bin/bash

rm input.txt
touch input.txt

RANDCOUNT=$(( ( RANDOM % 20)  + 1 ))

for i in `seq 1 $RANDCOUNT`; do
	RANDSTR=$(./randstr_randlength.sh)
	echo $RANDSTR >> input.txt
done

echo
valgrind ./main |tee output.txt
#./main
#echo
echo "Line Count:"
wc -l input.txt
#echo
#echo "Input File:"
#cat input.txt
