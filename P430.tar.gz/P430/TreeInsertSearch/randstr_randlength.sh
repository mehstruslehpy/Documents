chars=abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890
RANDCOUNT=$(( ( RANDOM % 50 )  + 1 ))
for i in `seq 1  $RANDCOUNT`; do
    echo -n ${chars:RANDOM%${#chars}:1}
	done
echo
