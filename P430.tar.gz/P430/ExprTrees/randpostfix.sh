#!/bin/bash
./prettyPrint.lisp > input.txt #generate the input expression
touch output.txt #clear the output file
./infixtopostfix > output.txt #create the normal output
./infixtopostfix | egrep -i "([0-9]\ )|[0-9]$" | head -1 #filter for a digit followed by a space (which is just postfix expressions from my programs output)
