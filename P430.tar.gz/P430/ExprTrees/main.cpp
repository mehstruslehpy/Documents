#include <iostream>
#include <sstream>
#include <math.h>

using namespace std;

//basic data enums and functions
enum EXPR_TYPE
{
    OPERATOR,
    OPERAND
};
enum OPERATOR_TYPE
{
    ADD_EXPR,
    SUB_EXPR,
    MUL_EXPR,
    DIV_EXPR,
    EXP_EXPR
};
EXPR_TYPE TokenType(string);
OPERATOR_TYPE WhichOperator(string);

//tree stuff
struct TreeNode
{
    string expr="";
    TreeNode* left=NULL;
    TreeNode* right=NULL;
};
//build a postfix expression using the algorithm from the notes
void BuildPostfixTree(TreeNode*&,string);
//evaluate a tree recursively
double EvalExpr(TreeNode*);
//evaluate a specific operator signified by str[0]
double EvalOp(double,double,string);
//print an expression in a tree
void PrintExpr(TreeNode*);
//clean up a tree
void DeleteTree(TreeNode*&);

//stack stuff
struct StackNode
{
    TreeNode* data=NULL;
    StackNode* next=NULL;
};
void Push(StackNode*&,TreeNode*&);
TreeNode* Pop(StackNode*&);

int main()
{
    string userin = "";
    TreeNode* root=NULL;
    cout << "Enter a postfix expression with operators and numbers separated by whitespace:"<<endl;
    getline(cin,userin);
    BuildPostfixTree(root,userin);
    PrintExpr(root);
    cout << "=" <<EvalExpr(root) << endl;
    DeleteTree(root);
}

void BuildPostfixTree(TreeNode*& node,string str)
{
    if (node!=NULL) throw runtime_error("RUNTIME-ERROR:void BuildPostfixTree(TreeNode*& node,string str): Tree is not empty");
    istringstream sstrm(str); //5th ed of c++ primer talks about string streams, they make this kind of work easier
    string curtoken=""; //the current token be processed
    StackNode* stack=NULL; //the working stack
    while (sstrm>>curtoken)
    {
        EXPR_TYPE curtype = TokenType(curtoken); //find the type of the current token
        if (curtype==OPERAND) //if it's an operand...
        {
            TreeNode* temp = new TreeNode{curtoken,NULL,NULL};
            Push(stack,temp); //build a node and push it
        }
        else if(curtype==OPERATOR) //if it's an operator
        {
            TreeNode* T1 = Pop(stack); //pop the left operand
            TreeNode* T2 = Pop(stack); //pop the right operand
            TreeNode* temp = new TreeNode{curtoken,T2,T1};
            Push(stack,temp); //build a tree from the left operand, right operand, and operator then push it
        }
    }
    node=Pop(stack); //Pop the resulting tree into node
}
//return whether the token str is an operator or operand
EXPR_TYPE TokenType(string str)
{
    if (str=="*"||str=="/"||str=="+"||str=="-"||str=="^") return OPERATOR;
    else return OPERAND;
}
//return which operator str is
OPERATOR_TYPE WhichOperator(string str)
{
    switch (str[0])
    {
    case '+':
        return ADD_EXPR;
    case '-':
        return SUB_EXPR;
    case '*':
        return MUL_EXPR;
    case '/':
        return DIV_EXPR;
    case '^':
		return EXP_EXPR;
    default:
        throw runtime_error("RUNTIME-ERROR:OPERATOR_TYPE WhichOperator(string str): Unknown operator type: \""+str+"\"");
    }
}
//from the notes but modified to use my functions and work in doubles
//recursively evaluates the tree "item"
double EvalExpr(TreeNode* item)
{
    //postorder: left right visit
    if (item==NULL) return 0;
    double left=EvalExpr(item->left); //get left operand recursively
    double right=EvalExpr(item->right); //get right operand recursively
    if (TokenType(item->expr)==OPERATOR) return EvalOp(left,right,item->expr); //evaluate the operation and return if it's an operator
    else return strtod(item->expr.c_str(),NULL); //else convert to a number and return that
}
//performs the operation "left op right"
//will throw on unknown operations and division by zero
double EvalOp(double left,double right,string op)
{
    //probably should check for div by zero using epsilons but this works alright too
    switch (WhichOperator(op))
    {
    case ADD_EXPR:
        return left+right;
    case MUL_EXPR:
        return left*right;
    case SUB_EXPR:
        return left-right;
    case EXP_EXPR:
		return pow(left,right);
    case DIV_EXPR:
        if (right==0) throw runtime_error("RUNTIME-ERROR:double EvalOp(double left,double right,string op): Attempted division by zero");
        return left/right;
    default:
        throw runtime_error("RUNTIME-ERROR:double EvalOp(double left,double right,string op): Unknown operation expected: \""+op+"\"");
    }

}
//print the tree held in node
void PrintExpr(TreeNode* node)
{
    //inorder: left visit right
    if (node!=NULL)
    {
        if (TokenType(node->expr)==OPERATOR) cout << "("; //proper parens
        PrintExpr(node->left);
        if (TokenType(node->expr)==OPERATOR) cout << " "; //less claustrophobic spacing
        cout << node->expr;
        if (TokenType(node->expr)==OPERATOR) cout << " ";
        PrintExpr(node->right);
        if (TokenType(node->expr)==OPERATOR) cout << ")";
    }
}
//delete the tree
void DeleteTree(TreeNode*& node)
{
    if (node==NULL) return;

    //delete the leaves first
    if (node->left!=NULL) DeleteTree(node->left);
    if (node->right!=NULL) DeleteTree(node->right);

    //delete the current node last
    delete node;
    node=NULL;
}
//push
void Push(StackNode*& top,TreeNode*& tnode)
{
    if (top==NULL)
    {
        top = new StackNode{tnode,NULL};
    }
    else
    {
        StackNode* newtop = new StackNode{tnode,top};
        top=newtop;
    }
}
//pop
TreeNode* Pop(StackNode*& top)
{
    if (top==NULL) throw runtime_error("RUNTIME-ERROR:TreeNode* Pop(StackNode*& top): Attempted to pop from empty stack");
    StackNode* temp = top;
    TreeNode* ret = top->data;
    top=top->next;
	delete temp;
    return ret;
}
