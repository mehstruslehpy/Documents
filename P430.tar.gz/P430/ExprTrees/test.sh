clear
./main <<-ENDOFMESSAGE
	$(./randpostfix.sh)
ENDOFMESSAGE
cat output.txt
echo "calc output"
calc -m 0 $(cat output.txt|egrep -i "\(|[0-9]$")
