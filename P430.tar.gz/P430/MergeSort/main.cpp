#include <iostream>
#include <fstream>
using namespace std;

//the struct I will be using
struct Node
{
    Node* next;
    int data;
};
//the assigned headers from your prompt
void split(Node* head,Node*& a,Node*& b);
Node* merge(Node* a, Node* b);
Node* mergeSort(Node* head);

//load the list of numbers into memory from a file
void ReadNums(istream& inf,Node*& head);
//load the list of numbers into memory from an array
void ReadNums(Node*& head,const int* nums, int length);
void PrintList(Node* head);
int CountList(Node* head);
//This is basically just an enqueue, having both versions means I can use one
//to do all my news up front then my sort won't need to allocate any memory temporarily
void AddToEnd(Node*& head,Node*& data);
void AddToEnd(Node*& head,int data);
//used for clean up at the end
void DeleteList(Node*& head);

int main()
{
    Node* nums = NULL;
    //fstream inf("input.txt");
    //ReadNums(inf,nums);
   	int arr[9]={1,3,8,9,17,0,5,123,57};
    ReadNums(nums,arr,9);
    cout << "Starting List:" << endl;
    PrintList(nums);
    cout << endl;
    nums=mergeSort(nums);
    cout << "Sorted List:" << endl;
    PrintList(nums);
    cout << endl;
    DeleteList(nums);
    //inf.close();
	return 0;
}
Node* merge(Node* a, Node* b)
{
	//helper list instead of a helper array
    Node* helperlist = NULL;
    Node* temp = NULL;
	//put the smaller of the first two elements from a or b into the helperlist
    while (a&&b)
    {
        if (a->data<=b->data)
        {
            temp = a;
            a=a->next;
            AddToEnd(helperlist,temp);
        }
        else
        {
            temp = b;
            b=b->next;
            AddToEnd(helperlist,temp);
        }
    }
	//put whatever is leftover into the helperlist
    while (a)
    {
        temp = a;
        a=a->next;
        AddToEnd(helperlist,temp);
    }
    while (b)
    {
        temp = b;
        b=b->next;
        AddToEnd(helperlist,temp);
    }
	//return the sorted helperlist
    return helperlist;
}
Node* mergeSort(Node* head)
{
    //if (head==NULL) throw runtime_error("ERROR:Node* mergeSort(Node* head):Cannot sort empty list");
    if (head==NULL) return NULL;
	//a one element list is already sorted
	if (head->next==NULL) return head;
    //the two sublists to sort recursively
	Node* splita=NULL;
    Node* splitb=NULL;
	//split them up
    split(head,splita,splitb);
	//sort the sublists recursively
    splita = mergeSort(splita);
    splitb = mergeSort(splitb);
	//merge the lists back together
    head=merge(splita,splitb);
	//return the merged and sorted list
    return head;
}
void split(Node* head,Node*& a,Node*& b)
{
	//count the list
    int length = CountList(head);
    Node* curr = NULL;
	//iterate about halfway down the list
    length/=2;
    for (curr=head; length>1; length--,curr=curr->next);
	//a is the first half
    a=head;
	//b is the rest
    b=curr->next;
	//snip the list into two separate halves
    curr->next=NULL;
}
int CountList(Node* head)
{
	//a simple counting function
    int total = 0;
    for (Node* curr=head; curr; curr=curr->next,total++);
    return total;
}
void DeleteList(Node*& head)
{
    if (head==NULL) throw runtime_error("ERROR:void DelList(Node*& head):Cannot delete an empty list");
	Node* temp = NULL;
	while (head->next)
	{
		temp = head->next;
		delete head;
		head=temp;
	}
	temp = head->next;
	delete head;
	head=temp;
}
void AddToEnd(Node*& head,int data)
{
	//implemented in terms of the other version for simplicity
	Node* temp = new Node{NULL,data};
	AddToEnd(head,temp);
}
void AddToEnd(Node*& head,Node*& newnode)
{
    if (newnode==NULL)
        throw runtime_error("ERROR:void AddToEnd(Node*& head,Node*& newnode):Cannot add null ptr to end.");
    if (head==NULL)
    {
        head = newnode;
        head->next=NULL;
    }
    else
    {
        Node* curr=head;
        while (curr->next)curr=curr->next;
        curr->next=newnode;
        curr->next->next=NULL;
    }
}
void PrintList(Node* head)
{
    if (head==NULL) return;
    Node* curr = head;
    while (curr->next)
    {
        cout << curr->data << " : ";
        curr=curr->next;
    }
    cout << curr->data;
}
void ReadNums(istream& inf, Node*& head)
{
    int temp;
    while (inf >> temp)
    {
        AddToEnd(head,temp);
    }
    if (head==NULL)
        throw runtime_error("ERROR:void ReadNums(istream& inf, Node*& head):Head is NULL after reading from file.");
}
void ReadNums(Node*& head,const int* nums, int length)
{
    if (nums==NULL) throw runtime_error("ERROR:void ReadNums(Node*& head,const int* nums, int length):nums can't be NULL.");
	for (unsigned i=0;i<length;i++) AddToEnd(head,nums[i]);
}
