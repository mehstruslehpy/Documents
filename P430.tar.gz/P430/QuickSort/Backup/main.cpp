#include <iostream>
#include <fstream>
#include <math.h>
using namespace std;

void printArray(int a[],int last);
int partition(int a[], int first, int last);
void quickSort(int a[], int start, int end);
int findLargest(int a[],int last);
void pad5Numbers(int a[],int last);
int readFile(int*& a);

int main()
{
    int* a = NULL;

    cout << "Reading Array:" << endl;
    int SIZE = readFile(a);
    cout << "lines:" << SIZE << endl;
    printArray(a,SIZE-1);
    cout << "Sorting Array (quicksort):" <<endl;
    quickSort(a,0,SIZE-1);
    printArray(a,SIZE-1);
    cout << "Padding Numbers:" << endl;
    pad5Numbers(a,SIZE-1);
    printArray(a,SIZE-1);

    delete [] a;
    return 0;
}

void printArray(int a[],int last)
{
    static int state = 0;
    cout << "state["<< state++ << "]: ";
    for (int i = 0; i <= last; i++) cout << a[i]<<" : ";
    cout << endl;
}
int partition(int a[], int first, int last)
{
    int pivot=last, lower=first, upper=last-1;
    while (lower<=upper)
    {
        while (a[lower]>=a[pivot] && lower<=upper)
            lower++;
        if (lower>upper)
            break;
        swap (a[lower],a[pivot]);
        pivot=lower;
        lower++;

        while (a[upper]<=a[pivot] && upper>=lower)
            upper--;
        if (upper<lower)
            break;
        swap (a[upper],a[pivot]);
        pivot=upper;
        upper--;

    }
    return pivot;

}

void quickSort(int a[], int start, int end)
{
    int pIndex;
    if (start>=end)
        return;
    pIndex=partition(a,start,end);
    quickSort(a, start, pIndex-1);
    quickSort(a, pIndex+1, end);
}
int findLargest(int a[],int last)
{
    int largest = a[0];
    for (int i = 0; i <= last; i++)
        if (a[i]>largest) largest = a[i];
    return largest;
}
void pad5Numbers(int a[],int last)
{
    int digits = log10(findLargest(a,last));
    for (int i = 0; i <= last; i++)
    {
        for(; log10(a[i])<digits&&a[i]!=0;)
        {
            a[i]*=10;
        }
        for (int j = 0; j<=digits; j++)
        {
            if (int((a[i]/pow(10,j)))%10==0)
            {
                a[i]+=(5*pow(10,j));
            }
            else
            {
                break;
            }
        }
    }
}

int readFile(int*& a)
{
    fstream inf("input.txt");
    int lines = 0;
    int temp;

    while (inf>>temp)lines++;
    inf.close();
    inf.open("input.txt");

    a = new int[lines];

    int i = 0;
    while (inf>>temp)
    {
        a[i]=temp;
        i++;
    }
    return lines;
}
