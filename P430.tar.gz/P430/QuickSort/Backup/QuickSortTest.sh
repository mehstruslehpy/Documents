#!/bin/bash

rm input.txt
touch input.txt

RANDCOUNT=$(( ( RANDOM % 20)  + 1 ))

for i in `seq 1 $RANDCOUNT`; do
	RANDNUM=$(( ( RANDOM % 199 )  + 1 ))
	echo $RANDNUM >> input.txt
done

echo
#valgrind ./main
./main
echo
#echo "Line Count:"
wc -l input.txt
#echo
echo "Input File:"
cat input.txt
