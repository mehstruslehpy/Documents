#include <iostream>
#include <fstream>
#include <math.h>
using namespace std;

//print an array from 0 to the index of the last element
void printArray(int a[],int last);
//the modified partition function
int partition(int a[], int first, int last);
//needed no changes
void quickSort(int a[], int start, int end);
//not really needed for a sorted array but I used it in pad5Numbers which
//I wanted to be fairly general
int findLargest(int a[],int last);
//pads the numbers with 5's til they match the amount of digits of the largest number
//in the array
void pad5Numbers(int a[],int last);
//read from a file into an array return the line count
int readFile(int*& a);

//radix sort stuff modified from the last assignment
const unsigned int BASE = 10;
struct Node
{
    Node* next = NULL;
    Node* prev = NULL;
    int data;
};
struct Queue
{
    Node* front = NULL;
    Node* rear = NULL;
};
enum SortOrder
{
    ASCENDING,
    DESCENDING
};
void RadixSort(Queue& inq,SortOrder ord);
void Enqueue(Queue& q,int data);
int Dequeue(Queue& q);
void PushToQ(Queue& q);
void ArrayToQueue(Queue& q,int*,int);
void DeleteQueue(Queue& q);
void PrintQueue(Queue q);

int main()
{
    int* a = NULL;
    Queue radixq;
    int SIZE = readFile(a); //read the file

    cout << "Input Lines:" << endl;
    cout << SIZE << endl;
    cout << "Before Sorting:" << endl;
    printArray(a,SIZE-1);
    cout << endl;
    cout << "Sorting via Quicksort:" <<endl;
    quickSort(a,0,SIZE-1);
    printArray(a,SIZE-1);
    cout << endl;
    cout << "Padding Numbers:" << endl;
    pad5Numbers(a,SIZE-1);
    printArray(a,SIZE-1);
    cout << endl;
    cout << "Sorting via Radix Sort:" << endl;
    //convert to queue
    ArrayToQueue(radixq,a,SIZE-1);
    RadixSort(radixq,DESCENDING);
    PrintQueue(radixq);
    cout << endl;
    //clean up
    DeleteQueue(radixq);
    delete [] a;
    return 0;
}

void printArray(int a[],int last)
{
    cout << "array: ";
    //iterate across the array and print each element
    for (int i = 0; i <= last; i++) cout << a[i]<<" ";
    cout << endl;
}
//I swapped the pivot to the end upper to first instead of first+1
//lower to last-1, then I swapped some of the body around so the
//pivot gets compared to lower first and upper second, lastly I
//swapped the comparisons for both lower and upper from <= to >=
//and from >= to <=
int partition(int a[], int first, int last)
{
    int pivot=last, lower=first, upper=last-1;
    while (lower<=upper)
    {
        while (a[lower]>=a[pivot] && lower<=upper)
            lower++;
        if (lower>upper)
            break;
        swap (a[lower],a[pivot]);
        pivot=lower;
        lower++;

        while (a[upper]<=a[pivot] && upper>=lower)
            upper--;
        if (upper<lower)
            break;
        swap (a[upper],a[pivot]);
        pivot=upper;
        upper--;

    }
    return pivot;

}
//no changes
void quickSort(int a[], int start, int end)
{
    int pIndex;
    if (start>=end)
        return;
    pIndex=partition(a,start,end);
    quickSort(a, start, pIndex-1);
    quickSort(a, pIndex+1, end);
}
int findLargest(int a[],int last)
{
    int largest = a[0];
    for (int i = 0; i <= last; i++)
        if (a[i]>largest) largest = a[i];
    return largest;
}
void pad5Numbers(int a[],int last)
{
    //trunc(log10(val)) will be the amount of digits
	bool iszero = false;
    int digits = log10(findLargest(a,last));
    for (int i = 0; i <= last; i++,iszero=false)
    {
        //if we need to preserve the left most digit when a[i] is zero
		//the only way to do that leaves a[i] with a leading "invisible"
		//zero digit for example if the largest number were 1999 and 
		//a[i]==0 then after padding a[i]==0555 or just 555 if you were
		//hoping for a[i] to be 5555 then all you would need to do is
		//comment out the two if statements involving iszero
		if(a[i]==0)
		{
			iszero=true;
			a[i]++;
		}
		for(int j=0; log10(a[i])<digits; j++)
        {
            a[i]*=10;
            a[i]+=5;
        }
		if(iszero)a[i]-=pow(10,digits);

	}
}

int readFile(int*& a)
{
    fstream inf("input.txt");
    int lines = 0;
    int temp;

	//get the line count
    while (inf>>temp)lines++;
    inf.close();
    inf.open("input.txt");
	
	//allocate space for the array
    a = new int[lines];

	//fill the array
    int i = 0;
    while (inf>>temp)
    {
        a[i]=temp;
        i++;
    }

	//return the line count
    return lines;
}
//below here is just some slight modifications to my previous radix sort program
void Enqueue(Queue& q,int data)
{
    if (q.front==NULL||q.rear==NULL)
    {
        q.front=q.rear=new Node;
        q.front->data=data;
        q.front->next=q.front->prev=NULL;
    }
    else
    {
        q.rear->next=new Node;
        q.rear->next->data=data;
        q.rear->next->next=NULL;
        q.rear->next->prev=q.rear;
        q.rear=q.rear->next;
    }
}
int Dequeue(Queue& q)
{
    int retval;
    if (q.front->next==NULL)
    {
        retval=q.front->data;
        delete q.front;
        q.front=q.rear=NULL;
        return retval;
    }
    else
    {
        Node* oldfront = q.front;
        retval=oldfront->data;
        q.front=q.front->next;
        delete oldfront;
        return retval;
    }
}
void PushToQ(Queue& q,int data)
{
    if (q.front==NULL||q.rear==NULL)
    {
        q.front=q.rear=new Node;
        q.front->data=data;
        q.front->next=q.front->prev=NULL;
    }
    else
    {
        Node* newFront=new Node;
        newFront->data=data;
        newFront->next=q.front;
        newFront->prev=NULL;
        q.front->prev=newFront;
        q.front=newFront;
    }
}
void PrintQueue(Queue q)
{
    cout << "queue: ";
    if (q.front==NULL) return;
    Node* curr = q.front;
    while (curr->next!=NULL)
    {
        cout << curr->data << " ";
        curr=curr->next;
    }
    cout << curr->data << endl;
}
void DeleteQueue(Queue& q)
{
    while (q.rear!=NULL)
    {
        Dequeue(q);
    }
}
int FindMax(Queue& q)
{
    Node* curr = q.front;
    int max = q.front->data;
    for (; curr; curr=curr->next)(max<curr->data)?(max=curr->data):(max=max);
    return max;
}
void RadixSort(Queue& q,SortOrder ord)
{
    Queue qs[BASE];
    int LSD;
    int temp;
    int N=1;
    int M=BASE;
    int MAX = FindMax(q);
    while (N<=MAX)
    {
        while (q.front)
        {
            temp = Dequeue(q);
            LSD = (temp%M)/N;
            if (ord==ASCENDING) Enqueue(qs[LSD],temp);
            else PushToQ(qs[LSD],temp);
        }
        for (unsigned i=0; i<BASE; i++)
            while(qs[i].front)
                if (ord==ASCENDING) Enqueue(q,Dequeue(qs[i]));
                else PushToQ(q,Dequeue(qs[i]));
        M*=BASE;
        N*=BASE;
    }
}
void ArrayToQueue(Queue& q,int* arr,int asize)
{
    for (int i = 0; i <= asize; i++) Enqueue(q,arr[i]);
}
