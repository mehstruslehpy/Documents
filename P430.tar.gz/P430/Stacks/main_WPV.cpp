#include <iostream>

//Nodes to build the stack with
struct Node
{
    char data;
    Node* next;
};

//Pre: top may be empty/NULL data may be any unsigned integer
//Post: top contains one more element with a value of data
//Desc: a new node is allocated with the value of data and appended
//(pushed) to top.
void Push(Node*& top, char data);

//Pre: top may be empty/NULL
//Post: top contains one less element if it was not empty if top was empty
//the program throws an error
//Desc: the first element of top is removed from the stack and deallocated
//its value is returned, if top is empty an error occurs
char Pop(Node*& top);

//Pre: top must be a null pointer
//Post: top contains the binary or hexadecimal representation of the data
//in a stack
//Desc: top is built using data via the assigned algorithm
void BuildStackBinary(Node*& top, unsigned int data);
void BuildStackHex(Node*& top, unsigned int data);

//Pre: top may be empty/NULL
//Post: each element of top is popped and printed until top is empty
void PrintPop(Node*& top);

//print errmsg and throw
void Error(const char* errmsg);

using namespace std;

int main()
{
    Node* top = NULL;
    unsigned int usernumber;
    
	//take in user input
	cout << "Enter an integer" << endl;
    cin >> usernumber;
    cout << "You chose:" << endl;
	cout << usernumber << endl;

	//handle the binary conversion and output
	BuildStackBinary(top,usernumber);
    cout << "Your number in binary is:" << endl;
    cout << "0b"; //prefix for binary numbers
	PrintPop(top);

	//handle the hex conversion and output
    cout << "Your number in hex is:" << endl;
    BuildStackHex(top,usernumber);
    cout << "0x"; //prefix for hex numbers
    PrintPop(top);
}

void Error(const char* errmsg)
{
    cout << errmsg << endl;
    throw;
}

void Push(Node*& top, char data)
{
    if (!top) //if the stack is empty add the first element
    {
        top = new Node;
        top->next=NULL;
        top->data=data;
    }
    else //if not add a new element to the top
    {
        Node* temp = new Node;
        temp->data=data;
        temp->next=top;
        top=temp;
    }
}

char Pop(Node*& top)
{
	//don't allow pops from empty stacks
    if (!top) Error("ERROR:unsigned int Pop(Node*& top): Cannot pop from empty stack.");
    
	//delete the old top and return its value
	Node* tempnode = top;
    char tempnum = top->data;
    top=top->next;
    delete tempnode;
    return tempnum;
}

void BuildStackBinary(Node*& top, unsigned int data)
{
	//don't allow building on stacks that already contain stuff
    if (top) Error("ERROR:void BuildStack(Node*& top, unsigned int data): Top already points to something.");

	//push the first binary digit as a char
    Push(top,data%2+'0');

	//push the rest
    while(data/2)
    {
        data = data/2;
        Push(top,data%2+'0');
    }
}

void BuildStackHex(Node*& top, unsigned int data)
{
	//don't allow building on stacks that already contain stuff
    if (top) Error("ERROR:void BuildStack(Node*& top, unsigned int data): Top already points to something.");

	//push the first hex digit as a char
    //the ternary statement just toggles between the digits [0-9] and letters
	//[A-F] in the ASCII table based on the value of data%16+'0'
	Push(top,(data%16+'0'>'9')?(data%16+'7'):(data%16+'0'));
    
	//push the rest
	while(data/16)
    {
        data = data/16;
        Push(top,(data%16+'0'>'9')?(data%16+'7'):(data%16+'0'));
    }
}

void PrintPop(Node*& top)
{
	//if the stack is empty "print" nothing
    if (!top) return;
	//if not really print stuff
    while(top) cout << Pop(top);
    cout << endl;
}
