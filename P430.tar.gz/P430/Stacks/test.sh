#!/bin/bash
RANDNUM=$(( ( RANDOM % 99999 )  + 1 ))
valgrind ./main <<-ENDOFMESSAGE
	$RANDNUM
ENDOFMESSAGE
echo ""
calc -d -p "base(2);$RANDNUM"
calc -d -p "base(16);$RANDNUM"
