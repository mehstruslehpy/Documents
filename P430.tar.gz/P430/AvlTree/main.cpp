#include <iostream>
#include <fstream>
using namespace std;

struct TreeNode
{
    int key;
    int height=0;
    TreeNode* left = NULL;
    TreeNode* right = NULL;
};
//build a tree from a file
void BuildTree(TreeNode*&);
//this is a modification of the levelorder print to print to stdout and "output.txt" as well as print the height and balance
void LevelOrderPrint(TreeNode*,ofstream&);
//the normal tree delete function
void DeleteTree(TreeNode*&);
//the new insert function, rebalances if necessary this came from the assignment description
TreeNode* Insert(TreeNode*,int);
//the rebalance function using the algorithm described in the assignment description
TreeNode* Rebalance(TreeNode*);
//returns the max of two values
int Max(int,int);
//get the height of a tree
int GetHeight(TreeNode*);
//get the balance of a tree
int GetBalance(TreeNode*);
//left rotate
TreeNode* LeftRotate(TreeNode*);
//right rotate
TreeNode* RightRotate(TreeNode*);

/***This is the same exact queue stuff as a couple projects ago for the level ordered print***/
//structs for dealing with queues of treenodes nicely
struct QueueNode
{
    TreeNode* treeptr=NULL;
    QueueNode* next=NULL;
};
struct Queue
{
    QueueNode* front=NULL;
    QueueNode* rear=NULL;
};
void Enqueue(Queue&,TreeNode*&);
TreeNode* Dequeue(Queue&);
void EnqueueHandler(QueueNode*& front,QueueNode*& rear,TreeNode*& data);
TreeNode* DequeueHandler(QueueNode*& front);

/***This is the same dot lang stuff I've been using for a while now but modified to print balance and height***/
void DotHandler(TreeNode*& node);
void DotLangPrint(TreeNode*& root);

int main()
{
    TreeNode* root = NULL;
    ofstream outf("output.txt"); //the output file stream
    BuildTree(root); //build the tree
    cout << "Dot language print:" << endl<<endl;
    DotLangPrint(root); //print in dotlang format (useful for debugging and visualising)
    cout << endl << "Level ordered print (also redirected to \"output.txt\"):" << endl;
    LevelOrderPrint(root,outf); //level order print
    DeleteTree(root); //clean up
}
//pretty much the exact same build as last time but throws if the file was empty
void BuildTree(TreeNode*& root)
{
    fstream inf("input.txt");
    int temp = 0;
    if (inf>>temp) root = Insert(root,temp);
    else throw runtime_error("RUNTIME-ERROR:file was empty");
    while (inf >> temp) root=Insert(root,temp);
}
//slightly modified format and output of my last level order print
void LevelOrderPrint(TreeNode* node,ofstream& outf)
{
    unsigned nicl=0; //nodes in current level
    unsigned ninl=0; //nodes in next level
    unsigned curlevel=0;
    Queue pq; //printqueue
    Enqueue(pq,node);//enqueue the root
    nicl++;
    outf <<"Level "<<curlevel;
    cout <<"Level "<<curlevel;
    while (nicl>0)
    {
        TreeNode* temp = Dequeue(pq); //dequeue whatever needs printed
        nicl--;
        outf << " : "<<temp->key << " ("<<temp->height<<","<<GetBalance(temp)<<")";;
        cout << " : "<<temp->key << " ("<<temp->height<<","<<GetBalance(temp)<<")";;
        if (temp->left) //enqueue the left stuff
        {
            Enqueue(pq,temp->left);
            ninl++;
        }
        if (temp->right) //enqueue the right stuff
        {
            Enqueue(pq,temp->right);
            ninl++;
        }
        if(nicl==0) //if nicl==0 we are ready to move on the the next level
        {
            curlevel++;
            nicl=ninl;
            ninl=0;
            outf << endl<<"Level "<<curlevel;
            cout << endl<<"Level "<<curlevel;
        }
    }
    outf << " : ***EMPTY***" <<endl;
    cout << " : ***EMPTY***" <<endl;
    //queue is empty so nothing left to clean up
}

//from the notes
//non-tail recursive algorithm because of rebalance
TreeNode* Insert(TreeNode* node, int key)
{
    //recursive Code for inserting a node
    //When insert happens set height to 0 for the node
    if (node == NULL) return (new TreeNode{key,0,NULL,NULL}); //using braced init lists there is no need for a function
    if (key < node->key) node->left = Insert(node->left, key); //if left insert on left
    else node->right = Insert(node->right, key); //if not insert right
    node=Rebalance(node); //update heights and rebalance
    return node;
}
//from the assignment description
TreeNode* Rebalance(TreeNode* node)
{
    node->height = Max(GetHeight(node->left), GetHeight(node->right)) + 1;
    int balance = GetBalance(node); //node->left - node->right

    //implementation of the psuedocode given in assignment description
    if (balance>1&&GetBalance(node->left)>=0) return RightRotate(node); //left heavy left heavy (outside)
    if (balance<-1&&GetBalance(node->right)<=0) return LeftRotate(node); //right heavy right heavy (outside)
    if (balance>1&&GetBalance(node->left)<0) //left heavy right heavy (inside)
    {
        node->left =  LeftRotate(node->left); //left rotate lower left
        return RightRotate(node); //right rotate lower
    }
    if (balance<-1&&GetBalance(node->right)>0) //left heavy right heavy (inside)
    {
        node->right = RightRotate(node->right); //right rotate lower right
        return LeftRotate(node); //left rotate upper
    }
    //if no rotation
    return node;
}
//maps the labeled nodes from the notes (x,y,z)->(y,x,z) and recomputes the approporiate heights
TreeNode* LeftRotate(TreeNode* x)
{
    TreeNode* y=x->right;
    x->right=y->left;
    y->left=x;
    y->height=GetHeight(y);
    x->height=GetHeight(x);
    return y;
}
//maps the labeled nodes from the notes (x,y,z)->(y,x,z) and recomputes the approporiate heights
TreeNode* RightRotate(TreeNode* x)
{
    TreeNode* y=x->left;
    x->left=y->right;
    y->right=x;
    y->height=GetHeight(y);
    x->height=GetHeight(x);
    return y;
}
//computes the balance htleft-htright
int GetBalance(TreeNode* node)
{
    int htleft = (node->left==NULL)?(-1):(node->left->height);
    int htright = (node->right==NULL)?(-1):(node->right->height);
    return htleft-htright;
}
//the same height function from the last assignment
int GetHeight(TreeNode* node)
{
    if (node==NULL)
    {
        return(-1);
    }
    else
    {
        // compute the depth of each subtree
        int LHeight = GetHeight(node->left);
        int RHeight = GetHeight (node->right); // use the larger one
        if (LHeight > RHeight) return(LHeight + 1);
        else return(RHeight + 1);
    }
}
//return the max of a or b
int Max(int a,int b)
{
    return (a>b)?a:b;
}

//recurse down the tree and delete everything
void DeleteTree(TreeNode*& node)
{
    if (node==NULL) return;

    //delete the leaves first
    if (node->left!=NULL) DeleteTree(node->left);
    if (node->right!=NULL) DeleteTree(node->right);

    //delete the current node last
    delete node;
    node=NULL;
}
//-----------------------------------------------------------------------------
//This is the same queueu stuff as before
//-----------------------------------------------------------------------------
void Enqueue(Queue& q,TreeNode*& node)
{
    EnqueueHandler(q.front,q.rear,node);
}
TreeNode* Dequeue(Queue& q)
{
    return DequeueHandler(q.front);
}
void EnqueueHandler(QueueNode*& front,QueueNode*& rear,TreeNode*& data)
{
    //if front is null the queue is empty
    if (!front)
    {
        front = new QueueNode;
        front->next=NULL;
        front->treeptr=data;
        rear=front;
    }
    else //if not the queue has items so we have to add new stuff to the rear
    {
        rear->next = new QueueNode;
        rear->next->treeptr = data;
        rear->next->next = NULL;
        rear=rear->next;
    }
}

TreeNode* DequeueHandler(QueueNode*& front)
{
    //handle front is null case
    if (!front) throw runtime_error("ERROR:void Dequeue(QueueNode*& front): Nothing to dequeue.");

    //if not remove from the front
    QueueNode* tempnode = front;
    TreeNode* retval = front->treeptr;
    front = front->next;
    delete tempnode;
    return retval;
}
//-----------------------------------------------------------------------------
//This is a barely modified version of the dot lang stuff I've been using
//-----------------------------------------------------------------------------

void DotHandler(TreeNode*& node)
{
    static long invisnode = 0;
    //print the connecting nodes
    if (node->left==NULL)
    {
        cout << "\t"<<long(&node)<< " -> "<<++invisnode<<"//left branch is null"<<endl;
        cout << "\t" << invisnode << "[label=\"\\\\\"]"<<endl;
    }
    else
    {
        cout << "\t"<<long(&node) << " -> " << long(&(node->left)) << endl;
    }

    if (node->right==NULL)
    {
        cout << "\t"<<long(&node)<< " -> "<<++invisnode<<"//right branch is null"<<endl;
        cout << "\t" << invisnode << "[label=\"\\\\\"]"<<endl;
    }
    else
    {
        cout << "\t" <<long(&node) << " -> " << long(&(node->right)) << endl;
    }

    //recurse
    if(node->left!=NULL)DotHandler(node->left);
    if(node->right!=NULL)DotHandler(node->right);

    //print the label for the current node
    cout << "\t" <<long(&node)<<"[label=\""<<node->key<<" ("<<node->height<<","<<GetBalance(node)<<")\"];"<<endl;
}

//the dotlang printing functions I've been using for the past couple projects
void DotLangPrint(TreeNode*& root)
{
    //if (root==NULL) throw runtime_error("void DotLangPrint(TreeNode* root): root must not be NULL.");
    if (root==NULL) return;
    cout << "digraph BST\n{"<<endl;
    cout << "\tnodesep=0.01"<<endl;
    DotHandler(root);
    cout << "}"<<endl;

    cout << endl << endl << "You can copy and paste the code: \"digraph names { ... }\" ";
    cout << "at one of the following sites to see a diagram of the tree"<< endl;
    cout << "http://webgraphviz.com/" << endl;
    cout << "https://dreampuf.github.io/GraphvizOnline/" << endl;
    cout << "http://viz-js.com/" << endl;
    cout << "or use some other graphviz/DOT language viewer" << endl;
    cout << "more info about graphviz can be found here:" << endl;
    cout << "https://www.graphviz.org/about/" << endl;

}
