#include <iostream>
#include <fstream>

#define MAX 20

/*-----assigned-functions-----*/
struct Node
{
    char name[MAX];
    Node* next;
};
//ReadFile:
//Create a linked list from an input file (input.txt) that contains an even
//number of first names. The number of items in the file is unknown.
void ReadFile(Node*&);
//SplitMerge:
//Create a split function that divides the newly created linked list into two
//equal sublists
void SplitMerge(Node*,Node*&,Node*&);
//Traverse:
//Accepts a pointer and displays each of the lists
void Traverse(Node*);
//Merge:
//Feed the pointer variables myList1 and myList2 into the Merge function. Create a single list. Return the list.
Node* Merge(Node*,Node*);

/*-----helper-functions-----*/
//CopyString:
//A helper function copies one string to another
void CopyString(char*,char*);
//DeleteList:
//A helper function which takes a list and deletes every element if possible
void DeleteList(Node*&);
//CountList:
//A helper function which takes a list and returns its count of nodes starting from 0
int CountList(Node*&);
//CopyToEnd:
//copy element to the end of list
void CopyToEnd(Node*& list,Node* element);

using namespace std;
int main()
{
    //alloc and init the lists
    Node* list = NULL;
    Node* sublist1 = NULL;
    Node* sublist2 = NULL;
    Node* mergedlist = NULL;

    //build all four lists
    ReadFile(list);
    SplitMerge(list,sublist1,sublist2);
    mergedlist = Merge(sublist2,sublist1);

    //print all necessary info
    cout << "list:" << endl;
    Traverse(list);
    cout << endl;
    cout << "sublist1:"<<endl;;
    Traverse(sublist1);
    cout << endl;
    cout << "sublist2:" <<endl;
    Traverse(sublist2);
    cout << endl;
    cout << "mergedlist:" <<endl;
    Traverse(mergedlist);
    cout << endl;

    //delete all four lists
    DeleteList(list);
    DeleteList(sublist1);
    DeleteList(sublist2);
    DeleteList(mergedlist);
}

/*-----assigned-functions-----*/
Node* Merge(Node* sublist1, Node* sublist2)
{
    //exit if either sublist is NULL
    if(!sublist1||!sublist2) return NULL;

    //return this list at the end
    Node* retlist = NULL;

    //copy both lists to retlist
    while(sublist1->next)
    {
        CopyToEnd(retlist,sublist1);
        sublist1=sublist1->next;
    }
    CopyToEnd(retlist,sublist1);
    while(sublist2->next)
    {
        CopyToEnd(retlist,sublist2);
        sublist2=sublist2->next;
    }
    CopyToEnd(retlist,sublist2);

    //return the merged list
    return retlist;
}
void SplitMerge(Node* list, Node*& sublist1, Node*& sublist2)
{
    //list needs to be non null but sublist1 and 2 must be null
    if (!list) return;
    if (sublist1) return;
    if (sublist2) return;

    //count the list
    int length = CountList(list);
    int count = 0;
    Node* cur = list;

    //copy half of cur to sublist1 and half to sublist2
    while(cur->next)
    {
        if ((length+2)/2 > count) CopyToEnd(sublist1,cur);
        else CopyToEnd(sublist2,cur);
        count++;
        cur=cur->next;
    }
    //there is one element left to copy
    CopyToEnd(sublist2,cur);
}
void Traverse(Node* const list)
{
    //if we receive a null pointer exit
    if (!list) return;
    Node* temp = list;
    //if not iterate to the end and print each name
    while (temp->next)
    {
        cout << temp->name << endl;
        temp = temp->next;
    }
    //print the final name
    cout << temp->name << endl;
}
void ReadFile(Node *& list)
{
    //if we receive a non null pointer exit
    if (list) return;

    //open the file
    ifstream file("input.txt");
    char str[MAX];
    Node* temp = NULL;

    //prime the loop by setting up the very first node
    if (file >> str)
    {
        list = new Node;
        list->next=NULL;
        CopyString(list->name,str);
    }
    //while there are names left to read, read a name
    //tag it to the end
    while (file>>str)
    {
        temp = new Node;
        temp->next=NULL;
        CopyString(temp->name,str);
        temp->next = list;
        list = temp;
    }
    file.close();
}

/*-----helper-functions-----*/
//this is from the last assignment
void CopyString(char *A, char *B)
{
    unsigned int i;
    //copy over every character from B into A, this will not copy the null char
    for (i = 0; B[i]!='\0'; i++)
    {
        A[i] = B[i];
    }
    //make sure to end A with the null character
    A[i] = '\0';
}
int CountList(Node*& list)
{
    //if we receive a null pointer return -1 and exit
    if (!list) return -1;

    int count = 0;
    for (Node* cur = list; cur->next; cur=cur->next, count++);
    return count;
}
void CopyToEnd(Node*& head,Node* element)
{
    Node* list = head;
    //if list is null iterate to end and add the element if not then
    //start the list with the element
    if(head)
    {
        //iterate to the end
        while (list->next)
        {
            list = list->next;
        }
        //add element on to the end
        list->next = new Node;
        CopyString(list->next->name,element->name);
        list->next->next = NULL;
    }
    else
    {
        list = new Node;
        CopyString(list->name,element->name);
        list->next = NULL;
        head = list;
    }
}
void DeleteList(Node*& list)
{
    Node* temp = NULL;
    while (list->next)
    {
        temp = list->next;
        delete list;
        list = temp;
    }
    temp = list->next;
    delete list;
    list = temp;

}
