#include <iostream>
#include <fstream>

#define MAX 20

/*-----assigned-functions-----*/
struct Node
{
    char name[MAX];
    Node* next;
};
//ReadFile:
//Create a linked list from an input file (input.txt) that contains an even
//number of first names. The number of items in the file is unknown.
void ReadFile(Node*&);
//SplitMerge:
//Create a split function that divides the newly created linked list into two
//equal sublists
void SplitMerge(Node*,Node*&,Node*&);
//Traverse:
//Accepts a pointer and displays each of the lists
void Traverse(Node*);
//Merge:
//Feed the pointer variables myList1 and myList2 into the Merge function. Create a single list. Return the list.
Node* Merge(Node*,Node*);

/*-----helper-functions-----*/
//CopyString:
//A helper function copies one string to another
void CopyString(char*,char*);
//DeleteList:
//A helper function which takes a list and deletes every element if possible
void DeleteList(Node*&);
//CountList:
//A helper function which takes a list and returns its count of nodes starting from 0
int CountList(Node*&);

using namespace std;
int main()
{
    //alloc and init the lists
    Node* list = NULL;
    Node* sublist1 = NULL;
    Node* sublist2 = NULL;

    //build the first list 
    ReadFile(list);
    
	//print all necessary info
    cout << "list:" << endl;
    Traverse(list);
    cout << endl;
	
	//split the list into two sublists	
    SplitMerge(list,sublist1,sublist2);

	//print all necessary info
	cout << "sublist1:"<<endl;;
    Traverse(sublist1);
    cout << endl;
    cout << "sublist2:" <<endl;
    Traverse(sublist2);
    cout << endl;
   
   	//merge the two lists back together
    list = Merge(sublist1,sublist2);
	
	//print all necessary info
	cout << "list:" <<endl;
    Traverse(list);
    cout << endl;

    //delete the list 
    DeleteList(list);
}

/*-----assigned-functions-----*/
Node* Merge(Node* sublist1, Node* sublist2)
{
    //exit if either sublist is NULL
    if(!sublist1||!sublist2) return NULL;

    //return this list at the end, sublist2 will be appended to 1
    Node* retlist = sublist1;
    
	//iterate down sublist1 to until next is null
	Node* curr = NULL;
	for (curr=sublist1;curr->next;curr=curr->next);

	//tag sublist2 to the end of sublist1
	curr->next=sublist2;
    
	//return retlist
	return retlist;
}
void SplitMerge(Node* list, Node*& sublist1, Node*& sublist2)
{
    //list needs to be non null but sublist1 and 2 must be null
    if (!list) return;
    if (sublist1) return;
    if (sublist2) return;

    //count the list
    int length = CountList(list);

	//iterate halfway down the list
    Node* curr = list;
	for (int i = 0; i < length/2; i++,curr=curr->next);
	
	//sublist1 is set to point to the start
	sublist1=list;
	
	//sublist2 is set to point to the node after the middle edge 
	sublist2=curr->next;

	//curr next being set to null removes the middle edge which
	//connected sublist1 to sublist2
	curr->next=NULL;
}
void Traverse(Node* const list)
{
    //if we receive a null pointer exit
    if (!list) return;
    Node* temp = list;
    //if not iterate to the end and print each name
    while (temp->next)
    {
        cout << temp->name << endl;
        temp = temp->next;
    }
    //print the final name
    cout << temp->name << endl;
}
void ReadFile(Node *& list)
{
    //if we receive a non null pointer exit
    if (list) return;

    //open the file
    ifstream file("input.txt");
    char str[MAX];
    Node* temp = NULL;

    //prime the loop by setting up the very first node
    if (file >> str)
    {
        list = new Node;
        list->next=NULL;
        CopyString(list->name,str);
    }
    //while there are names left to read, read a name
    //tag it to the end
    while (file>>str)
    {
        temp = new Node;
        temp->next=NULL;
        CopyString(temp->name,str);
        temp->next = list;
        list = temp;
    }
    file.close();
}

/*-----helper-functions-----*/
//this is from the last assignment
void CopyString(char *A, char *B)
{
    unsigned int i;
    //copy over every character from B into A, this will not copy the null char
    for (i = 0; B[i]!='\0'; i++)
    {
        A[i] = B[i];
    }
    //make sure to end A with the null character
    A[i] = '\0';
}
int CountList(Node*& list)
{
    //if we receive a null pointer return -1 and exit
    if (!list) return -1;

    //iterate down the list and store the total count of elements
	int count = 0;
    for (Node* cur = list; cur->next; cur=cur->next, count++);

	//return the count
    return count;
}

void DeleteList(Node*& list)
{
	//if the list is empty there is nothing to delete
    if (!list) return;

	//iterate through the list advance temp before deleting the current head, 
	//then move list forward to catch it back up to temp for the next iteration
    Node* temp = NULL;
    while (list->next)
    {
        temp = list->next;
        delete list;
        list = temp;
    }
	//delete the last element
    temp = list->next;
    delete list;
    list = temp;

}
