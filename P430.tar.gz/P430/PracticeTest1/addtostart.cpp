#include <iostream>
#include <fstream>
#include <string.h>
#include <string>
using namespace std;

int const MAX_SIZE = 15;

struct singlylist
{
    singlylist* next;
    char name[MAX_SIZE];
};

struct doublylist
{
    doublylist* next;
    doublylist* prev;
    char name[MAX_SIZE];
};

struct circularlist
{
    circularlist* next;
    circularlist* prev;
    char name[MAX_SIZE];
};

void ErrorMsg(const char*);

template<typename T>
void ReadFile(T*& head);

template<typename T>
void TraverseFwd(T* head);
template<>
void TraverseFwd<circularlist>(circularlist* head);

template<typename T>
void TraverseBwd(T* tail);
template<>
void TraverseBwd(singlylist* tail);

template<typename T>
void AddToStart(T*&, const char* data);

template<typename T>
void RemoveFromStart(T*&);

template<typename T>
void DeleteList(T*&,T*);

int main()
{
    singlylist* shead=NULL;
    doublylist* dhead=NULL;
    circularlist* chead=NULL;
    doublylist* temp=NULL;

    ReadFile<singlylist>(shead);
    ReadFile<doublylist>(dhead);
    ReadFile<circularlist>(chead);

    cout << "Singly List Traverse:" << endl;
    TraverseFwd<singlylist>(shead);
    cout << "Doubly List Traverse:" << endl;
    TraverseFwd<doublylist>(dhead);
    cout << "Circular List Traverse:" << endl;
    TraverseFwd<circularlist>(chead);
    cout << "Circular List Traverse Backwards:" << endl;
    TraverseBwd<circularlist>(chead->prev);
    temp=dhead;
    while (temp->next) temp=temp->next;
    cout << "Doubly List Traverse Backwards:" << endl;
    TraverseBwd<doublylist>(temp);

    DeleteList<singlylist>(shead,NULL);
    DeleteList<doublylist>(dhead,temp);
    DeleteList<circularlist>(chead,chead->prev);

    return 0;
}
void ErrorMsg(const char* msg)
{
    cout << msg << endl;
    throw;
}

template<typename T>
void ReadFile(T*& head)
{
    if (head != NULL) ErrorMsg("ERROR:void ReadFile(circularlist*& head): List not empty.");
    ifstream inf("input.txt");
    string temp;
    const char* ptr = NULL;
    while (inf >> temp)
    {
        ptr = temp.c_str();
        AddToStart<T>(head,ptr);
    }
}
template <>
void AddToStart<singlylist>(singlylist*& head, const char* data)
{
    if (data==NULL)ErrorMsg("ERROR:void AddToStart<singlylist>(singlylist*& head, const char*): Data is null.");
    if (head==NULL)
    {
        head = new singlylist;
        head->next=NULL;
        strncpy(head->name,data,MAX_SIZE);
    }
    else
    {
        singlylist* curr = new singlylist;
        curr->next = head;
        strncpy(curr->name,data,MAX_SIZE);
        head=curr;
    }
}
template <>
void AddToStart<doublylist>(doublylist*& head, const char* data)
{
    if (data==NULL)ErrorMsg("ERROR:void AddToStart<doublylist>(doublylist*& head, const char*): Data is null.");
    if (head==NULL)
    {
        head = new doublylist;
        head->next=head->prev=NULL;
        strncpy(head->name,data,MAX_SIZE);
    }
    else
    {
        doublylist* curr = new doublylist;
        curr->next=head;
        curr->prev=NULL;
        head->prev=curr;
        head=curr;
        strncpy(curr->name,data,MAX_SIZE);
    }
}
template <>
void AddToStart<circularlist>(circularlist*& head, const char* data)
{
    if (data==NULL) ErrorMsg("ERROR:void AddToStart<circularlist>(circularlist*& head, const char*): Data is null.");
    if (head==NULL)
    {
        head = new circularlist;
        head->next=head;
        head->prev=head;
        strncpy(head->name,data,MAX_SIZE);
    }
    else
    {
        circularlist* curr = new circularlist;
        curr->next = head;
        curr->prev = head->prev;
        head->prev->next=curr;
        head->prev=curr;
        strncpy(curr->name,data,MAX_SIZE);
        head=curr;
    }
}

template <>
void RemoveFromStart<singlylist>(singlylist*& head)
{
    if (head==NULL)
    {
        return;
    }
    else
    {
        if (head->next==NULL)
        {
            delete head;
            head=NULL;
        }
        else
        {
            singlylist* curr = head;
            head=head->next;
            delete curr;
        }
    }
}
template <>
void RemoveFromStart<doublylist>(doublylist*& head)
{
    if (head==NULL)
    {
        return;
    }
    else
    {
        if (head->next==NULL)
        {
            delete head;
            head = NULL;
        }
        else
        {
            doublylist* curr = head;
            head = head->next;
            head->prev=NULL;
            delete curr;
        }
    }
}
template <>
void RemoveFromStart<circularlist>(circularlist*& head)
{
    if (head==NULL)
    {
        return;
    }
    else
    {
        if (head==head->prev)
        {
            delete head;
            head=NULL;
        }
        else
        {
            circularlist* curr = head;
            head=head->next;
            head->prev=curr->prev;
            head->prev->next=head;
            delete curr;
        }
    }
}
template <typename T>
void DeleteList(T*& head,T* tail)
{
    while (head!=NULL)
    {
        RemoveFromStart<T>(head);
    }
}

template <>
void TraverseFwd<circularlist>(circularlist* head)
{
    circularlist* curr = head;
    while (curr!=head->prev)
    {
        cout << curr->name << " , ";
        curr=curr->next;
    }
    cout << curr->name << endl;
}
template<typename T>
void TraverseFwd(T* head)
{
    while (head->next)
    {
        cout << head->name << " , ";
        head=head->next;
    }
    cout << head->name << endl;
}
template <>
void TraverseBwd<singlylist>(singlylist* head)
{
    ErrorMsg("ERROR:TraverseBwd: Unimplemented for singly linked lists");
}
template <typename T>
void TraverseBwd(T* tail)
{
    T* curr=tail;
    while (curr!=tail->next&&curr->prev)
    {
        cout << curr->name << " , ";
        curr=curr->prev;
    }
    cout << curr->name << endl;
}
