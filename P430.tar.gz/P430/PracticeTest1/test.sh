#!/bin/sh
rm input.txt
touch input.txt
#random number of lines
RANDCOUNT=$(( ( RANDOM % 15 )  + 1 ))
for i in `seq 1  $RANDCOUNT`; do
    echo -n $(./randstr_randlength.sh) >> input.txt
	echo >> input.txt
done
echo "FILE CONTENTS:"
cat input.txt
echo
#valgrind ./addtoend
#echo
#valgrind ./addtostart
echo "ADD TO START:"
./addtostart
echo
echo "ADD TO END:"
./addtoend
