#include <iostream>
#include <fstream>
#include <string.h>
#include <string>
using namespace std;

int const MAX_SIZE = 15;

struct singlylist
{
    singlylist* next;
    char name[MAX_SIZE];
};

struct doublylist
{
    doublylist* next;
    doublylist* prev;
    char name[MAX_SIZE];
};

struct circularlist
{
    circularlist* next;
    circularlist* prev;
    char name[MAX_SIZE];
};

void ErrorMsg(const char*);

template<typename T>
void ReadFile(T*& head);

template<typename T>
void TraverseFwd(T* head);
template<>
void TraverseFwd<circularlist>(circularlist* head);

template<typename T>
void TraverseBwd(T* tail);
template<>
void TraverseBwd(singlylist* tail);

template<typename T>
void AddToEnd(T*&, const char*);

template<typename T>
void RemoveFromEnd(T*&);

template<typename T>
void DeleteList(T*&);

int main()
{
    singlylist* shead=NULL;
    doublylist* dhead=NULL;
    circularlist* chead=NULL;
    doublylist* temp=NULL;

    ReadFile<singlylist>(shead);
    ReadFile<doublylist>(dhead);
    ReadFile<circularlist>(chead);

    cout << "Singly List Traverse:" << endl;
    TraverseFwd<singlylist>(shead);
    cout << "Doubly List Traverse:" << endl;
    TraverseFwd<doublylist>(dhead);
    cout << "Circular List Traverse:" << endl;
    TraverseFwd<circularlist>(chead);
    cout << "Circular List Traverse Backwards:" << endl;
    TraverseBwd<circularlist>(chead->prev);
    temp=dhead;
    while (temp->next) temp=temp->next;
    cout << "Doubly List Traverse Backwards:" << endl;
    TraverseBwd<doublylist>(temp);

    DeleteList<singlylist>(shead);
    DeleteList<doublylist>(dhead);
    DeleteList<circularlist>(chead);

    return 0;
}
void ErrorMsg(const char* msg)
{
    cout << msg << endl;
    throw;
}

template<typename T>
void ReadFile(T*& head)
{
    if (head != NULL) ErrorMsg("ERROR:void ReadFile(circularlist*& head): List not empty.");
    ifstream inf("input.txt");
    string temp;
    const char* ptr = NULL;
    while (inf >> temp)
    {
        ptr = temp.c_str();
        AddToEnd<T>(head,ptr);
        //TraverseFwd<T>(head);
    }
}
template <>
void AddToEnd<singlylist>(singlylist*& head, const char* data)
{
    if (data==NULL)ErrorMsg("ERROR:void AddToEnd<singlylist>(singlylist*& head, char data[]): Data is null.");
    if (head==NULL)
    {
        head = new singlylist;
        head->next=NULL;
        strncpy(head->name,data,MAX_SIZE);
    }
    else
    {
        singlylist* curr=head;
        while (curr->next) curr=curr->next;
        curr->next = new singlylist;
        curr->next->next=NULL;
        strncpy(curr->next->name,data,MAX_SIZE);
    }
}
template <>
void AddToEnd<doublylist>(doublylist*& head, const char* data)
{
    if (data==NULL)ErrorMsg("ERROR:void AddToEnd<doublylist>(doublylist*& head, char data[]): Data is null.");
    if (head==NULL)
    {
        head = new doublylist;
        head->next=head->prev=NULL;
        strncpy(head->name,data,MAX_SIZE);
    }
    else
    {
        doublylist* curr=head;
        while (curr->next) curr=curr->next;
        curr->next = new doublylist;
        curr->next->next=NULL;
        curr->next->prev=curr;
        strncpy(curr->next->name,data,MAX_SIZE);
    }
}
template <>
void AddToEnd<circularlist>(circularlist*& head, const char* data)
{
    if (data==NULL) ErrorMsg("ERROR:void AddToEnd<circularlist>(circularlist*& head, char data[]): Data is null.");
    if (head==NULL)
    {
        head = new circularlist;
        head->next=head;
        head->prev=head;
        strncpy(head->name,data,MAX_SIZE);
    }
    else
    {
        circularlist* curr = head->prev;
        curr->next = new circularlist;
        curr->next->next=head;
        curr->next->prev=curr;
        head->prev=curr->next;
        strncpy(curr->next->name,data,MAX_SIZE);
    }
}

template <>
void RemoveFromEnd<singlylist>(singlylist*& head)
{
    if (head==NULL)
    {
        return;
    }
    else
    {
        singlylist* curr = head;
        while (curr->next&&curr->next->next) curr=curr->next;
        if (curr->next)
        {
            delete curr->next;
            curr->next=NULL;
        }
        else
        {
            delete head;
            head=NULL;
        }
    }
}
template <>
void RemoveFromEnd<doublylist>(doublylist*& head)
{
    if (head==NULL)
    {
        return;
    }
    else
    {
        doublylist* curr = head;
        while (curr->next)curr=curr->next;
        if (curr->prev!=NULL)
        {
            curr=curr->prev;
            delete curr->next;
            curr->next=NULL;
        }
        else
        {
            delete head;
            head=NULL;
        }
    }
}
template <>
void RemoveFromEnd<circularlist>(circularlist*& head)
{
    if (head==NULL)
    {
        return;
    }
    else
    {
        circularlist* curr = head->prev;
        if (curr==head)
        {
            delete head;
            head=NULL;
        }
        else
        {
            head->prev=curr->prev;
            curr->prev->next=head;
            delete curr;
        }
    }
}
template <typename T>
void DeleteList(T*& head)
{
    while (head!=NULL) RemoveFromEnd<T>(head);
}

template <>
void TraverseFwd<circularlist>(circularlist* head)
{
    circularlist* curr = head;
    while (curr!=head->prev)
    {
        cout << curr->name << " , ";
        curr=curr->next;
    }
    cout << curr->name << endl;
}
template<typename T>
void TraverseFwd(T* head)
{
    while (head->next)
    {
        cout << head->name << " , ";
        head=head->next;
    }
    cout << head->name << endl;
}
template <>
void TraverseBwd<singlylist>(singlylist* head)
{
    ErrorMsg("ERROR:TraverseBwd: Unimplemented for singly linked lists");
}
template <typename T>
void TraverseBwd(T* tail)
{
    T* curr=tail;
    while (curr!=tail->next&&curr->prev)
    {
        cout << curr->name << " , ";
        curr=curr->prev;
    }
    cout << curr->name << endl;
}
