#!/bin/bash
./prettyPrint.lisp > input.txt
valgrind ./main
#./main
