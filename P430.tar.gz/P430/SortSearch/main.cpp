#include <iostream>
#include <iomanip> //setw to make my output prettier
using namespace std;
const unsigned int COL_SIZE = 4;
const unsigned int ROW_SIZE = 5;
const unsigned int SIZE = ROW_SIZE * COL_SIZE;

//utility functions
void swapRow(int arr[][COL_SIZE],unsigned int src,unsigned int dest,unsigned int rsize);
void swapCol(int arr[][COL_SIZE],unsigned int src,unsigned int dest,unsigned int csize);
void displayArray(int arr[][COL_SIZE],unsigned int rsize,unsigned int csize);
void copyArray(int arrsrc[][COL_SIZE],int arrdst[][COL_SIZE],unsigned int rsize,unsigned int csize);

//the sorts are adapted from the ones you gave us in the notes since you said not to reinvent the wheel with these

//column sorts need to know row ending index (ROW_SIZE-1) as limit and which column to sort
void bubbleSortColumns(int arr[][COL_SIZE],unsigned int limit,unsigned int col); //might be nicer to pass ROW_SIZE and COL_SIZE for more general sorts
void selectionSortColumns(int arr[][COL_SIZE],unsigned int limit,unsigned int col);
void shellSortColumns(int arr[][COL_SIZE],unsigned int limit,unsigned int col);

//row sorts need to know col ending index (COL_SIZE-1) as limit and which row to sort
void insertionSortRows(int arr[][COL_SIZE],unsigned int limit,unsigned int row);

//a linear search by row needs to know the row to search and the ending index for the columns
bool linearSearchRow(int arr[][COL_SIZE],int query,unsigned int row,unsigned int collimit);

int main()
{

    int arr[ROW_SIZE][COL_SIZE] = {{5,3,2,6},{9,8,10,17},{4,7,11,18},{2,5,9,12},{7,9,4,10}};
    int arr_copy[ROW_SIZE][COL_SIZE];
    int query = 0;
    copyArray(arr,arr_copy,ROW_SIZE,COL_SIZE);

    cout << "Initial State:" << endl << endl;
    displayArray(arr,ROW_SIZE,COL_SIZE);

    bubbleSortColumns(arr,ROW_SIZE-1,0);
    cout << "After BubbleSort: (Col 1)" << endl << endl;
    displayArray(arr,ROW_SIZE,COL_SIZE);
    copyArray(arr_copy,arr,ROW_SIZE,COL_SIZE);

    selectionSortColumns(arr,ROW_SIZE-1,1);
    cout << "After SelectionSort: (Col 2)" << endl << endl;
    displayArray(arr,ROW_SIZE,COL_SIZE);
    copyArray(arr_copy,arr,ROW_SIZE,COL_SIZE);

    shellSortColumns(arr,ROW_SIZE-1,2);
    cout << "After ShellSort: (Col 3)" << endl << endl;
    displayArray(arr,ROW_SIZE,COL_SIZE);
    copyArray(arr_copy,arr,ROW_SIZE,COL_SIZE);

    insertionSortRows(arr,COL_SIZE-1,4);
    cout << "After InsertionSort: (Row 5)" << endl << endl;
    displayArray(arr,ROW_SIZE,COL_SIZE);

    cout << "What number are you searching for in the 5th row? ";
    cin >> query;
    cout << "that element was " << ((linearSearchRow(arr,query,4,COL_SIZE-1))?("FOUND."):("NOT FOUND.")) << endl<<endl;

    //you said to reset the array after each sort but you also search before that in the example
    cout << "Ending State:" << endl << endl;
    copyArray(arr_copy,arr,ROW_SIZE,COL_SIZE);
    displayArray(arr,ROW_SIZE,COL_SIZE);

    return 0;
}
void swapRow(int arr[][COL_SIZE],unsigned int src,unsigned int dest,unsigned int rsize)
{
    int temp = 0;
    for (unsigned int i = 0; i <= rsize; i++) //if this is <= then passing rsize-1 is consistent with SIZE-1 in the sorts
    {
        temp = arr[src][i];
        arr[src][i] = arr[dest][i];
        arr[dest][i] = temp;
    }
}
void swapCol(int arr[][COL_SIZE],unsigned int src,unsigned int dest,unsigned int csize)
{
    int temp = 0;
    for (unsigned int i = 0; i <= csize; i++)
    {
        temp = arr[i][src];
        arr[i][src] = arr[i][dest];
        arr[i][dest] = temp;
    }
}
void displayArray(int arr[][COL_SIZE],unsigned int rsize,unsigned int csize)
{
    for (unsigned int i = 0; i < rsize; i++)
    {
        for (unsigned int j = 0; j < csize; j++)
        {
            cout <<setw(3)<< arr[i][j] << " ";
        }
        cout << endl;
    }
    cout << endl;
}
void copyArray(int arrsrc[][COL_SIZE],int arrdst[][COL_SIZE],unsigned int rsize,unsigned int csize)
{
    for (unsigned int i = 0; i < rsize; i++)
    {
        for (unsigned int j = 0; j < csize; j++)
        {
            arrdst[i][j]=arrsrc[i][j];
        }
    }
}
void bubbleSortColumns(int arr[][COL_SIZE],unsigned int limit,unsigned int col)
{
    unsigned int index;
    //This loop is used to determine the number of passes
    for (; limit > 0; limit--)
    {
        for (index=0; index<limit; index++)
        {
            //To change to descending order just change the
            //relational operator to <
            if (arr[index][col] > arr[index+1][col])
            {
                swapRow(arr,index,index+1,COL_SIZE-1);
            }
        }
    }
}
void selectionSortColumns(int arr[][COL_SIZE],unsigned int limit,unsigned int col)
{
    unsigned int index_of_largest,index;
    //This loop is used to determine the number of passes
    for(; limit > 0; limit--)
    {
        index_of_largest=0 ;
        //This loop is used to determine the number of
        //comparisons for each pass
        for (index=1; index<=limit; index++)
        {
            //To change to ascending order just change the
            //relational operator to >.
            if (arr[index][col] < arr[index_of_largest][col])
                index_of_largest=index; //Store the index of array element
        }
        //Swap element at the end of pass if needed
        if (limit !=index_of_largest)
        {
            swapRow(arr,limit,index_of_largest,COL_SIZE-1);
        }
    }
}
void shellSortColumns(int a[][COL_SIZE],unsigned int n,unsigned int col)
{
    //maintain the ROW_SIZE-1 convention for sorts and searches
    n++;
    for (unsigned int gap=n/2; gap>=1; gap=gap/2)
    {
        for(unsigned int i=gap; i<n; i++)
        {
            for (unsigned int j=i; j>=gap && a[j-gap][col]>a[j][col]; j=j-gap)
            {
                swapRow(a,j-gap,j,COL_SIZE-1);
            }
        }
    }
}
void insertionSortRows(int arr[][COL_SIZE],unsigned int limit,unsigned int row)
{
    unsigned int i=0, j=0;
    for (i = 1; i < limit; i++)
    {
        for (j=i; j>0 && arr[row][j] < arr[row][j-1]; j--)
        {
            swapCol(arr,j,j-1,ROW_SIZE-1);
        }
    }
}
bool linearSearchRow(int arr[][COL_SIZE],int query,unsigned int row,unsigned int collim)
{
    for (unsigned int i =0; i <= collim; i++)
        if (arr[row][i]==query) return true;
    return false;
}
