#include <iostream>
#include <fstream>
using namespace std;

//tree nodes
struct TreeNode
{
    int key;
    TreeNode* left = NULL;
    TreeNode* right = NULL;
};

//build a node with a given key
TreeNode* NewNode(int);
//insert an item into the correct position
void Insert(TreeNode*&,int);
//find an item to delete from the tree then call DeleteNode to perform the removal
//this function expects the node to be in the tree (which is why I search for the item before using this function to delete it)
TreeNode* Delete(TreeNode*&,int);
//search for an item in the tree return true or false
bool Search(TreeNode*&,int);
//delete an item from the tree while maintaing proper binary tree ordering
//this was cobbled together from the notes
TreeNode* DeleteNode(TreeNode*&,int);
//find the smallest element in the branch
TreeNode* Min(TreeNode*&);
//build a tree per the assignment spec
void BuildTree(TreeNode*&);
//free a tree
void DeleteTree(TreeNode*&);
//Perform each of traversals wrt to the assignment spec
void Traversals(TreeNode*& root);
//perform a postorder traversal
void PostOrder(TreeNode*,ofstream&);
//perform a preorder traversal
void PreOrder(TreeNode*,ofstream&);
//perform an inorder traversal
void InOrder(TreeNode*,ofstream&);
//perform a levelorder (breadth search fromat) traversal
void LevelOrder(TreeNode*,ofstream&);

//structs for dealing with queues of treenodes nicely
struct QueueNode
{
    TreeNode* treeptr=NULL;
    QueueNode* next=NULL;
};
struct Queue
{
    QueueNode* front=NULL;
    QueueNode* rear=NULL;
};
//wrappers to the enqueue and dequeue functions I wrote previously to keep things slightly cleaner
void Enqueue(Queue&,TreeNode*&);
TreeNode* Dequeue(Queue&);
//the actual enqueue dequeue handlers
void EnqueueHandler(QueueNode*& front,QueueNode*& rear,TreeNode*& data);
TreeNode* DequeueHandler(QueueNode*& front);

//like the last assignment this outputs graphvisuals which helped a lot with debugging
//these are slightly modified for a nicer output
void DotLangPrint(TreeNode*& root);
void DotHandler(TreeNode*& node);

int main()
{
    TreeNode* root = NULL;
    BuildTree(root);
    DotLangPrint(root);
    Traversals(root);
    DeleteTree(root);
}
void PostOrder(TreeNode* node,ofstream& outf)
{
    if (node!=NULL)
    {
        //left
        PostOrder(node->left,outf);
        //right
        PostOrder(node->right,outf);
        //visit
        outf << node->key << ":";
    }
}
void PreOrder(TreeNode* node,ofstream& outf)
{
    if (node!=NULL)
    {
        //visit
        outf << node->key << ":";
        //left
        PreOrder(node->left,outf);
        //right
        PreOrder(node->right,outf);
    }
}
void InOrder(TreeNode* node,ofstream& outf)
{
    if (node!=NULL)
    {
        //left
        InOrder(node->left,outf);
        //visit
        outf << node->key << ":";
        //right
        InOrder(node->right,outf);
    }
}
void LevelOrder(TreeNode* node,ofstream& outf)
{
    unsigned nicl=0; //nodes in current level
    unsigned ninl=0; //nodes in next level
    Queue pq; //printqueue
    Enqueue(pq,node);//enqueue the root
    nicl++;
    outf << endl<<"\t";
    while (nicl>0)
    {
        TreeNode* temp = Dequeue(pq); //dequeue whatever needs printed
        nicl--;
        outf << ":"<<temp->key;
        if (temp->left) //enqueue the left stuff
        {
            Enqueue(pq,temp->left);
            ninl++;
        }
        if (temp->right) //enqueue the right stuff
        {
            Enqueue(pq,temp->right);
            ninl++;
        }
        if(nicl==0) //if nicl==0 we are ready to move on the the next level
        {
            nicl=ninl;
            ninl=0;
            outf << endl<<"\t";
        }
    }
    //queue is empty so nothing left to clean up
}
void Traversals(TreeNode*& root)
{
    ofstream outf("output.txt");
    if(root==NULL)
    {
        outf << "*TREE IS EMPTY*";
        return;
    }

    outf << "postorder traversal: ";
    PostOrder(root,outf);
    outf << endl;

    outf << "inorder traversal: ";
    InOrder(root,outf);
    outf << endl;

    outf << "preorder traversal: ";
    PreOrder(root,outf);
    outf << endl;

    outf << "level-order traversal: ";
    LevelOrder(root,outf);
    outf << endl;

    outf.close();
}
//recurse the tree and delete everything
void DeleteTree(TreeNode*& node)
{
    if (node==NULL) return;

    //delete the leaves first
    if (node->left!=NULL) DeleteTree(node->left);
    if (node->right!=NULL) DeleteTree(node->right);

    //delete the current node last
    delete node;
    node=NULL;
}
//build the tree according to the spec
void BuildTree(TreeNode*& root)
{
    fstream inf("input.txt");
    string input = "";
    while (getline(inf,input))
    {
        cout << "input-sequence:" << input << endl;
        if (input.substr(0,6)=="delete") //Delete(from tree,atoi(rest of string after "delete" keyword))
        {
            if(!Search(root,atoi(input.substr(6).c_str()))) //check if the node to be deleted exists
                Insert(root,atoi(input.substr(6).c_str())); //if not found insert it like the assignment spec says to do
            else
                Delete(root,atoi(input.substr(6).c_str())); //if it did exist then delete it
        }
        else
        {
            Insert(root,atoi(input.c_str())); //insert the string converted as an integer
        }
    }
    inf.close();
}

TreeNode* Min(TreeNode*& leaf)
{
    TreeNode* min=leaf;
    while (min->left!=NULL)min=min->left; //follow the left branch to the end since that leads to the min node
    return min;
}
//receives key returns a new node
TreeNode* NewNode(int key)
{
    TreeNode* node=new TreeNode;
    node->key = key;
    node->left=NULL;
    node->right=NULL;
    return node;
}
//insert item in the appropriate position
void Insert(TreeNode*& leaf, int item)
{
    if (!leaf)
    {
        leaf=NewNode(item);
    }
    else if (item < leaf->key)
    {
        Insert(leaf->left, item);
    }
    else if (item > leaf->key)
    {
        Insert(leaf->right, item);
    }
    //this will not insert duplicates but could be modified to do so
}
//find the value to delete
TreeNode* Delete(TreeNode*& leaf, int item)
{
    if (item == leaf->key) //if you find the thing then delete that particular node
    {
        DeleteNode(leaf,item);
        return leaf;
    }
    else if (item < leaf->key) //search left
    {
        return Delete(leaf->left, item);
    }
    else //search right
    {
        return Delete(leaf->right, item);
    }
    throw runtime_error("RUNTIME-ERROR: TreeNode* Delete(TreeNode*& leaf, int item): Delete failed unexpectedly");
}
//find a value in the tree
bool Search(TreeNode*& leaf, int item)
{
    if (!leaf)
    {
        return false;
    }
    else if (item == leaf->key)
    {
        return true;
    }
    else if (item < leaf->key)
    {
        return Search(leaf->left, item);
    }
    else
    {
        return Search(leaf->right, item);
    }
    throw runtime_error("RUNTIME-ERROR:bool Search(TreeNode*& leaf, int item): Search failed unexpectedly");
}

TreeNode* DeleteNode(TreeNode*& leaf, int item)
{
    TreeNode* temp = leaf;
    if (leaf->left==NULL&&leaf->right==NULL) //no child nodes
    {
        delete leaf;
        leaf=NULL;
        return leaf;
    }
    else if (leaf->left!=NULL&&leaf->right!=NULL) //both nodes are not null meaning the node has two children
    {
        //this is that weird case from the notes
        TreeNode* child=(leaf->left)?(leaf->left):(leaf->right);
        TreeNode* minormax=Min(child);
        leaf->key=minormax->key;
        Delete(leaf->left,minormax->key);
        return leaf;
    }
    else
    {
        temp=(leaf->left)?(leaf->left):(leaf->right);
        delete leaf;
        leaf=temp;
        return temp;
    }
    throw runtime_error("RUNTIME-ERROR:void DeleteNode(TreeNode*& leaf, int item): Could not delete node from tree");
}
void Enqueue(Queue& q,TreeNode*& node)
{
    EnqueueHandler(q.front,q.rear,node);
}
TreeNode* Dequeue(Queue& q)
{
    return DequeueHandler(q.front);
}
void EnqueueHandler(QueueNode*& front,QueueNode*& rear,TreeNode*& data)
{
    //if front is null the queue is empty
    if (!front)
    {
        front = new QueueNode;
        front->next=NULL;
        front->treeptr=data;
        rear=front;
    }
    else //if not the queue has items so we have to add new stuff to the rear
    {
        rear->next = new QueueNode;
        rear->next->treeptr = data;
        rear->next->next = NULL;
        rear=rear->next;
    }
}

TreeNode* DequeueHandler(QueueNode*& front)
{
    //handle front is null case
    if (!front) throw runtime_error("ERROR:void Dequeue(QueueNode*& front): Nothing to dequeue.");

    //if not remove from the front
    QueueNode* tempnode = front;
    TreeNode* retval = front->treeptr;
    front = front->next;
    delete tempnode;
    return retval;
}
/*---------------------------------------------------------------------------*/
/*---------------------------------------------------------------------------*/
//graphviz output stuff
/*---------------------------------------------------------------------------*/
/*---------------------------------------------------------------------------*/

void DotLangPrint(TreeNode*& root)
{
    //if (root==NULL) throw runtime_error("void DotLangPrint(TreeNode* root): root must not be NULL.");
    if (root==NULL) return;
    cout << "digraph BST\n{"<<endl;
    cout << "\tnodesep=0.01"<<endl;
    DotHandler(root);
    cout << "}"<<endl;

    cout << endl << endl << "You can copy and paste the code: \"digraph names { ... }\" ";
    cout << "at one of the following sites to see a diagram of the tree"<< endl;
    cout << "http://webgraphviz.com/" << endl;
    cout << "https://dreampuf.github.io/GraphvizOnline/" << endl;
    cout << "http://viz-js.com/" << endl;
    cout << "or use some other graphviz/DOT language viewer" << endl;
    cout << "more info about graphviz can be found here:" << endl;
    cout << "https://www.graphviz.org/about/" << endl;

}
void DotHandler(TreeNode*& node)
{
    static long invisnode = 0;
    //print the connecting nodes
    if (node->left==NULL)
    {
        cout << "\t"<<long(&node)<< " -> "<<++invisnode<<"//left branch is null"<<endl;
        cout << "\t" << invisnode << "[label=\"\\\\\"]"<<endl;
    }
    else
    {
        cout << "\t"<<long(&node) << " -> " << long(&(node->left)) << endl;
    }

    if (node->right==NULL)
    {
        cout << "\t"<<long(&node)<< " -> "<<++invisnode<<"//right branch is null"<<endl;
        cout << "\t" << invisnode << "[label=\"\\\\\"]"<<endl;
    }
    else
    {
        cout << "\t" <<long(&node) << " -> " << long(&(node->right)) << endl;
    }

    //recurse
    if(node->left!=NULL)DotHandler(node->left);
    if(node->right!=NULL)DotHandler(node->right);

    //print the label for the current node
    cout << "\t" <<long(&node)<<"[label=\""<<node->key<<"\"];"<<endl;
}

