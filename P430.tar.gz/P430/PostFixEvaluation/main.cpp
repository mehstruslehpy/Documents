#include <iostream>
#include <fstream>
using namespace std;

const unsigned int MAX_LENGTH = 999;

struct Node
{
    char data;
    Node* next;
};
typedef Node Stack;
typedef Node Queue;

//Stack stuff
void Push(Stack*& top, char value);
char Pop(Stack*& top);
char Peek(Stack*& top);

//Queue stuff
void Enqueue(Queue*& front,Queue*& rear,char value);
char Dequeue(Queue*& front);

//mixed
void Read(char* str);
void Convert(Stack*& top,Queue*& front,Queue*& rear,char* str);
void DeleteStruct(Node*& head);
void TraverseStruct(Node* head);
void Error(const char* msg);
void Operator(Stack*& top,Queue*& front,Queue*& rear,char str);

//new stuff
//evaluate the postfix expression stored in str
int Evaluate(char* str);
//choose the correct operation and perform it
int EvalOp(char opa,char opb,char op);

int main()
{
    char str[MAX_LENGTH];

    //read a formula
    Read(str);
    //print it
    cout << "input formula:"<<endl<<str<<endl;
    //convert it
    cout << "After Evaluating: " << str <<"  =  "<< Evaluate(str) << endl;
}

//iterate through the input string and run the evaluation program from class/notes
int Evaluate(char* str)
{

    Node* stk = NULL;
    int opa = 0;
    int opb = 0;
    int result = 0;

    //iterate through each element in the string
    for (int i = 0; str[i]!='\0'; i++)
    {
		//isdigit is available on my machine without using a #include my manual
		//says it is available through ctype.h
        if (isdigit(str[i]))
        {
            Push(stk,str[i]);
        }
        else if (str[i] == '=')
        {
            break;
        }
        else
        {
			opb = Pop(stk);
			opa = Pop(stk);
            result = EvalOp(opa,opb,str[i]);
            Push(stk,result+'0'); //store as a char
        }
    }
    return Pop(stk)-'0'; //return as an int
}
//switch on and perform the correct operation based on op
int EvalOp(char opa,char opb,char op)
{
	int result = 0;
	opa = opa-'0'; //perform arithmetic as an int
	opb = opb-'0';
	switch (op)
    {
    case '+':
    {
		result  = opa + opb;	
        break;
    }
    case '-':
    {
		result  = opa - opb;	
        break;
    }
    case '*':
    {
		result  = opa * opb;	
        break;
    }
    case '/':
    {
		result  = opa / opb;	
        break;
    }
    default:
    {
        Error("int EvalOp(int opa,int opb,char op): Unknown operator.");
    }
    }
	return result;
}
//mixed
void Error(const char* msg)
{
    cout << msg << endl;
    throw;
}
void DeleteStruct(Node*& list)
{
    if (!list) Error("ERROR:void DeleteStruct(Node*& head): Cannot delete empty struct");
    Node* temp = NULL;
    while (list->next)
    {
        temp = list->next;
        delete list;
        list=temp;
    }
    temp = list->next;
    delete list;
    list=temp;
}
void TraverseStruct(Node* head)
{
    //don't print anything for an empty struct
    if (!head) return;

    //if not empty traverse through and print the whole thing
    cout << head->data;
    while (head->next)
    {
        head=head->next;
        cout << " " << head->data;
    }
}
void Read(char* str)
{
    //string can't be null
    if (!str) Error("ERROR:void Read(char* str): String must be non-null.");
    ifstream infile("input.txt");

    //read one line and exit
    if (infile >> str) return;

    //if you reach here something went wrong
    Error("ERROR:void Read(char* str): Malformed input file.");
}

//Stack stuff
void Push(Stack*& top, char value)
{
    if (!top)
    {
        top = new Node;
        top->next=NULL;
        top->data=value;
    }
    else
    {
        Node* temp = new Node;
        temp->next = top;
        temp->data = value;
        top=temp;
    }
}
char Pop(Stack*& top)
{
    if (!top) Error("ERROR:char Pop(Stack*& top): Cannot pop from empty stack.");
    char retvalue = top->data;
    Node* temp = top;
    top=top->next;
    delete temp;
    return retvalue;
}
//just return the data of the top of stack
char Peek(Stack*& top)
{
    if (!top) Error("ERROR:char Peek(Stack*& top): Cannot peek on empty stack.");
    return top->data;
}

//Queue stuff
void Enqueue(Queue*& front,Queue*& rear,char value)
{
    if((rear&&!front)||(front&&!rear)) Error("ERROR:void Enqueue(Queue*& front,Queue*& rear): Malformed queue pointers.");
    if (!front)
    {
        rear = new Node;
        rear->data=value;
        rear->next=NULL;
        front=rear;
    }
    else
    {
        rear->next = new Node;
        rear->next->data=value;
        rear->next->next=NULL;
        rear=rear->next;
    }
}
char Dequeue(Queue*& front)
{
    if (!front) Error("ERROR:char Dequeue(Queue*& front): Cannot dequeue from empty queue");
    Node* temp = front;
    char retvalue = front->data;
    front = front->next;
    delete temp;
    return retvalue;
}

