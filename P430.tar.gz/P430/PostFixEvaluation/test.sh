#!/bin/bash
rm input.txt
rm formula.txt
./prettyPrint.lisp > formula.txt
./convert > spaces.txt
cat spaces.txt | sed 's/\ //g' | sed -n '4p' > input.txt
#valgrind ./main
./main
echo
echo "Input with spaces: "
cat spaces.txt
echo "Which evaluates to: "
cat spaces.txt | sed -n '2p' | bc
