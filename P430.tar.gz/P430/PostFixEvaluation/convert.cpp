#include <iostream>
#include <fstream>
using namespace std;

//more than 999 characters of input will segfault
const unsigned int MAX_LENGTH = 999;

//map each token to a precedence
enum OpPrecedence
{
    //From highest to lowest ^*/+-(=
    DIGIT,
    OPAR,
    EQ,
    CPAR,
    SUB,
    ADD,
    DIV,
    MUL,
    EXP
};
//use nodes to represent stacks and queues
struct Node
{
    char data;
    Node* next;
};
typedef Node Stack;
typedef Node Queue;

//Stack stuff
//push value to top of stack
void Push(Stack*& top, char value);
//pop from top of stack and return value
char Pop(Stack*& top);
//peek at top of stack but don't dealloc
//without this I would need to push and re-pop whenever
//I want to peek
char Peek(Stack*& top);

//Queue stuff
//place value at rear of queue
void Enqueue(Queue*& front,Queue*& rear,char value);
//remove and return the front of the queue I didn't use this because
//because the algorithm for conversion never requires a dequeue and
//using one linked list style delete for both stack and queue is simpler
char Dequeue(Queue*& front);

//mixed
//read a formula into str
void Read(char* str);
//convert an infix formula to a postfix formula
void Convert(Stack*& top,Queue*& front,Queue*& rear,char* str);
//delete a linked list stack or queue
void DeleteStruct(Node*& head);
//print a linked list stack or queue
void TraverseStruct(Node* head);
//print msg and throw
void Error(const char* msg);
//map the character val to a precedence or call Error
OpPrecedence Prec(char val);
//handle operators in the conversion function
void Operator(Stack*& top,Queue*& front,Queue*& rear,char str);

int main()
{
    char str[MAX_LENGTH];
    Stack* opstack = NULL;
    Queue* frontq = NULL;
    Queue* rearq = NULL;
    
	//read a formula
	Read(str);
	//print it
    cout << "input formula:"<<endl<<str<<endl;
    //convert it
	Convert(opstack,frontq,rearq,str);
	//print the converted formula
    cout << "postfix output:"<<endl;
    TraverseStruct(frontq);
    cout << endl;
	
	//clean up
    if (frontq) DeleteStruct(frontq);
    if (opstack) DeleteStruct(opstack);
}

//mixed
void Error(const char* msg)
{
    cout << msg << endl;
    throw;
}
void DeleteStruct(Node*& list)
{
    if (!list) Error("ERROR:void DeleteStruct(Node*& head): Cannot delete empty struct");
    Node* temp = NULL;
    while (list->next)
    {
        temp = list->next;
        delete list;
        list=temp;
    }
    temp = list->next;
    delete list;
    list=temp;
}
void TraverseStruct(Node* head)
{
	//don't print anything for an empty struct
    if (!head) return;
    
	//if not empty traverse through and print the whole thing
	cout << head->data;
    while (head->next)
    {
        head=head->next;
        cout << " " << head->data;
    }
}
void Read(char* str)
{
	//string can't be null
    if (!str) Error("ERROR:void Read(char* str): String must be non-null.");
    ifstream infile("formula.txt");
    
	//read one line and exit
    if (infile >> str) return;
    
	//if you reach here something went wrong
	Error("ERROR:void Read(char* str): Malformed input file.");
}
void Convert(Stack*& top,Queue*& front,Queue*& rear,char* str)
{
	//loop through every char in the string
    for(unsigned int i = 0; str[i]!='\0'&&i<MAX_LENGTH; i++)
    {
        switch (str[i])
        {
        case '0':
        case '1':
        case '2':
        case '3':
        case '4':
        case '5':
        case '6':
        case '7':
        case '8':
        case '9':
        case 'a':
        case 'b':
        case 'c':
        case 'd':
        case 'e':
        case 'f':
        case 'g':
        case 'h':
        case 'i':
        case 'j':
        case 'k':
        case 'l':
        case 'm':
        case 'n':
        case 'o':
        case 'p':
        case 'q':
        case 'r':
        case 's':
        case 't':
        case 'u':
        case 'v':
        case 'w':
        case 'x':
        case 'y':
        case 'z':
		case 'A':
        case 'B':
        case 'C':
        case 'D':
        case 'E':
        case 'F':
        case 'G':
        case 'H':
        case 'I':
        case 'J':
        case 'K':
        case 'L':
        case 'M':
        case 'N':
        case 'O':
        case 'P':
        case 'Q':
        case 'R':
        case 'S':
        case 'T':
        case 'U':
        case 'V':
        case 'W':
        case 'X':
        case 'Y':
        case 'Z':

		{
			//all digits are immediately enqueued
            Enqueue(front,rear,str[i]);
            break;
        }
        case '(':
        {
			//push open parens
            Push(top,str[i]);
            break;
        }
        case ')':
        {
			//so long as you haven't hit another open paren
            while(Peek(top)!='(')
            {
				//enqueue any non parens
                char temp=Pop(top);
                if (temp!='('&&temp!=')') Enqueue(front,rear,temp);
            }
			//pop the corresonding open paren
            Pop(top);
            break;
        }
        case '=':
        case '+':
        case '-':
        case '*':
        case '/':
        case '^':
        {
			//for operators if the stack is not empty do Operator() if it is empty Push it
            if (top)
            {
                Operator(top,front,rear,str[i]);
            }
            else
            {
                Push(top,str[i]);
            }
            break;
        }
        default:
        {
            Error("ERROR:void Convert(Stack*& top,Queue*& front,Queue*& rear,char* str): Could not convert input.");
        }
        }
    }
	//snag up and enqueue all the remaining non-paren characters from the stack
    while (top)
    {
        char temp = Pop(top);
        if (temp!=')'&&temp!=')') Enqueue(front,rear,temp);
    }
}
void Operator(Stack*& top,Queue*& front,Queue*& rear,char str)
{
	//compare the current operator (str) to the top of the stack
	//push it if it is greater precedence than the top of the stack,
	//if not Enqueue all the non-parens until you can push str
    if (Prec(str)>Prec(Peek(top)))
    {
        Push(top,str);
    }
    else
    {
        while(top&&Prec(str)<=Prec(Peek(top)))
        {
            char temp = Pop(top);
            if (temp!=')'&&temp!=')') Enqueue(front,rear,temp);
        }
        Push(top,str);
    }
}
//Stack stuff
void Push(Stack*& top, char value)
{
    if (!top)
    {
        top = new Node;
        top->next=NULL;
        top->data=value;
    }
    else
    {
        Node* temp = new Node;
        temp->next = top;
        temp->data = value;
        top=temp;
    }
}
char Pop(Stack*& top)
{
    if (!top) Error("ERROR:char Pop(Stack*& top): Cannot pop from empty stack.");
    char retvalue = top->data;
    Node* temp = top;
    top=top->next;
    delete temp;
    return retvalue;
}
//just return the data of the top of stack
char Peek(Stack*& top)
{
    if (!top) Error("ERROR:char Peek(Stack*& top): Cannot peek on empty stack.");
    return top->data;
}

//Queue stuff
void Enqueue(Queue*& front,Queue*& rear,char value)
{
    if((rear&&!front)||(front&&!rear)) Error("ERROR:void Enqueue(Queue*& front,Queue*& rear): Malformed queue pointers.");
    if (!front)
    {
        rear = new Node;
        rear->data=value;
        rear->next=NULL;
        front=rear;
    }
    else
    {
        rear->next = new Node;
        rear->next->data=value;
        rear->next->next=NULL;
        rear=rear->next;
    }
}
char Dequeue(Queue*& front)
{
    if (!front) Error("ERROR:char Dequeue(Queue*& front): Cannot dequeue from empty queue");
    Node* temp = front;
    char retvalue = front->data;
    front = front->next;
    delete temp;
    return retvalue;
}
//map each token to the correct precedence via the enum at the top of the file
OpPrecedence Prec(char val)
{
    switch (val)
    {
    case '0':
    case '1':
    case '2':
    case '3':
    case '4':
    case '5':
    case '6':
    case '7':
    case '8':
    case '9':
        return DIGIT;
    case '=':
        return EQ;
    case '(':
        return OPAR;
    case '+':
        return ADD;
    case '-':
        return SUB;
    case '*':
        return MUL;
    case '/':
        return DIV;
    case '^':
        return EXP;
    case ')':
        return CPAR;
    default:
    {
        Error("ERROR: Unrecognized character on input");
    }
    }
    //shut up compiler warnings about possibly not returning
    Error("ERROR: It should be impossible to reach this point");
    return OpPrecedence(-1);
}
