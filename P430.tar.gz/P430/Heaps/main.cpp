#include <iostream>
#include <fstream>
using namespace std;
//I originally wrote this with plain ints with an empty value of -1
//but then all of my comparisons for shuffling heap items around had to account for that
//which was a huge hassle.
//Using a struct (or even simpler just a pointer to an int) adds another level of indirection
//so that you know a spot in the heap is empty when it is null, and you can compare values
//by dereferencing the required pointers
struct HeapValue
{
    int* num=NULL;
};
const int* EMPTY_VALUE=NULL; //not super necessary but I used this when I was attempting to do this with plain ints

//index formulas
inline unsigned Left(unsigned);
inline unsigned Right(unsigned);
inline unsigned Parent(unsigned);
//build a heap from a file given its maximum size and the filename in a string
void BuildHeap(HeapValue[],unsigned&,unsigned,string);
//insert an integer into a heap given its maximum size and the end index of the heap
void Insert(HeapValue[],int,unsigned,unsigned);
//delete and return a value from a heap given its maximum size and the end index of the heap
int Delete(HeapValue[],unsigned&,unsigned);
//print a heap in array format
void HeapIndexPrint(HeapValue[],unsigned);
//print a heap in level order
void HeapLevelPrint(HeapValue heap[],unsigned);

//sift a heap value up
void SiftUp(HeapValue[],unsigned);
//sift a heap value down
unsigned SiftDown(HeapValue[],unsigned);
//get a count of the number of items from a file
unsigned FileItemCount(string);

int main()
{
    const unsigned MAX_SIZE = FileItemCount("input.txt"); //calc the max size
    unsigned heapsize=0; //the index of the final item in the heap
    HeapValue* heap = new HeapValue[MAX_SIZE]; //alloc enough space for all the items in the heap
    for (unsigned i=0; i<MAX_SIZE; i++) heap[i].num=NULL; //init each one to null

    cout << "Before building the heap:" << endl;
    HeapIndexPrint(heap,MAX_SIZE); //print the empty heap
    cout << endl;
    BuildHeap(heap,heapsize,MAX_SIZE,"input.txt"); //build the heap
    cout << "After building the heap:" << endl;
    HeapIndexPrint(heap,MAX_SIZE); //print the filled heap
    cout << endl;

    cout << "The level ordered heap:" << endl;
    HeapLevelPrint(heap,heapsize); //print in level order
    cout << endl;

    cout << "Delete 1 deleted: " << Delete(heap,heapsize,MAX_SIZE) << endl;
    HeapLevelPrint(heap,heapsize);
    cout << endl ;

    cout << "Delete 2 deleted: " << Delete(heap,heapsize,MAX_SIZE) << endl;
    HeapLevelPrint(heap,heapsize);
    cout << endl ;

    cout << "Delete 3 deleted: " << Delete(heap,heapsize,MAX_SIZE) << endl;
    HeapLevelPrint(heap,heapsize);
    cout << endl ;

    cout << "Delete 4 deleted: " << Delete(heap,heapsize,MAX_SIZE) << endl;
    HeapLevelPrint(heap,heapsize);
    cout << endl ;

    cout << "Delete 5 deleted: " << Delete(heap,heapsize,MAX_SIZE) << endl;
    HeapLevelPrint(heap,heapsize);
    cout << endl ;

    cout << "After deletions:" << endl;
    HeapIndexPrint(heap,MAX_SIZE); //print the final array
    cout << endl;

    //clean up
    for (unsigned i=0; heap[i].num; i++) delete heap[i].num; //delete each int pointer
    delete [] heap; //delete the space for the heap
}
//a heap is already technically in level order in array form hence this is just the other print plus some decorations
void HeapLevelPrint(HeapValue heap[],unsigned end)
{
    cout << "Level 0: ";
    for (unsigned i=0,pow2=2,curlevel=1; i<end; i++)
    {
        //print the element or empty
        (heap[i].num==NULL)?(cout<<":*EMPTY*"):(cout<<":"<<*(heap[i].num));
        //print endl's and level headings when needed
        if (i==pow2-2)
        {
            cout << endl<<"Level "<<curlevel++<<": ";
            pow2*=2;
        }
    }
    cout << endl;
}
void HeapIndexPrint(HeapValue heap[],unsigned size)
{
    for (unsigned i=0; i<size; i++)
        (heap[i].num==NULL)?(cout<<":*EMPTY*"):(cout<<":"<<*(heap[i].num));
    cout << endl;
}
void BuildHeap(HeapValue heap[],unsigned& heapsize,unsigned size,string infile)
{
    fstream inf(infile);
    int temp=0;
    for (unsigned i=0; (inf>>temp)&&(i<size); i++) //keep reading while there is stuff left ot read and we haven't exceeded our size
    {
        Insert(heap,temp,heapsize++,size); //insert each item from the file and increment the heapsize
    }
}
void Insert(HeapValue heap[],int value,unsigned end,unsigned size)
{
    if (heap[end].num!=EMPTY_VALUE) throw runtime_error("RUNTIME-ERROR: Insert into already full heap");
    if (end>size) throw runtime_error("RUNTIME-ERROR: Inserting with end of heap is beyond its size lengths");
    heap[end].num=new int(value); //make space for a new element
    for (int i=end; i!=0&&*(heap[i].num)<*(heap[Parent(i)].num); i=Parent(i)) //rearrange to maintain heap properties
        SiftUp(heap,i);
}
//just a swap but using the parent index
void SiftUp(HeapValue heap[],unsigned i)
{
    HeapValue temp;
    temp.num=heap[i].num;
    heap[i].num=heap[Parent(i)].num;
    heap[Parent(i)].num=temp.num;
}
int Delete(HeapValue heap[],unsigned& end,unsigned size)
{
    if (heap[0].num==EMPTY_VALUE) throw runtime_error("RUNTIME-ERROR: Delete from empty heap");
    int ret = *(heap[0].num); //value to return
    delete heap[0].num; //delete the removed value
    heap[0].num=heap[end-1].num; //set the root to the last item
    heap[end-1].num=NULL; //clear the last item
    end--; //shrink the end by one

    bool siftneeded = true; //used if a sift is needed
    //a sift is needed when...
    if (end>0&&Left(0)<size&&heap[Left(0)].num&&*(heap[0].num)>*(heap[Left(0)].num))siftneeded=true; //end>0,left exists,parent is bigger than left
    else if (end>0&&Right(0)<size&&heap[Right(0)].num&&*(heap[0].num)>*(heap[Right(0)].num))siftneeded=true; //end>0,right exists,parent is bigger than right
    else siftneeded=false; //if not don't sift
    for (unsigned i=0; siftneeded;)
    {
        i=SiftDown(heap,i);//i gets moved down the tree
        if (end>0&&Left(i)<size&&heap[Left(i)].num&&*(heap[i].num)>*(heap[Left(i)].num))siftneeded=true; //same boolean as before but on i rather than 0
        else if (end>0&&Right(i)<size&&heap[Right(i)].num&&*(heap[i].num)>*(heap[Right(i)].num))siftneeded=true;
        else siftneeded=false;
    }
    return ret;
}
//sift down based on the child heap[i] is bigger than
unsigned SiftDown(HeapValue heap[],unsigned i)
{
    unsigned smalli;
    unsigned lefti = Left(i); //get lefti and righti ahead of time to make things simple
    unsigned righti = Right(i);
    //get the correct index
    if (heap[lefti].num&&heap[righti].num) //if both exist
        if (*(heap[lefti].num)<*(heap[righti].num)) smalli=lefti; //pick the smaller
        else smalli=righti;
    else if (heap[lefti].num) smalli=lefti; //if not pick whichever remains
    else smalli=righti;
    //perform the swap
    HeapValue temp = heap[i];
    heap[i]=heap[smalli];
    heap[smalli]=temp;
    return smalli;//return the new index
}
unsigned FileItemCount(string inf)
{
    unsigned cnt=0;
    int tmp=0;
    ifstream file(inf);
    for(; file>>tmp; cnt++); //count each item in the file
    return cnt+1;
}
inline unsigned Left(unsigned i)
{
    return 2*i+1;
}
inline unsigned Right(unsigned i)
{
    return 2*i+2;
}
inline unsigned Parent(unsigned i)
{
    return (i-1)/2;
}

